// ========================================
// FB Multi-Post Tool - Content Script v2.1
// ========================================

const FB_TOOL_VERSION = '3.5';

function announceInstalled() {
  try {
    if (document.documentElement) {
      document.documentElement.dataset.fbToolInstalled = FB_TOOL_VERSION;
    }
  } catch (e) {}
  window.postMessage({ type: 'FB_TOOL_INSTALLED', version: FB_TOOL_VERSION, extId: (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) ? chrome.runtime.id : '' }, '*');
}

function safeSendRuntime(payload, callback) {
  try {
    if (typeof callback === 'function') {
      chrome.runtime.sendMessage(payload, callback);
    } else {
      chrome.runtime.sendMessage(payload, () => {
        void chrome.runtime.lastError;
      });
    }
  } catch (e) {
    console.warn('FB Multi-Post Tool: Runtime messaging skipped', e);
  }
}

// Notify the web page immediately that the extension is installed
announceInstalled();

// Listen for messages from the web page
window.addEventListener('message', (event) => {
  if (event.source !== window || !event.data || typeof event.data !== 'object') return;
  const { type, groupId, groupUrl, content, images, postMode } = event.data;

  switch (type) {
    case 'CHECK_EXTENSION':
    case 'PING_EXTENSION':
      announceInstalled();
      break;

    case 'START_EXTRACTION':
      safeSendRuntime({
        action: 'start_extraction',
        data: {
          pageId: event.data.pageId || null,
          pageName: event.data.pageName || null
        }
      });
      break;

    case 'STOP_EXTRACTION':
      safeSendRuntime({ action: 'stop_extraction' });
      break;

    case 'POST_TO_GROUP':
      if (images && images.length > 0) {
        chrome.storage.local.set({ temp_post_images: images }, () => {
          if (chrome.runtime.lastError) {
            console.error('Storage Check Failed:', chrome.runtime.lastError);
            safeSendRuntime({
              action: 'post_to_group',
              data: { groupId, groupUrl, content, images, postMode }
            });
          } else {
            safeSendRuntime({
              action: 'post_to_group',
              data: { groupId, groupUrl, content, images: 'USE_STORAGE', postMode }
            });
          }
        });
      } else {
        safeSendRuntime({
          action: 'post_to_group',
          data: { groupId, groupUrl, content, images, postMode }
        });
      }
      break;

    case 'STOP_POSTING':
      safeSendRuntime({ action: 'stop_posting' });
      break;

    case 'CHECK_FACEBOOK_LOGIN':
      safeSendRuntime({ action: 'check_facebook_login' });
      break;

    case 'OPEN_FACEBOOK':
      safeSendRuntime({ action: 'open_facebook' });
      break;

    // Page Posts Feature
    case 'SCAN_PAGE_POSTS':
      safeSendRuntime({
        action: 'scan_page_posts',
        data: { pageUrl: event.data.pageUrl }
      });
      break;

    case 'SHARE_POST_TO_GROUP':
      safeSendRuntime({
        action: 'share_post_to_group',
        data: {
          groupId: event.data.groupId,
          groupName: event.data.groupName || '',
          groupUrl: event.data.groupUrl,
          postUrl: event.data.postUrl,
          caption: event.data.caption || ''
        }
      });
      break;

    case 'FETCH_USER_PAGES':
      safeSendRuntime({ action: 'fetch_user_pages' });
      break;

    case 'GET_CURRENT_PAGE':
      safeSendRuntime({ action: 'get_current_page' });
      break;
    case 'CHECK_POST_STATUS':
      safeSendRuntime({
        action: 'check_post_status',
        data: {
          requestId: event.data.requestId || '',
          url: event.data.url || '',
          groupId: event.data.groupId || ''
        }
      });
      break;
  }
});

// Listen for messages from the background script
chrome.runtime.onMessage.addListener((message) => {
  if (!message || typeof message !== 'object') return;
  const { action, data } = message;

  switch (action) {
    case 'group_data':
      window.postMessage({ type: 'GROUP_DATA', data }, '*');
      break;
    case 'status_update':
    case 'STATUS_UPDATE':
      window.postMessage({ type: 'STATUS_UPDATE', message: typeof message.message === 'string' ? message.message : ((message.message && message.message.message) || (data && data.message) || (typeof data === 'string' ? data : '')) }, '*');
      break;
    case 'total_count':
      window.postMessage({ type: 'TOTAL_COUNT', data }, '*');
      break;
    case 'FB_LOGGED_IN':
      window.postMessage({ type: 'FB_LOGGED_IN', data }, '*');
      break;
    case 'FB_USER_INFO':
      window.postMessage({ type: 'FB_USER_INFO', data }, '*');
      break;
    case 'FB_NOT_LOGGED_IN':
      window.postMessage({ type: 'FB_NOT_LOGGED_IN' }, '*');
      break;
    case 'POST_SUCCESS':
      window.postMessage({ type: 'POST_SUCCESS', data }, '*');
      break;
    case 'POST_ERROR':
      window.postMessage({ type: 'POST_ERROR', data }, '*');
      break;
    case 'error':
    case 'ERROR':
      window.postMessage({ type: 'ERROR', message: typeof message.message === 'string' ? message.message : ((message.message && message.message.message) || (data && data.message) || (typeof data === 'string' ? data : '')) }, '*');
      break;
    case 'complete':
      window.postMessage({ type: 'COMPLETE' }, '*');
      break;
    case 'page_posts_data':
      window.postMessage({ type: 'PAGE_POSTS_DATA', data }, '*');
      break;
    case 'page_posts_complete':
      window.postMessage({ type: 'PAGE_POSTS_COMPLETE' }, '*');
      break;
    case 'SHARE_SUCCESS':
      window.postMessage({ type: 'SHARE_SUCCESS', data }, '*');
      break;
    case 'SHARE_ERROR':
      window.postMessage({ type: 'SHARE_ERROR', data }, '*');
      break;
    case 'fb_pages_data':
      window.postMessage({ type: 'FB_PAGES_DATA', data }, '*');
      break;
    case 'current_page_info':
      window.postMessage({ type: 'CURRENT_PAGE_INFO', data }, '*');
      break;
    case 'POST_STATUS_RESULT':
      window.postMessage({ type: 'POST_STATUS_RESULT', data }, '*');
      break;
  }
});

// Ping background to keep worker alive
safeSendRuntime({ action: 'ping' }, () => {
  void chrome.runtime.lastError;
});
