// ========================================
// FB Multi-Post Tool - Background Service Worker
// ========================================

const DOC_ID = '24648931168042404';
const PAGINATION_DOC_ID = '9974006939348139';
// doc_id from fbtool.net v4.0.5 - used as fallback
const FBTOOL_DOC_ID = '9778341108915180';

// Anti-block settings
const MAX_POSTS_PER_HOUR = 15;
const MIN_DELAY_MS = 20000;  // 20 seconds
const MAX_DELAY_MS = 90000;  // 90 seconds

// State tracking
let isExtracting = false;
let isPosting = false;
let postCountThisHour = 0;
let lastHourReset = Date.now();

// Anti-block: Random delay helper
function randomDelay(min = MIN_DELAY_MS, max = MAX_DELAY_MS) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Anti-block: Rate limiting check
function checkRateLimit() {
  // Reset counter every hour
  if (Date.now() - lastHourReset > 3600000) {
    postCountThisHour = 0;
    lastHourReset = Date.now();
  }
  return postCountThisHour < MAX_POSTS_PER_HOUR;
}

// Anti-block: Checkpoint detection
function isCheckpoint(responseText) {
  if (!responseText) return false;
  return responseText.includes('checkpoint') ||
    responseText.includes('captcha') ||
    responseText.includes('temporarily blocked') ||
    responseText.includes('account has been locked');
}

// Message Listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const tabId = sender.tab?.id;

  switch (request.action) {
    case 'start_extraction':
      if (!isExtracting) {
        isExtracting = true;
        startExtraction(tabId, request.data || {});
      }
      break;

    case 'stop_extraction':
      isExtracting = false;
      break;

    case 'post_to_group':
      postToGroup(tabId, request.data);
      break;

    case 'stop_posting':
      isPosting = false;
      break;

    case 'check_facebook_login':
      checkFacebookLogin(tabId);
      break;

    case 'open_facebook':
      chrome.tabs.create({ url: 'https://www.facebook.com/' }, (newTab) => {
        if (tabId) loginTrackerTabs.set(tabId, newTab.id);
      });
      break;

    // Page Posts Feature
    case 'scan_page_posts':
      scanPagePosts(tabId, request.data.pageUrl);
      break;

    case 'share_post_to_group':
      sharePostToGroup(tabId, request.data);
      break;

    case 'fetch_user_pages':
      fetchUserPages(tabId);
      break;

    case 'get_current_page':
      getCurrentPageInfo(tabId);
      break;

    case 'check_post_status':
      checkPostStatus(tabId, request.data || {});
      break;

    case 'ping':
      sendResponse({ status: 'ok' });
      break;
  }
});

// ========================================
// Check Facebook Login Status
// ========================================
let loginTrackerTabs = new Map(); // uiTabId -> fbTabId

async function checkFacebookLogin(uiTabId) {
  try {
    const fbTabs = await chrome.tabs.query({ url: '*://*.facebook.com/*' });
    
    let userInfo = null;
    
    // 1. Try to extract user info from any active, open Facebook tabs
    if (fbTabs.length > 0) {
      for (const tab of fbTabs) {
        try {
          const info = await getUserInfoFromTab(tab.id);
          if (info && info.userId) {
            userInfo = info;
            break;
          }
        } catch (e) {
          console.log('Skipping inactive or discarded Facebook tab:', tab.id, e);
        }
      }
    }

    // 2. Fallback: Check direct c_user cookie via chrome.cookies API (supports www, m, mbasic)
    if (!userInfo) {
      try {
        const fbCookies = await getFbCookies();
        if (fbCookies && fbCookies.cUser) {
          userInfo = {
            userId: fbCookies.cUser,
            userName: 'Facebook User',
            userAvatar: ''
          };
        }
      } catch (cookieError) {
        console.error('Error querying cookies fallback:', cookieError);
      }
    }

    if (userInfo && userInfo.userId) {
      sendMessage(uiTabId, 'FB_USER_INFO', userInfo);
    } else {
      sendMessage(uiTabId, 'FB_NOT_LOGGED_IN', null);
    }
  } catch (error) {
    sendMessage(uiTabId, 'FB_NOT_LOGGED_IN', null);
  }
}

// Track login progress for specific tabs
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('facebook.com')) {
    for (const [uiTabId, fbTabId] of loginTrackerTabs.entries()) {
      if (tabId === fbTabId) {
        const userInfo = await getUserInfoFromTab(tabId);
        if (userInfo && userInfo.userId) {
          sendMessage(uiTabId, 'FB_USER_INFO', userInfo);
          // Close the Facebook tab since connection is successful
          try { chrome.tabs.remove(tabId); } catch (e) {}
          // Return focus to the app
          chrome.tabs.update(uiTabId, { active: true });
          chrome.tabs.get(uiTabId, (uiTab) => {
            if (uiTab && uiTab.windowId) {
              chrome.windows.update(uiTab.windowId, { focused: true });
            }
          });
          loginTrackerTabs.delete(uiTabId);
        }
      }
    }
  }
});

async function getUserInfoFromTab(tabId) {
  const result = await chrome.scripting.executeScript({
    target: { tabId: tabId },
    world: 'MAIN',
    func: () => {
      try {
        let userId = null;
        let userName = null;
        let userAvatar = null;
        let dtsg = null;
        let lsd = null;

        // --- 1. Get Auth Tokens (from FBTool 2) ---
        try {
          if (window.DTSGInitialData && window.DTSGInitialData.token) {
            dtsg = window.DTSGInitialData.token;
          }
          if (window.LSD && window.LSD.token) {
            lsd = window.LSD.token;
          }
          if (!dtsg && window.require) {
            try { dtsg = window.require("DTSGInitialData").token; } catch (e) { }
          }
          if (!lsd && window.require) {
            try { lsd = window.require("LSD").token; } catch (e) { }
          }
          if (!dtsg) {
            const input = document.querySelector('input[name="fb_dtsg"]');
            if (input) dtsg = input.value;
          }
          if (!lsd) {
            const input = document.querySelector('input[name="lsd"]');
            if (input) lsd = input.value;
          }
        } catch (e) { }

        // --- 2. Get User ID & Page Actor ID (i_user) from cookies ---
        let actorId = null;
        const cookies = document.cookie.split(';');
        for (const cookie of cookies) {
          const [name, value] = cookie.trim().split('=');
          if (name === 'c_user') userId = value;
          if (name === 'i_user') actorId = value;
        }

        if (!userId && !actorId && !dtsg) return null;

        // --- 3. Get User / Page Profile Info (Name & Avatar) ---
        // Strategy A: CurrentUserInitialData (handles both Personal & New Pages Experience profiles)
        try {
          if (window.CurrentUserInitialData) {
            if (window.CurrentUserInitialData.NAME) {
              userName = window.CurrentUserInitialData.NAME;
            }
            if (window.CurrentUserInitialData.ACCOUNT_ID) {
              actorId = window.CurrentUserInitialData.ACCOUNT_ID;
            }
            if (window.CurrentUserInitialData.USER_ID) {
              userId = window.CurrentUserInitialData.USER_ID;
            }
          }
        } catch (e) {}
        const isPageProfile = Boolean(actorId && userId && String(actorId) !== String(userId));
        if (isPageProfile) {
          userId = actorId;
        }

        // Strategy B: Try to get from aria-labels of profile links
        if (!userName) {
          const profileLink = document.querySelector('a[href*="/me/"]') ||
            document.querySelector('a[aria-label*="Trang cá nhân"]') ||
            document.querySelector('a[aria-label*="Profile"]') ||
            document.querySelector('[aria-label*="Trang cá nhân của "]') ||
            document.querySelector('[aria-label*="Profile of "]');

          if (profileLink) {
            const rawLabel = profileLink.getAttribute('aria-label');
            if (rawLabel) {
              const cleanName = rawLabel
                .replace('Trang cá nhân của ', '')
                .replace('Profile of ', '')
                .replace('Trang cá nhân: ', '')
                .replace('Trang cá nhân', '')
                .replace('Profile: ', '')
                .trim();
              if (cleanName && cleanName !== 'Trang cá nhân' && cleanName !== 'Profile' && cleanName.toLowerCase() !== 'bạn') {
                userName = cleanName;
              }
            }
          }
        }

        // Strategy B2: Try to get from avatar alt or menu aria-label (extremely robust fallback for business pages!)
        if (!userName) {
          const img = document.querySelector('img[alt*="Ảnh đại diện của "], img[alt*="Profile picture of "]');
          if (img) {
            const alt = img.getAttribute('alt');
            const cleanName = alt.replace('Ảnh đại diện của ', '').replace('Profile picture of ', '').trim();
            if (cleanName && cleanName.toLowerCase() !== 'bạn') {
              userName = cleanName;
            }
          }
        }
        if (!userName) {
          const menuBtn = document.querySelector('[aria-label*="Menu tài khoản của "], [aria-label*="Account menu for "]');
          if (menuBtn) {
            const label = menuBtn.getAttribute('aria-label');
            const cleanName = label.replace('Menu tài khoản của ', '').replace('Account menu for ', '').trim();
            if (cleanName && cleanName.toLowerCase() !== 'bạn') {
              userName = cleanName;
            }
          }
        }

        // Strategy C: Left sidebar links fallback
        if (!userName) {
          const leftSideBarLink = document.querySelector('div[role="navigation"] a[href^="https://www.facebook.com/me/"] span') ||
            document.querySelector('div[role="navigation"] a[href*="/profile.php"] span') ||
            document.querySelector('a[href*="/me/"] span') ||
            document.querySelector('a[href*="facebook.com/profile.php"] span');
          if (leftSideBarLink && leftSideBarLink.textContent) {
            userName = leftSideBarLink.textContent.trim();
          }
        }

        // Strategy D: Fallback to Page Title if on /me
        if (!userName && (window.location.pathname.includes('/me') || window.location.pathname.includes('/profile.php'))) {
          userName = document.title.replace(' | Facebook', '').trim();
        }

        const isProfileImage = (url) => {
          return url && url.includes('fbcdn.net') && !url.includes('static.') && !url.includes('/rsrc.php') && !url.includes('emoji');
        };

        const svgImages = document.querySelectorAll('image');
        for (const img of svgImages) {
          const href = img.getAttribute('xlink:href') || img.getAttribute('href');
          if (isProfileImage(href)) {
            userAvatar = href;
            break;
          }
        }

        if (!userAvatar) {
          const accountAreas = document.querySelectorAll('[aria-label*="Account"], [aria-label*="Tài khoản"], [data-pagelet*="ProfileTilesFeed"], nav, header, [role="banner"]');
          for (const area of accountAreas) {
            const imgs = area.querySelectorAll('img');
            for (const img of imgs) {
              if (isProfileImage(img.src) && img.width >= 28 && img.width <= 100) {
                userAvatar = img.src;
                break;
              }
            }
            if (userAvatar) break;
          }
        }

        // Extra Fallback Strategy: Scan all document images for a suitable avatar size
        if (!userAvatar) {
          const allImgs = document.querySelectorAll('img');
          for (const img of allImgs) {
            if (isProfileImage(img.src)) {
              const w = img.width || img.naturalWidth;
              if (w >= 28 && w <= 96) {
                userAvatar = img.src;
                break;
              }
            }
          }
        }

        if (userName && (userName.toLowerCase() === 'bạn' || userName.toLowerCase() === 'trang cá nhân của bạn')) {
          userName = 'Facebook User';
        }

        // Final Fallback: ui-avatars with exact matched profile initials
        if (!userAvatar && userName) {
          userAvatar = `https://ui-avatars.com/api/?name=${encodeURIComponent(userName || 'FB')}&background=3b82f6&color=fff&size=100&bold=true&rounded=true`;
        }

        return { userId, userName: userName || 'Facebook User', userAvatar, dtsg, lsd };
      } catch (e) {
        return null;
      }
    }
  });
  return result[0]?.result;
}

// ========================================
// Group Extraction (FBTool 2 approach - simple & reliable)
// ========================================
async function getActivePageCookieId() {
  try {
    const cookie = await chrome.cookies.get({ url: 'https://www.facebook.com', name: 'i_user' });
    return cookie && cookie.value ? String(cookie.value).trim() : null;
  } catch (e) {
    return null;
  }
}

function extractGroupConnectionFromGraphQL(response) {
  if (!response || typeof response !== 'object') return null;

  const viewer = response.data?.viewer;
  if (viewer?.all_joined_groups?.tab_groups_list?.edges) {
    return {
      edges: viewer.all_joined_groups.tab_groups_list.edges,
      pageInfo: viewer.all_joined_groups.tab_groups_list.page_info || {},
      totalCount: viewer.all_joined_groups.total_joined_groups || null
    };
  }
  if (viewer?.groups_tab?.tab_groups_list?.edges) {
    return {
      edges: viewer.groups_tab.tab_groups_list.edges,
      pageInfo: viewer.groups_tab.tab_groups_list.page_info || {},
      totalCount: viewer.groups_tab.total_joined_groups || null
    };
  }
  if (viewer?.all_joined_groups?.edges) {
    return {
      edges: viewer.all_joined_groups.edges,
      pageInfo: viewer.all_joined_groups.page_info || {},
      totalCount: viewer.all_joined_groups.total_joined_groups || null
    };
  }

  const visited = new Set();
  const walk = (obj, depth = 0) => {
    if (!obj || typeof obj !== 'object' || depth > 8 || visited.has(obj)) return null;
    visited.add(obj);
    if (Array.isArray(obj.edges) && obj.edges.length > 0) {
      const hasGroup = obj.edges.some((e) => {
        const n = e && e.node;
        return n && n.id && n.name && (n.__typename === 'Group' || (typeof n.url === 'string' && n.url.includes('/groups/')));
      });
      if (hasGroup) {
        return {
          edges: obj.edges,
          pageInfo: obj.page_info || {},
          totalCount: obj.count || obj.total_joined_groups || null
        };
      }
    }
    for (const val of Object.values(obj)) {
      if (val && typeof val === 'object') {
        const found = walk(val, depth + 1);
        if (found) return found;
      }
    }
    return null;
  };
  return walk(response.data || response);
}

async function scanGroupsViaDOM(uiTabId, seenIds, options = {}) {
  let scanTabId = null;
  let totalAdded = 0;

  const targetUrls = [
    'https://www.facebook.com/groups/joins/?nav_source=tab',
    'https://m.facebook.com/groups/?seemore',
    'https://mbasic.facebook.com/groups/?seemore',
    'https://www.facebook.com/groups/feed/'
  ];

  const emitGroups = (candidates) => {
    if (!Array.isArray(candidates) || candidates.length === 0) return 0;
    const batch = [];
    for (const g of candidates) {
      if (!g || !g.id || !g.name) continue;
      const cleanId = String(g.id).trim();
      const cleanName = String(g.name)
        .replace(/\uFFFD/g, '')
        .replace(/\s+/g, ' ')
        .trim();
      if (!cleanId || !cleanName || cleanName.length < 2) continue;
      if (seenIds.has(cleanId)) continue;
      seenIds.add(cleanId);
      batch.push({
        id: cleanId,
        name: cleanName,
        url: g.url && g.url.includes('facebook.com/groups/') ? g.url : `https://www.facebook.com/groups/${cleanId}`,
        image: g.image || null,
        last_visited: g.last_visited || null
      });
    }
    if (batch.length > 0) {
      sendMessage(uiTabId, 'group_data', batch);
      totalAdded += batch.length;
      sendMessage(uiTabId, 'status_update', `📋 Đã quét được ${seenIds.size} nhóm...`);
    }
    return batch.length;
  };

  try {
    sendMessage(uiTabId, 'status_update', '🌐 Đang quét danh sách nhóm trực tiếp từ Facebook (hỗ trợ cả Trang/Page & Cá nhân)...');
    const createdTab = await chrome.tabs.create({ url: targetUrls[0], active: false });
    scanTabId = createdTab.id;

    for (let uIdx = 0; uIdx < targetUrls.length && isExtracting; uIdx++) {
      const targetUrl = targetUrls[uIdx];
      if (uIdx > 0) {
        if (totalAdded > 0) break;
        sendMessage(uiTabId, 'status_update', '🔄 Đang thử quét từ mục Nhóm đã tham gia trên thanh bên...');
        await chrome.tabs.update(scanTabId, { url: targetUrl });
      }

      await waitForPageLoad(scanTabId, 12000);
      await delay(2200);
      if (!isExtracting) break;

      try {
        await chrome.scripting.executeScript({
          target: { tabId: scanTabId },
          world: 'MAIN',
          func: () => {
            if (window.__FB_GROUP_SNIFFER_ACTIVE) return;
            window.__FB_GROUP_SNIFFER_ACTIVE = true;
            window.__FB_SNIFFED_GROUPS = window.__FB_SNIFFED_GROUPS || [];

            const extractFromPayload = (text) => {
              if (!text || typeof text !== 'string') return;
              if (!text.includes('"Group"') && !text.includes('/groups/')) return;
              const chunks = text.split('\n').filter(Boolean);
              for (const chunk of chunks) {
                const cleaned = chunk.replace(/^for\s*\(;;\);\s*/, '').trim();
                if (!cleaned.startsWith('{')) continue;
                try {
                  const json = JSON.parse(cleaned);
                  const stack = [json];
                  const visited = new Set();
                  while (stack.length > 0) {
                    const cur = stack.pop();
                    if (!cur || typeof cur !== 'object' || visited.has(cur)) continue;
                    visited.add(cur);
                    if (
                      cur.__typename === 'Group' &&
                      cur.id &&
                      cur.name &&
                      typeof cur.name === 'string' &&
                      (cur.url?.includes('/groups/') || /^\d+$/.test(String(cur.id)))
                    ) {
                      window.__FB_SNIFFED_GROUPS.push({
                        id: String(cur.id),
                        name: cur.name,
                        url: cur.url || `https://www.facebook.com/groups/${cur.id}`,
                        image: cur.profile_picture?.uri || cur.cover_photo?.photo?.image?.uri || null
                      });
                    }
                    if (Array.isArray(cur)) {
                      for (let i = 0; i < cur.length; i++) stack.push(cur[i]);
                    } else {
                      const vals = Object.values(cur);
                      for (let i = 0; i < vals.length; i++) {
                        if (vals[i] && typeof vals[i] === 'object') stack.push(vals[i]);
                      }
                    }
                  }
                } catch (e) {}
              }
            };

            const origFetch = window.fetch;
            window.fetch = async function (...args) {
              const res = await origFetch.apply(this, args);
              try {
                const url = typeof args[0] === 'string' ? args[0] : (args[0]?.url || '');
                if (url.includes('/api/graphql')) {
                  res.clone().text().then(extractFromPayload).catch(() => {});
                }
              } catch (e) {}
              return res;
            };

            const origOpen = XMLHttpRequest.prototype.open;
            const origSend = XMLHttpRequest.prototype.send;
            XMLHttpRequest.prototype.open = function (method, url) {
              this.__fbUrl = typeof url === 'string' ? url : '';
              return origOpen.apply(this, arguments);
            };
            XMLHttpRequest.prototype.send = function () {
              this.addEventListener('load', function () {
                try {
                  if (this.__fbUrl && this.__fbUrl.includes('/api/graphql') && typeof this.responseText === 'string') {
                    extractFromPayload(this.responseText);
                  }
                } catch (e) {}
              });
              return origSend.apply(this, arguments);
            };
          }
        });
      } catch (e) {
        console.warn('[scanGroupsViaDOM] Sniffer inject warning:', e);
      }

      if (uIdx === 1) {
        try {
          await chrome.scripting.executeScript({
            target: { tabId: scanTabId },
            world: 'MAIN',
            func: () => {
              const links = Array.from(document.querySelectorAll('a, [role="button"]'));
              for (const el of links) {
                const txt = (el.innerText || el.getAttribute('aria-label') || '').trim().toLowerCase();
                if (txt === 'xem tất cả' || txt === 'see all' || txt === 'xem thêm') {
                  try { el.click(); } catch (e) {}
                }
              }
            }
          });
          await delay(1500);
        } catch (e) {}
      }

      let idleRounds = 0;
      const maxScrollRounds = 45;

      for (let round = 0; round < maxScrollRounds && isExtracting; round++) {
        let extracted = [];
        try {
          const res = await chrome.scripting.executeScript({
            target: { tabId: scanTabId },
            world: 'MAIN',
            args: [round === 0],
            func: (includeSsrScripts) => {
              const results = [];
              const localSeen = new Set();
              const RESERVED = new Set([
                'feed', 'discover', 'joins', 'create', 'notifications', 'search',
                'your_groups', 'pending', 'categories', 'explore', 'requests', 'settings',
                'posts', 'permalink', 'members', 'about', 'events', 'media', 'files', 'admin'
              ]);

              const pushGroup = (g) => {
                if (!g || !g.id || !g.name) return;
                const id = String(g.id).trim();
                const name = String(g.name).replace(/\uFFFD/g, '').replace(/\s+/g, ' ').trim();
                if (!id || !name || name.length < 2) return;
                if (RESERVED.has(id.toLowerCase())) return;
                if (/^(xem nhóm|view group|tham gia|join|truy cập|visit|đã tham gia|joined|tạo nhóm|create group|khám phá|discover|bảng feed|your feed|nhóm của bạn|your groups)$/i.test(name)) {
                  return;
                }
                if (localSeen.has(id)) return;
                localSeen.add(id);
                results.push({
                  id,
                  name,
                  url: g.url || `https://www.facebook.com/groups/${id}`,
                  image: g.image || null
                });
              };

              if (Array.isArray(window.__FB_SNIFFED_GROUPS) && window.__FB_SNIFFED_GROUPS.length > 0) {
                while (window.__FB_SNIFFED_GROUPS.length > 0) {
                  pushGroup(window.__FB_SNIFFED_GROUPS.shift());
                }
              }

              if (includeSsrScripts) {
                const scripts = document.querySelectorAll('script[type="application/json"]');
                for (const s of scripts) {
                  const txt = s.textContent || '';
                  if (!txt.includes('"Group"') && !txt.includes('all_joined_groups') && !txt.includes('tab_groups_list')) continue;
                  try {
                    const parsed = JSON.parse(txt);
                    const stack = [parsed];
                    const visited = new Set();
                    while (stack.length > 0) {
                      const cur = stack.pop();
                      if (!cur || typeof cur !== 'object' || visited.has(cur)) continue;
                      visited.add(cur);
                      if (
                        cur.__typename === 'Group' &&
                        cur.id &&
                        cur.name &&
                        typeof cur.name === 'string' &&
                        (cur.url?.includes('/groups/') || /^\d+$/.test(String(cur.id)))
                      ) {
                        pushGroup({
                          id: String(cur.id),
                          name: cur.name,
                          url: cur.url || `https://www.facebook.com/groups/${cur.id}`,
                          image: cur.profile_picture?.uri || null
                        });
                      }
                      if (Array.isArray(cur)) {
                        for (let i = 0; i < cur.length; i++) stack.push(cur[i]);
                      } else {
                        const vals = Object.values(cur);
                        for (let i = 0; i < vals.length; i++) {
                          if (vals[i] && typeof vals[i] === 'object') stack.push(vals[i]);
                        }
                      }
                    }
                  } catch (e) {}
                }
              }

              const scopeRoot = document.querySelector('[role="main"]') || document.body;
              const anchors = Array.from(document.querySelectorAll('a[href*="/groups/"]'));
              for (const a of anchors) {
                const href = a.getAttribute('href') || '';
                const m = href.match(/\/groups\/([^/?#]+)/i);
                if (!m || !m[1]) continue;
                const slug = m[1].trim();
                if (!slug || RESERVED.has(slug.toLowerCase())) continue;
                if (/\/groups\/[^/?#]+\/(posts|permalink|user|members|media|files|events|about|search|pending|my_)/i.test(href)) {
                  continue;
                }

                let name = '';
                const rawLines = (a.innerText || '')
                  .split('\n')
                  .map((l) => l.trim())
                  .filter((l) => l.length > 1 && !/^(hoạt động|last active|thành viên|members|công khai|public|riêng tư|private|xem nhóm|view group|\d+\s*(bài viết|posts|thành viên|members))/i.test(l));
                if (rawLines.length > 0) {
                  name = rawLines[0];
                }
                if (!name) {
                  const aria = (a.getAttribute('aria-label') || '').trim();
                  if (aria && !/^(xem nhóm|view group|tùy chọn|more options)/i.test(aria)) {
                    name = aria;
                  }
                }
                if (!name) continue;

                let img = null;
                const container = a.closest('[role="listitem"], [role="article"], div.x1yztbdb, div[class*="x1n2onr6"]') || a.parentElement;
                if (container) {
                  const imgEl = container.querySelector('img[src*="fbcdn"], image');
                  if (imgEl) {
                    img = imgEl.getAttribute('src') || imgEl.getAttribute('xlink:href') || null;
                  }
                }

                if (scopeRoot.contains(a) || a.closest('[role="navigation"]')) {
                  pushGroup({
                    id: slug,
                    name,
                    url: `https://www.facebook.com/groups/${slug}`,
                    image: img
                  });
                }
              }

              window.scrollBy(0, Math.max(window.innerHeight * 0.9, 900));
              const scrollables = Array.from(document.querySelectorAll('[role="main"], [role="navigation"], div')).filter((el) => {
                if (el.scrollHeight <= el.clientHeight + 120) return false;
                const st = window.getComputedStyle(el);
                return st.overflowY === 'auto' || st.overflowY === 'scroll';
              });
              for (const sc of scrollables.slice(0, 4)) {
                sc.scrollTop = sc.scrollTop + Math.max(sc.clientHeight * 0.85, 700);
              }

              return results;
            }
          });
          extracted = res[0]?.result || [];
        } catch (e) {
          console.warn('[scanGroupsViaDOM] Round error:', e);
        }

        const addedThisRound = emitGroups(extracted);
        if (addedThisRound > 0) {
          idleRounds = 0;
        } else {
          idleRounds++;
        }

        if (idleRounds >= 4) {
          break;
        }
        await delay(1400);
      }
    }
  } finally {
    if (scanTabId) {
      try { await chrome.tabs.remove(scanTabId); } catch (e) {}
    }
  }

  return totalAdded;
}

async function startExtraction(uiTabId, options = {}) {
  let fbTabId = null;
  let isTempTab = false;
  try {
    sendMessage(uiTabId, 'status_update', '🔍 Đang kết nối Facebook để quét danh sách nhóm...');
    const fbCookies = await getFbCookies();
    if (!fbCookies || !fbCookies.cUser) {
      throw new Error('Chưa phát hiện phiên đăng nhập Facebook trên trình duyệt này. Vui lòng mở facebook.com hoặc m.facebook.com, đăng nhập tài khoản rồi quay lại bấm Quét nhóm.');
    }
    const connection = await getTokensResilient(uiTabId);
    if (!connection) {
      sendMessage(uiTabId, 'status_update', '📱 Đang chuyển sang chế độ quét nhóm trực tiếp cho trình duyệt di động...');
      const seenFallback = new Set();
      let mobileCount = await scanGroupsViaMobileHtml(uiTabId, seenFallback);
      if (mobileCount === 0 && isExtracting) {
        mobileCount += await scanGroupsViaDOM(uiTabId, seenFallback, options);
      }
      isExtracting = false;
      if (mobileCount > 0) {
        sendMessage(uiTabId, 'complete', { total: mobileCount, isPageContext: false });
        return;
      }
      throw new Error('Không lấy được token hoặc danh sách nhóm Facebook trên trình duyệt di động. Vui lòng mở m.facebook.com trong 1 tab mới, tải lại trang Facebook rồi thử Quét nhóm lại.');
    }
    fbTabId = connection.tabId;
    const tokens = connection.tokens;
    isTempTab = connection.isTemp;

    const cookiePageId = await getActivePageCookieId();
    const requestedPageId = options && options.pageId ? String(options.pageId).trim() : null;
    const activeActorId = requestedPageId || cookiePageId || tokens.actorId || tokens.userId;
    const isPageContext = Boolean(
      requestedPageId ||
      (cookiePageId && tokens.userId && String(cookiePageId) !== String(tokens.userId)) ||
      tokens.isPageProfile
    );

    if (isPageContext) {
      const label = options?.pageName ? `"${options.pageName}"` : `ID ${activeActorId}`;
      sendMessage(uiTabId, 'status_update', `🏳️ Phát hiện chế độ Trang (${label}). Đang quét các nhóm mà Trang đã tham gia...`);
    } else {
      sendMessage(uiTabId, 'status_update', '✅ Đã kết nối Facebook. Đang lấy danh sách nhóm...');
    }

    const scanTokens = {
      ...tokens,
      actorId: activeActorId
    };

    let rootDocId = DOC_ID;
    let paginationDocId = PAGINATION_DOC_ID;
    if (fbTabId) {
      try {
        const dynamicIds = await getGroupScanDocIds(fbTabId);
        if (dynamicIds?.rootDocId) rootDocId = dynamicIds.rootDocId;
        if (dynamicIds?.paginationDocId) paginationDocId = dynamicIds.paginationDocId;
      } catch (e) {
        console.warn('[startExtraction] Dynamic doc_id discovery skipped:', e);
      }
    }

    let cursor = null;
    let hasNextPage = true;
    let count = 0;
    const seenIds = new Set();
    let graphqlFailed = false;

    try {
      while (hasNextPage && isExtracting) {
        const variables = {
          ordering: ["viewer_added"],
          scale: 1,
          count: 15
        };

        if (cursor) {
          variables.cursor = cursor;
        }

        const currentDocId = cursor ? paginationDocId : rootDocId;
        const currentFriendlyName = cursor
          ? 'GroupsCometAllJoinedGroupsSectionPaginationQuery'
          : 'GroupsCometJoinsRootQuery';

        const responseText = await fetchGraphQLInTab(fbTabId, scanTokens, variables, currentDocId, currentFriendlyName);
        if (!responseText) {
          graphqlFailed = true;
          break;
        }

        const response = parseResponse(responseText);
        if (response && response.errorSummary) {
          console.warn('[startExtraction] GraphQL errorSummary:', response.errorSummary, response.errorDescription);
          graphqlFailed = true;
          break;
        }

        const conn = extractGroupConnectionFromGraphQL(response);
        if (!conn || !Array.isArray(conn.edges)) {
          console.warn('[startExtraction] GraphQL returned unexpected structure (common on Page profiles) — switching to DOM scanner.');
          graphqlFailed = true;
          break;
        }

        if (conn.totalCount) {
          sendMessage(uiTabId, 'total_count', conn.totalCount);
        }

        if (conn.edges.length > 0) {
          const newGroups = [];
          conn.edges.forEach(edge => {
            const node = edge && edge.node;
            if (node && node.id && node.name && !seenIds.has(String(node.id))) {
              seenIds.add(String(node.id));
              newGroups.push({
                id: String(node.id),
                name: String(node.name).replace(/\uFFFD/g, '').trim(),
                url: node.url || `https://www.facebook.com/groups/${node.id}`,
                image: node.profile_picture?.uri || null,
                last_visited: node.viewer_last_visited_time || null
              });
            }
          });

          if (newGroups.length > 0) {
            sendMessage(uiTabId, 'group_data', newGroups);
            count += newGroups.length;
            sendMessage(uiTabId, 'status_update', `📋 Đã quét được ${count} nhóm...`);
          }
        }

        const pageInfo = conn.pageInfo || {};
        if (!pageInfo.has_next_page || !pageInfo.end_cursor) {
          hasNextPage = false;
        } else if (cursor === pageInfo.end_cursor) {
          hasNextPage = false;
        } else {
          hasNextPage = true;
          cursor = pageInfo.end_cursor;
        }

        if (hasNextPage && isExtracting) {
          const waitMs = Math.floor(Math.random() * 1500) + 1200;
          await new Promise(resolve => setTimeout(resolve, waitMs));
        }
      }
    } catch (gqlErr) {
      console.warn('[startExtraction] GraphQL tier failed, falling back to DOM scanner:', gqlErr);
      graphqlFailed = true;
    }

    if (isExtracting && (count === 0 || graphqlFailed)) {
      if (requestedPageId && cookiePageId && String(requestedPageId) !== String(cookiePageId)) {
        sendMessage(
          uiTabId,
          'status_update',
          'ℹ️ Mẹo: Trên tab Facebook hiện đang ở trang khác. Hãy chuyển sang tư cách Trang bạn muốn quét trên Facebook nếu danh sách chưa đúng.'
        );
      } else if (requestedPageId && !cookiePageId) {
        sendMessage(
          uiTabId,
          'status_update',
          'ℹ️ Lưu ý: Tab Facebook đang ở tài khoản cá nhân. Để quét đúng nhóm của Trang, hãy bấm ảnh đại diện góc phải trên Facebook và chuyển sang Trang trước khi quét!'
        );
      }
      if (!isPageContext) {
        const mobileHtmlAdded = await scanGroupsViaMobileHtml(uiTabId, seenIds);
        count += mobileHtmlAdded;
      }
      if (isExtracting && count === 0) {
        const domAdded = await scanGroupsViaDOM(uiTabId, seenIds, options);
        count += domAdded;
      }
    }

    isExtracting = false;
    if (count > 0) {
      sendMessage(uiTabId, 'complete', { total: count, isPageContext });
    } else {
      const hint = isPageContext
        ? 'Không tìm thấy nhóm nào của Trang này. Hãy đảm bảo trên tab Facebook bạn đã chuyển sang tư cách Trang (bấm Avatar góc phải → Chọn Trang) và Trang đó đã tham gia ít nhất 1 nhóm.'
        : 'Không tìm thấy nhóm nào. Hãy mở Facebook trên trình duyệt, kiểm tra mục Nhóm bạn đã tham gia rồi thử quét lại.';
      sendMessage(uiTabId, 'error', hint);
    }

  } catch (error) {
    isExtracting = false;
    sendMessage(uiTabId, 'error', error.message);
  } finally {
    if (isTempTab && fbTabId) {
      try { await chrome.tabs.remove(fbTabId); } catch(e) {}
    }
  }
}

// ========================================
// Trigger Doc ID Capture - Navigate and click composer to capture doc_id
// ========================================
async function triggerDocIdCapture(tabId, groupUrl) {
  try {
    console.log('[DocID] Triggering capture via composer click...');

    // Navigate to group first
    await chrome.tabs.update(tabId, { url: groupUrl });
    await new Promise(r => setTimeout(r, 5000)); // Wait for page load

    // Setup interception
    await setupDocIdInterception(tabId);

    // Click on composer to trigger GraphQL requests
    const result = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      world: 'MAIN',
      func: async () => {
        const sleep = ms => new Promise(r => setTimeout(r, ms));

        // Find and click composer
        const composerSelectors = [
          'div[role="button"][tabindex="0"][class*="x1i10hfl"]', // General FB button
          'span[data-lexical-text="true"]', // Lexical composer
          'div[contenteditable="true"][role="textbox"]',
          'div[aria-label*="Write something"]',
          'div[aria-label*="Viết gì đó"]',
          'div[data-testid="composer-box"]',
          'div[class*="x6s0dn4"][tabindex="0"]'
        ];

        for (const sel of composerSelectors) {
          const el = document.querySelector(sel);
          if (el) {
            console.log('[DocID] Found composer element:', sel);
            el.scrollIntoView({ block: 'center' });
            await sleep(500);
            el.click();
            console.log('[DocID] Clicked composer');

            // Wait for any API calls to be made
            await sleep(2000);

            // Close any opened dialog by pressing Escape
            document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
            await sleep(500);

            return { success: true, selector: sel };
          }
        }

        return { success: false, message: 'Composer not found' };
      }
    });

    console.log('[DocID] Trigger result:', result[0]?.result);
    return result[0]?.result?.success || false;

  } catch (e) {
    console.error('[DocID] Trigger error:', e);
    return false;
  }
}

// ========================================
// Post to Group (Main Controller) - Pure GraphQL API via doc_id
// ========================================
const DESKTOP_CHROME_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

async function setDesktopUserAgentForTab(tabId) {
  if (!tabId || !chrome.declarativeNetRequest || !chrome.declarativeNetRequest.updateSessionRules) {
    return null;
  }
  const ruleId = 50000 + (Math.abs(Number(tabId) || 1) % 40000);
  try {
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [ruleId],
      addRules: [
        {
          id: ruleId,
          priority: 1,
          action: {
            type: 'modifyHeaders',
            requestHeaders: [
              { header: 'User-Agent', operation: 'set', value: DESKTOP_CHROME_UA },
              { header: 'Sec-CH-UA-Mobile', operation: 'set', value: '?0' },
              { header: 'Sec-CH-UA-Platform', operation: 'set', value: '"Windows"' },
              { header: 'Sec-CH-UA', operation: 'set', value: '"Chromium";v="131", "Not_A Brand";v="24", "Google Chrome";v="131"' }
            ]
          },
          condition: {
            requestDomains: ['facebook.com'],
            tabIds: [tabId],
            resourceTypes: ['main_frame', 'sub_frame', 'xmlhttprequest', 'script', 'other']
          }
        }
      ]
    });
    return ruleId;
  } catch (e) {
    console.warn('[DNR] Failed to apply desktop UA rule for tab:', e);
    return null;
  }
}

async function clearDesktopUserAgentRule(ruleId) {
  if (!ruleId || !chrome.declarativeNetRequest || !chrome.declarativeNetRequest.updateSessionRules) return;
  try {
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [ruleId]
    });
  } catch (_) {}
}

async function postToGroup(uiTabId, data) {
  let isSuccessfulWithLink = false;
  let tempWorkTabId = null;
  let isVisibleMode = false;
  let desktopUaRuleId = null;
  try {
    let { groupId, groupUrl, content, images, postMode } = data;

    // Retrieve images from storage if content.js passed them via storage
    if (images === 'USE_STORAGE') {
      const storedData = await chrome.storage.local.get('temp_post_images');
      images = storedData.temp_post_images || [];
      // Clean up storage immediately
      await chrome.storage.local.remove('temp_post_images');
    }

    // Anti-block: Check rate limit
    if (!checkRateLimit()) {
      sendMessage(uiTabId, 'RATE_LIMIT_REACHED', {
        message: `⚠️ Đã đạt giới hạn ${MAX_POSTS_PER_HOUR} bài/giờ. Vui lòng đợi.`,
        postsThisHour: postCountThisHour
      });
      throw new Error(`Rate limit: ${postCountThisHour}/${MAX_POSTS_PER_HOUR} bài/giờ`);
    }

    const imageCount = Array.isArray(images) ? images.length : 0;
    const isMobileBrowser = /Android|Mobile|iPhone|iPad/i.test((typeof navigator !== 'undefined' && navigator.userAgent) ? navigator.userAgent : '');
    const isMobileMode = postMode === 'mobile';
    isVisibleMode = postMode === 'desktop_visible' || isMobileBrowser;
    const isSilentMode = !isVisibleMode;

    // Convert blob URLs to Base64 Data URLs to bypass Cross-Origin restrictions in the Facebook tab
    const base64Images = [];
    if (images && images.length > 0) {
        for (const url of images) {
            try {
                if (typeof url === 'string' && url.startsWith('data:')) {
                    base64Images.push(url);
                    continue;
                }
                const res = await fetch(url);
                const blob = await res.blob();
                const reader = new FileReader();
                const b64 = await new Promise(r => {
                    reader.onloadend = () => r(reader.result);
                    reader.readAsDataURL(blob);
                });
                base64Images.push(b64);
            } catch(e) {
                console.error('Failed to convert image to base64:', url, e);
            }
        }
    }

    // On Android mobile browsers (Lemur/Kiwi/Mises), spoof Desktop Chrome UA ONLY on this worker tab
    // so Facebook serves the battle-tested Desktop Comet composer instead of broken mobile Bloks UI!
    let usingDesktopSpoof = false;
    let useMobileUrl = isMobileMode && !isMobileBrowser;

    if (isMobileBrowser) {
      const blankTab = await chrome.tabs.create({
        url: 'about:blank',
        active: isVisibleMode
      });
      tempWorkTabId = blankTab.id;
      desktopUaRuleId = await setDesktopUserAgentForTab(tempWorkTabId);
      usingDesktopSpoof = Boolean(desktopUaRuleId);
      useMobileUrl = !usingDesktopSpoof;
    }

    const targetGroupUrl = useMobileUrl
      ? `https://m.facebook.com/groups/${groupId}`
      : `https://www.facebook.com/groups/${groupId}`;

    sendMessage(uiTabId, 'STATUS_UPDATE', {
      message: isMobileBrowser
        ? (usingDesktopSpoof
            ? `📱 Mở tab Facebook chế độ máy tính để đăng ổn định | Nội dung: ${content.length} ký tự | Ảnh: ${imageCount}`
            : `📱 Mở tab Facebook di động để đăng bài | Nội dung: ${content.length} ký tự | Ảnh: ${imageCount}`)
        : isSilentMode
          ? `🕶️ Mở tab ngầm đăng bài (không chiếm màn hình) | Nội dung: ${content.length} ký tự | Ảnh: ${imageCount}`
          : `🚀 Đăng bài bằng chế độ hiển thị tab | Nội dung: ${content.length} ký tự | Ảnh: ${imageCount}`
    });

    if (isMobileBrowser && tempWorkTabId) {
      await chrome.tabs.update(tempWorkTabId, {
        url: targetGroupUrl,
        active: isVisibleMode
      });
    } else {
      const createdTab = await chrome.tabs.create({
        url: targetGroupUrl,
        active: isVisibleMode
      });
      tempWorkTabId = createdTab.id;
    }

    try {
      await postViaDOMAutomation(uiTabId, tempWorkTabId, groupId, content, base64Images, {
        silent: isSilentMode,
        alreadyNavigated: true,
        mobileMode: useMobileUrl
      });
      isSuccessfulWithLink = true;
    } catch (apiError) {
      console.error('[DOMAuto] Error:', apiError);

      // Retry once on the alternate host (if Desktop spoof failed on mobile, clear DNR rule and try m.facebook.com!)
      if (desktopUaRuleId) {
        await clearDesktopUserAgentRule(desktopUaRuleId);
        desktopUaRuleId = null;
      }
      const altIsMobile = !useMobileUrl;
      const altUrl = altIsMobile
        ? `https://m.facebook.com/groups/${groupId}`
        : `https://www.facebook.com/groups/${groupId}`;
      let retrySucceeded = false;
      try {
        sendMessage(uiTabId, 'STATUS_UPDATE', { message: `🔄 Đang thử lại qua giao diện Facebook dự phòng...` });
        await chrome.tabs.update(tempWorkTabId, { url: altUrl, active: isVisibleMode });
        await postViaDOMAutomation(uiTabId, tempWorkTabId, groupId, content, base64Images, {
          silent: isSilentMode,
          alreadyNavigated: true,
          mobileMode: altIsMobile
        });
        retrySucceeded = true;
        isSuccessfulWithLink = true;
      } catch (retryErr) {
        console.warn('[DOMAuto] Alternate host retry failed:', retryErr);
      }

      if (!retrySucceeded) {
        if (imageCount === 0) {
          try {
            sendMessage(uiTabId, 'STATUS_UPDATE', { message: `⚠️ Đang thử gửi dự phòng qua Mbasic...` });
            await postViaMbasic(uiTabId, tempWorkTabId, groupId, content, []);
            isSuccessfulWithLink = true;
          } catch (mbasicErr) {
            // Surface the clear DOM error rather than obsolete mbasic error
            throw apiError;
          }
        } else {
          throw apiError;
        }
      }
    }

    // Anti-block: Increment post counter on success
    postCountThisHour++;

  } catch (error) {
    console.error('[postToGroup] Error:', error);
    sendMessage(uiTabId, 'POST_ERROR', {
      groupId: data.groupId,
      message: error.message
    });
  } finally {
    if (desktopUaRuleId) {
      await clearDesktopUserAgentRule(desktopUaRuleId);
      desktopUaRuleId = null;
    }
    // Cleanly close our dedicated temporary background tab without touching any of the user's tabs or window focus
    if (tempWorkTabId) {
      try {
        await chrome.tabs.remove(tempWorkTabId);
      } catch (closeErr) {
        console.warn('[postToGroup] Failed to close temp work tab:', closeErr);
      }
    }

    // Only switch focus back to AutoPost Pro if the user explicitly enabled visible debug mode
    if (isVisibleMode) {
      try {
        if (uiTabId) {
          await chrome.tabs.update(uiTabId, { active: true });
          const uiTab = await chrome.tabs.get(uiTabId);
          if (uiTab && uiTab.windowId) {
            await chrome.windows.update(uiTab.windowId, { focused: true });
          }
        }
      } catch (uiTabErr) {
        console.error('Failed to focus UI tab in finally:', uiTabErr);
      }
    }
  }
}

// ========================================
// API Posting Logic (GraphQL + Media Upload)
// ========================================

async function postViaAPI(uiTabId, fbTabId, groupId, content, images, tokens) {
  try {
    let attachmentIds = [];

    // 1. Upload Images (if any)
    if (images && images.length > 0) {
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: `📷 Bước 1/3: Đang tải lên ${images.length} ảnh...` });

      for (let i = 0; i < images.length; i++) {
        const b64 = images[i];
        try {
          const photoId = await uploadImage(fbTabId, groupId, b64, tokens);
          if (photoId) {
            attachmentIds.push(photoId);
            sendMessage(uiTabId, 'STATUS_UPDATE', { message: `📷 Ảnh ${i + 1}/${images.length}: Đã tải lên thành công (ID: ${photoId})` });
          }
        } catch (e) {
          console.error('Upload failed:', e);
          sendMessage(uiTabId, 'ERROR', { message: 'Lỗi tải ảnh: ' + e.message });
        }
      }
    }

    // 2. Create Post via GraphQL
    sendMessage(uiTabId, 'STATUS_UPDATE', { message: '📝 Bước 2/3: Đang tạo bài viết qua GraphQL...' });

    const uuid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });

    const session_id = uuid();

    // DYNAMIC DOC ID RETRIEVAL (3-Strategy Approach)
    // Prioritize runtime doc_id to avoid hardcoded values
    let mutationDocId = null;
    try {
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: '🔑 Đang lấy mã xác thực (doc_id) từ Facebook...' });
      const dynamicId = await getCreatePostDocId(fbTabId);
      if (dynamicId) {
        console.log('[PostAPI] ✅ Using Dynamic Doc ID:', dynamicId);
        mutationDocId = dynamicId;
        sendMessage(uiTabId, 'STATUS_UPDATE', { message: `✅ Đã lấy doc_id: ${dynamicId.slice(0, 8)}...` });
      }
    } catch (e) {
      console.warn('[PostAPI] Failed to get dynamic ID:', e);
    }

    // Fallback to fbtool.net's doc_id if dynamic retrieval fails
    if (!mutationDocId) {
      console.warn('[PostAPI] ⚠️ Using fbtool.net fallback doc_id:', FBTOOL_DOC_ID);
      mutationDocId = FBTOOL_DOC_ID;
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: '⚠️ Dùng doc_id từ fbtool.net...' });
    }

    // Construct Attachments for GraphQL
    const attachments = attachmentIds.map(id => ({
      "photo": {
        "id": id,
      }
    }));

    const variables = {
      "input": {
        "composer_entry_point": "inline_composer",
        "composer_source_surface": "group",
        "composer_type": "group",
        "logging": {
          "composer_session_id": session_id
        },
        "source": "WWW_COMET_GROUP_DISCUSSION",
        "message": {
          "ranges": [],
          "text": content.replace(/\r\n/g, '\n').replace(/\r/g, '\n') // Normalize to LF only
        },
        "attachments": attachments.length > 0 ? attachments : null,
        "with_tags_ids": [],
        "inline_activities": [],
        "explicit_place_id": "0",
        "text_format_preset_id": "0",
        "tracking": [null],
        "audience": {
          "to_entity": {
            "id": groupId
          }
        },
        "actor_id": tokens.userId,
        "client_mutation_id": Math.floor(Math.random() * 1000000).toString()
      },
      "displayCommentsFeedbackContext": null,
      "displayCommentsContextEnableComment": null,
      "displayCommentsContextIsAd": null,
      "displayCommentsContextIsAggregatedShare": null,
      "displayCommentsContextIsStorySet": null,
      "feedLocation": "GROUP",
      "feedbackSource": 0,
      "focusCommentID": null,
      "gridMediaAsSizedImage": null,
      "scale": 1,
      "useDefaultActor": false,
      "UFI2CommentsProvider_commentsKey": "GroupCometComposeBoxPostMutation"
    };

    const responseText = await fetchGraphQLInTab(fbTabId, tokens, variables, mutationDocId, 'GroupCometComposeBoxPostMutation');

    if (!responseText) throw new Error('Không có phản hồi từ Server Facebook');

    // Anti-block: Check for checkpoint/captcha
    if (isCheckpoint(responseText)) {
      throw new Error('checkpoint detected - Facebook yêu cầu xác minh');
    }

    const response = parseResponse(responseText);

    // Success Check
    const postCreateResult = response && response.data && (response.data.story_create || response.data.group_post_create || response.data.group_create_post);
    
    if (postCreateResult) {
      const post = postCreateResult.post || postCreateResult.story || {};
      const postId = post.id || post.post_id || post.story_fbid || 'unknown';
      // Construct exact permalink
      const postUrl = `https://www.facebook.com/groups/${groupId}/posts/${postId}/`;

      // Cache the working doc_id for future use
      if (mutationDocId) {
        await saveDocIdToCache(mutationDocId);
      }

      sendMessage(uiTabId, 'STATUS_UPDATE', { message: `✅ Bước 3/3: Đăng bài thành công! Post ID: ${postId}` });
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: `🔗 Link bài viết: ${postUrl}` });
      sendMessage(uiTabId, 'POST_SUCCESS', { groupId, postId, postLink: postUrl });
      return;
    }

    // Error Check - clear cache as doc_id might be expired
    if (response && response.errors) {
      await clearDocIdCache(); // Doc ID might be expired
      throw new Error(response.errors[0]?.message || 'Lỗi GraphQL');
    }

    // Check for silent data null
    if (response && response.data === null) {
      console.error('GraphQL Data Null:', response);
      await clearDocIdCache(); // Doc ID might be expired
      throw new Error('Facebook từ chối yêu cầu (Data is null) - doc_id có thể hết hạn');
    }

    // Debug: Log what we received
    console.error('[PostAPI] Unexpected response structure:');
    console.error('Response text (first 500 chars):', responseText?.substring(0, 500));
    console.error('Parsed response:', JSON.stringify(response, null, 2)?.substring(0, 500));

    // Try to extract any error message from response
    let errorMsg = 'Lỗi không xác định (API Response Unknown)';
    if (!response) {
      errorMsg = `Không thể phân tích phản hồi từ Facebook: ${responseText ? responseText.substring(0, 100) : 'Rỗng'}`;
    } else if (response.errorSummary) {
      errorMsg = `${response.errorSummary} - ${response.errorDescription || ''}`;
    } else if (response.error?.message) {
      errorMsg = response.error.message;
    } else if (response.error && typeof response.error === 'object') {
      errorMsg = `Lỗi hệ thống FB: ${response.error.errorSummary || response.error.description || JSON.stringify(response.error)}`;
    } else if (response.data?.error) {
      errorMsg = response.data.error.message || JSON.stringify(response.data.error);
    } else if (typeof response === 'string') {
      errorMsg = 'Response dạng text: ' + response.substring(0, 100);
    }

    await clearDocIdCache(); // Clear cache on unknown error
    throw new Error(errorMsg);

  } catch (e) {
    throw e;
  }
}

async function uploadImage(tabId, groupId, base64Data, tokens) {
  const result = await chrome.scripting.executeScript({
    target: { tabId: tabId },
    world: 'MAIN',
    args: [groupId, base64Data, tokens],
    func: async (groupId, base64Data, tokens) => {
      try {
        // Convert Base64 to File Object
        const byteCharacters = atob(base64Data.split(',')[1]);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'image/jpeg' });
        const file = new File([blob], "image.jpg", { type: "image/jpeg" });

        const formData = new FormData();
        formData.append('source', '8');
        formData.append('profile_id', tokens.userId);
        formData.append('target_id', groupId);
        formData.append('file', file);
        formData.append('fb_dtsg', tokens.dtsg);
        formData.append('av', tokens.userId);

        // Upload Endpoint
        const response = await fetch('https://upload.facebook.com/ajax/react_composer/attachments/photo/upload', {
          method: 'POST',
          body: formData
        });

        const text = await response.text();
        // Strip protection chars
        const jsonText = text.replace('for (;;);', '');
        const json = JSON.parse(jsonText);

        return json.payload?.photoID || null;
      } catch (e) {
        console.error('Upload Error helper:', e);
        return null;
      }
    }
  });
  return result[0]?.result;
}

// ========================================
// Helper Functions
// ========================================
function sendMessage(tabId, action, data) {
  if (!tabId) return;
  try {
    chrome.tabs.sendMessage(tabId, { action, data, message: data }, () => {
      void chrome.runtime.lastError;
    });
  } catch (e) {}
}

function parseResponse(text) {
    if (!text) return null;
    try {
        let cleanText = text.trim();
        if (cleanText.startsWith('for (;;);')) {
            cleanText = cleanText.substring(9).trim();
        }
        
        const lines = cleanText.split('\n').filter(line => line.trim());
        if (lines.length > 0) {
            for (let line of lines) {
                line = line.trim();
                if (line.startsWith('for (;;);')) {
                    line = line.substring(9).trim();
                }
                try {
                    const json = JSON.parse(line);
                    if (json.data) return json;
                    if (json.errors) console.error('GraphQL Errors:', json.errors);
                    if (json.errorSummary || json.error) return json;
                } catch (e) {}
            }
            try {
                let firstLine = lines[0].trim();
                if (firstLine.startsWith('for (;;);')) {
                    firstLine = firstLine.substring(9).trim();
                }
                return JSON.parse(firstLine);
            } catch(e) {}
        }
        return JSON.parse(cleanText);
    } catch (e) {
        console.error('Parse error:', e, 'Response text preview:', text.substring(0, 300));
        return null;
    }
}

async function getFbCookies() {
  let cUser = null;
  let iUser = null;
  const urls = ['https://www.facebook.com', 'https://m.facebook.com', 'https://mbasic.facebook.com'];
  for (const url of urls) {
    try {
      if (!cUser) {
        const c = await chrome.cookies.get({ url, name: 'c_user' });
        if (c && c.value) cUser = String(c.value).trim();
      }
      if (!iUser) {
        const i = await chrome.cookies.get({ url, name: 'i_user' });
        if (i && i.value) iUser = String(i.value).trim();
      }
    } catch (e) {}
    if (cUser && iUser) break;
  }
  if (!cUser) {
    try {
      const all = await chrome.cookies.getAll({ domain: 'facebook.com' });
      for (const ck of all || []) {
        if (!cUser && ck.name === 'c_user' && ck.value) cUser = String(ck.value).trim();
        if (!iUser && ck.name === 'i_user' && ck.value) iUser = String(ck.value).trim();
      }
    } catch (e) {}
  }
  return { cUser, iUser };
}

function decodeHtmlEntitiesSimple(str) {
  return String(str || '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#0?39;/g, "'")
    .replace(/&#x27;/gi, "'")
    .replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
    .replace(/\\\//g, '/')
    .replace(/\uFFFD/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

async function scanGroupsViaMobileHtml(uiTabId, seenIds) {
  const urls = [
    'https://mbasic.facebook.com/groups/?seemore',
    'https://m.facebook.com/groups/?seemore',
    'https://m.facebook.com/groups_browse/your_groups/',
    'https://www.facebook.com/groups/joins/?nav_source=tab'
  ];
  const badNames = new Set([
    'nhóm', 'groups', 'xem thêm', 'see more', 'tạo nhóm mới', 'create new group',
    'khám phá', 'discover', 'bảng feed của bạn', 'your feed', 'trang chủ', 'home',
    'quản lý', 'manage', 'cài đặt', 'settings', 'thông báo', 'notifications',
    'nhóm của bạn', 'your groups', 'tham gia', 'join', 'đã tham gia', 'joined'
  ]);
  const badSlugs = new Set([
    'feed', 'discover', 'joins', 'create', 'notifications', 'search', 'categories',
    'browse', 'membership', 'requests', 'invites', 'manage', 'settings', 'events'
  ]);
  let totalAdded = 0;

  const emitBatch = (items) => {
    const batch = [];
    for (const g of items) {
      if (!g || !g.id || !g.name) continue;
      const cleanId = String(g.id).trim();
      const cleanName = decodeHtmlEntitiesSimple(g.name);
      if (!cleanId || badSlugs.has(cleanId.toLowerCase())) continue;
      if (!cleanName || cleanName.length < 2 || badNames.has(cleanName.toLowerCase())) continue;
      if (seenIds.has(cleanId)) continue;
      seenIds.add(cleanId);
      batch.push({
        id: cleanId,
        name: cleanName,
        url: `https://www.facebook.com/groups/${cleanId}`,
        image: g.image || null,
        last_visited: null
      });
    }
    if (batch.length > 0) {
      sendMessage(uiTabId, 'group_data', batch);
      totalAdded += batch.length;
      sendMessage(uiTabId, 'status_update', `📋 Đã quét được ${seenIds.size} nhóm (chế độ mobile)...`);
    }
  };

  for (const url of urls) {
    if (!isExtracting) break;
    try {
      const res = await fetch(url, {
        credentials: 'include',
        headers: {
          'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'cache-control': 'no-cache'
        }
      });
      if (!res.ok) continue;
      const html = await res.text();
      if (!html || html.length < 300) continue;

      const found = [];

      // 1. Parse embedded JSON Group objects (modern m.facebook.com & www.facebook.com)
      const jsonGroupRe = /"__typename"\s*:\s*"Group"[^{}]{0,400}?"id"\s*:\s*"(\d{5,})"[^{}]{0,400}?"name"\s*:\s*"([^"\\]{2,180}(?:\\.[^"\\]*)*)"/g;
      let m;
      while ((m = jsonGroupRe.exec(html)) !== null) {
        found.push({ id: m[1], name: m[2] });
      }
      const jsonGroupRevRe = /"id"\s*:\s*"(\d{5,})"[^{}]{0,250}?"name"\s*:\s*"([^"\\]{2,180}(?:\\.[^"\\]*)*)"[^{}]{0,350}?"__typename"\s*:\s*"Group"/g;
      while ((m = jsonGroupRevRe.exec(html)) !== null) {
        found.push({ id: m[1], name: m[2] });
      }

      // 2. Parse <a href="/groups/<id>...">Group Name</a> (mbasic & m.facebook.com)
      const linkRe = /<a[^>]+href=["'](?:https?:\/\/[^"']*facebook\.com)?\/groups\/([a-zA-Z0-9._-]{3,})(?:\/|\?|["'])[^>]*>([\s\S]*?)<\/a>/gi;
      while ((m = linkRe.exec(html)) !== null) {
        const gid = m[1];
        const innerText = m[2].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
        if (innerText && innerText.length >= 2 && innerText.length <= 160) {
          found.push({ id: gid, name: innerText });
        }
      }

      emitBatch(found);
      if (totalAdded >= 5 && url.includes('seemore')) break;
    } catch (err) {
      console.warn('[scanGroupsViaMobileHtml] Fetch skipped:', url, err);
    }
  }
  return totalAdded;
}

function cleanExtractedToken(tok) {
  if (!tok || typeof tok !== 'string') return null;
  const cleaned = tok
    .replace(/\\u003a/gi, ':')
    .replace(/\\\//g, '/')
    .trim();
  return cleaned.length >= 8 ? cleaned : null;
}

function extractTokensFromHtml(html) {
  let dtsg = null;
  let lsd = null;
  let userId = null;
  let actorId = null;
  try {
    if (!html || typeof html !== 'string') return { dtsg: null, lsd: null, userId: null, actorId: null };

    const dtsgPatterns = [
      /"payload"\s*:\s*\{[^}]*"token"\s*:\s*"([^"]{8,})"/,
      /"DTSGInitialData"\s*,\s*\[\]\s*,\s*\{[^}]*"token"\s*:\s*"([^"]{8,})"/,
      /"DTSGInitData"\s*,\s*(?:\[\]\s*,\s*)?\{[^}]*"token"\s*:\s*"([^"]{8,})"/,
      /"dtsg"\s*:\s*\{[^}]*"token"\s*:\s*"([^"]{8,})"/,
      /"dtsg_ag"\s*:\s*\{[^}]*"token"\s*:\s*"([^"]{8,})"/,
      /"fb_dtsg"\s*:\s*"([^"]{8,})"/,
      /name=["']fb_dtsg["'][^>]{0,120}?value=["']([^"']{8,})["']/i,
      /value=["']([^"']{8,})["'][^>]{0,120}?name=["']fb_dtsg["']/i,
      /name=\\"fb_dtsg\\"[^>]{0,120}?value=\\"([^\\"]{8,})\\"/i,
      /"token"\s*:\s*"((?:NA|AQ)[A-Za-z0-9:_\\-]{10,})"/,
      /fb_dtsg=([A-Za-z0-9:_%-]{10,})/
    ];
    for (const re of dtsgPatterns) {
      const m = html.match(re);
      if (m && m[1]) {
        const candidate = cleanExtractedToken(m[1].includes('%') ? decodeURIComponent(m[1]) : m[1]);
        if (candidate) {
          dtsg = candidate;
          break;
        }
      }
    }

    const lsdPatterns = [
      /"LSD"\s*,\s*\[\]\s*,\s*\{[^}]*"token"\s*:\s*"([^"]{4,})"/,
      /"lsd"\s*:\s*"([^"]{4,})"/,
      /name=["']lsd["'][^>]{0,120}?value=["']([^"']{4,})["']/i,
      /value=["']([^"']{4,})["'][^>]{0,120}?name=["']lsd["']/i
    ];
    for (const re of lsdPatterns) {
      const m = html.match(re);
      if (m && m[1]) {
        lsd = m[1].trim();
        break;
      }
    }

    const userMatch =
      html.match(/"USER_ID"\s*:\s*"(\d{5,})"/) ||
      html.match(/"c_user"\s*:\s*"(\d{5,})"/) ||
      html.match(/db_profile_id\s*:\s*"(\d{5,})"/) ||
      html.match(/c_user=(\d{5,})/);
    if (userMatch && userMatch[1] && userMatch[1] !== '0') userId = userMatch[1];

    const actorMatch =
      html.match(/"ACCOUNT_ID"\s*:\s*"(\d{5,})"/) ||
      html.match(/"ACTOR_ID"\s*:\s*"(\d{5,})"/) ||
      html.match(/"actorID"\s*:\s*"(\d{5,})"/);
    if (actorMatch && actorMatch[1] && actorMatch[1] !== '0') actorId = actorMatch[1];
  } catch (e) {
    console.error('Error extracting tokens from HTML:', e);
  }
  return { dtsg, lsd, userId, actorId: actorId || userId };
}

async function getTokensFromTab(tabId) {
  let resultTokens = null;

  // 1. Default isolated world (100% supported on Lemur / Kiwi / Mises mobile browsers + Chrome)
  try {
    const isoExec = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: async () => {
        const extractFromText = (txt) => {
          if (!txt) return { d: null, l: null, u: null, a: null };
          let d = null, l = null, u = null, a = null;
          const dPats = [
            /"DTSGInitialData"\s*,\s*\[\]\s*,\s*\{[^}]*"token"\s*:\s*"([^"]{8,})"/,
            /"DTSGInitData"\s*,\s*(?:\[\]\s*,\s*)?\{[^}]*"token"\s*:\s*"([^"]{8,})"/,
            /"dtsg"\s*:\s*\{[^}]*"token"\s*:\s*"([^"]{8,})"/,
            /"fb_dtsg"\s*:\s*"([^"]{8,})"/,
            /"token"\s*:\s*"((?:NA|AQ)[A-Za-z0-9:_\\-]{10,})"/,
            /name=["']fb_dtsg["'][^>]{0,120}?value=["']([^"']{8,})["']/i
          ];
          for (const re of dPats) {
            const m = txt.match(re);
            if (m && m[1]) { d = m[1].replace(/\\u003a/gi, ':').replace(/\\\//g, '/'); break; }
          }
          const lM = txt.match(/"LSD"\s*,\s*\[\]\s*,\s*\{[^}]*"token"\s*:\s*"([^"]{4,})"/) || txt.match(/"lsd"\s*:\s*"([^"]{4,})"/);
          if (lM && lM[1]) l = lM[1];
          const uM = txt.match(/"USER_ID"\s*:\s*"(\d{5,})"/) || txt.match(/c_user=(\d{5,})/);
          if (uM && uM[1] && uM[1] !== '0') u = uM[1];
          const aM = txt.match(/"ACCOUNT_ID"\s*:\s*"(\d{5,})"/) || txt.match(/"ACTOR_ID"\s*:\s*"(\d{5,})"/);
          if (aM && aM[1] && aM[1] !== '0') a = aM[1];
          return { d, l, u, a };
        };

        for (let i = 0; i < 12; i++) {
          let d = null, l = null, u = null, actor = null;
          try {
            const dInput = document.querySelector('input[name="fb_dtsg"]');
            if (dInput && dInput.value) d = dInput.value;
            const lInput = document.querySelector('input[name="lsd"]');
            if (lInput && lInput.value) l = lInput.value;

            const cookies = (document.cookie || '').split(';');
            for (const cookie of cookies) {
              const eqIdx = cookie.indexOf('=');
              if (eqIdx === -1) continue;
              const name = cookie.slice(0, eqIdx).trim();
              const value = cookie.slice(eqIdx + 1).trim();
              if (!u && name === 'c_user') u = value;
              if (!actor && name === 'i_user') actor = value;
            }

            if (!d) {
              const scripts = document.querySelectorAll('script');
              for (let s = 0; s < scripts.length; s++) {
                const txt = scripts[s].textContent || '';
                if (!txt || (!txt.includes('DTSG') && !txt.includes('dtsg') && !txt.includes('"NA') && !txt.includes('"AQ'))) continue;
                const parsed = extractFromText(txt);
                if (parsed.d) {
                  d = parsed.d;
                  if (!l && parsed.l) l = parsed.l;
                  if (!u && parsed.u) u = parsed.u;
                  if (!actor && parsed.a) actor = parsed.a;
                  break;
                }
              }
            }

            if (!d && document.documentElement) {
              const parsed = extractFromText(document.documentElement.innerHTML);
              if (parsed.d) {
                d = parsed.d;
                if (!l && parsed.l) l = parsed.l;
                if (!u && parsed.u) u = parsed.u;
                if (!actor && parsed.a) actor = parsed.a;
              }
            }

            if (d) {
              const finalActor = actor || u;
              return { dtsg: d, lsd: l, userId: u, actorId: finalActor, isPageProfile: Boolean(actor && u && String(actor) !== String(u)) };
            }
          } catch (e) {}
          await new Promise((r) => setTimeout(r, 250));
        }
        return { dtsg: null, lsd: null, userId: null };
      }
    });
    if (isoExec && isoExec[0] && isoExec[0].result && isoExec[0].result.dtsg) {
      resultTokens = isoExec[0].result;
    }
  } catch (e) {
    console.warn('[getTokensFromTab] Isolated world scan warning:', e);
  }

  // 2. Also try MAIN world (desktop & modern Chromium) if isolated world didn't get DTSG
  if (!resultTokens || !resultTokens.dtsg) {
    try {
      const result = await chrome.scripting.executeScript({
        target: { tabId: tabId },
        world: 'MAIN',
        func: async () => {
          let d = null, l = null, u = null, actor = null;
          for (let i = 0; i < 12; i++) {
            try {
              if (window.DTSGInitialData && window.DTSGInitialData.token) d = window.DTSGInitialData.token;
              if (!d && window.DTSGInitData && window.DTSGInitData.token) d = window.DTSGInitData.token;
              if (!d && window.MRequestConfig && window.MRequestConfig.dtsg && window.MRequestConfig.dtsg.token) {
                d = window.MRequestConfig.dtsg.token;
              }
              if (window.LSD && window.LSD.token) l = window.LSD.token;
              if (!d && window.require) {
                try { d = window.require('DTSGInitialData').token; } catch (e) {}
                try { if (!d) d = window.require('DTSGInitData').token; } catch (e) {}
                try { if (!d) d = window.require('MRequestConfig').dtsg.token; } catch (e) {}
              }
              if (!l && window.require) {
                try { l = window.require('LSD').token; } catch (e) {}
              }
              if (!d) {
                const input = document.querySelector('input[name="fb_dtsg"]');
                if (input && input.value) d = input.value;
              }
              if (!l) {
                const input = document.querySelector('input[name="lsd"]');
                if (input && input.value) l = input.value;
              }
              try {
                if (window.CurrentUserInitialData) {
                  if (window.CurrentUserInitialData.USER_ID) u = window.CurrentUserInitialData.USER_ID;
                  if (window.CurrentUserInitialData.ACCOUNT_ID) actor = window.CurrentUserInitialData.ACCOUNT_ID;
                }
              } catch (e) {}
              if (d) {
                const finalActor = actor || u;
                return { dtsg: d, lsd: l, userId: u, actorId: finalActor, isPageProfile: Boolean(actor && u && String(actor) !== String(u)) };
              }
            } catch (e) {}
            await new Promise((r) => setTimeout(r, 250));
          }
          return { dtsg: null, lsd: null, userId: null };
        }
      });
      if (result && result[0] && result[0].result && result[0].result.dtsg) {
        resultTokens = result[0].result;
      }
    } catch (e) {
      console.warn('[getTokensFromTab] MAIN world scan skipped:', e);
    }
  }

  // Enrich with chrome.cookies so userId/actorId are never missing on mobile
  if (resultTokens && resultTokens.dtsg) {
    const ck = await getFbCookies();
    if (!resultTokens.userId && ck.cUser) resultTokens.userId = ck.cUser;
    if (!resultTokens.actorId) resultTokens.actorId = ck.iUser || resultTokens.userId;
    if (ck.iUser && resultTokens.userId && String(ck.iUser) !== String(resultTokens.userId)) {
      resultTokens.actorId = ck.iUser;
      resultTokens.isPageProfile = true;
    }
    return resultTokens;
  }
  return { dtsg: null, lsd: null, userId: null };
}

async function isTabActiveAndReady(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab.discarded) {
      console.warn(`[isTabActiveAndReady] Tab ${tabId} is discarded.`);
      return false;
    }
    const ready = tab.status === 'complete' && tab.url && tab.url.includes('facebook.com');
    return ready;
  } catch (e) {
    console.error(`[isTabActiveAndReady] Error checking tab ${tabId}:`, e);
    return false;
  }
}

async function getTokensResilient(uiTabId) {
  const ck = await getFbCookies();
  const enrichTokens = (t) => {
    if (!t || !t.dtsg) return null;
    const userId = t.userId || ck.cUser || null;
    const actorId = ck.iUser || t.actorId || userId;
    return {
      dtsg: t.dtsg,
      lsd: t.lsd || null,
      userId,
      actorId,
      isPageProfile: Boolean(ck.iUser && userId && String(ck.iUser) !== String(userId)) || Boolean(t.isPageProfile)
    };
  };

  if (uiTabId) sendMessage(uiTabId, 'status_update', '🔍 Kiểm tra các tab Facebook đang mở...');
  const fbTabs = await chrome.tabs.query({ url: '*://*.facebook.com/*' });

  // 1. Try existing open Facebook tabs first (supports www, m, mbasic, web)
  if (fbTabs.length > 0) {
    if (uiTabId) sendMessage(uiTabId, 'status_update', `Tìm thấy ${fbTabs.length} tab Facebook. Đang trích xuất token...`);
    for (const tab of fbTabs) {
      try {
        const isReady = await isTabActiveAndReady(tab.id);
        if (!isReady) continue;
        const tokens = enrichTokens(await getTokensFromTab(tab.id));
        if (tokens && tokens.dtsg) {
          if (uiTabId) sendMessage(uiTabId, 'status_update', '✅ Đã lấy token bảo mật từ tab có sẵn.');
          return { tokens, tabId: tab.id, isTemp: false };
        }
      } catch (e) {
        console.warn('Failed to extract tokens from existing tab:', tab.id, e);
      }
    }
  }

  // 2. Fast silent multi-endpoint fetches in Service Worker (works on BOTH desktop & mobile Lemur/Kiwi/Mises!)
  if (uiTabId) sendMessage(uiTabId, 'status_update', 'Đang trích xuất token ngầm qua API (hỗ trợ Mobile & PC)...');
  const silentEndpoints = [
    { url: 'https://www.facebook.com/ajax/dtsg/?__a=1', label: 'API dtsg' },
    { url: 'https://m.facebook.com/ajax/dtsg/?__a=1', label: 'Mobile API dtsg' },
    { url: 'https://www.facebook.com/', label: 'www.facebook.com' },
    { url: 'https://m.facebook.com/groups/', label: 'm.facebook.com' },
    { url: 'https://mbasic.facebook.com/groups/?seemore', label: 'mbasic.facebook.com' },
    { url: 'https://mbasic.facebook.com/', label: 'mbasic home' }
  ];

  for (const ep of silentEndpoints) {
    try {
      const response = await fetch(ep.url, {
        headers: {
          'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'cache-control': 'no-cache',
          'pragma': 'no-cache'
        },
        credentials: 'include'
      });
      if (response.ok) {
        const bodyText = await response.text();
        const tokens = enrichTokens(extractTokensFromHtml(bodyText));
        if (tokens && tokens.dtsg) {
          if (uiTabId) sendMessage(uiTabId, 'status_update', `✅ Đã lấy token bảo mật ngầm (${ep.label}).`);
          let targetTabId = null;
          for (const tab of fbTabs) {
            if (await isTabActiveAndReady(tab.id)) {
              targetTabId = tab.id;
              break;
            }
          }
          // Return directly with existing tab (or null for direct SW fetch — avoids Android frozen background tabs!)
          return { tokens, tabId: targetTabId, isTemp: false };
        }
      }
    } catch (fetchErr) {
      console.warn(`[getTokensResilient] Silent fetch skipped (${ep.label}):`, fetchErr);
    }
  }

  // 3. Last resort: open silent background tab (try m.facebook.com/groups/ first on mobile-like setups, then www)
  const fallbackTabUrls = ['https://www.facebook.com/', 'https://m.facebook.com/groups/'];
  for (const tabUrl of fallbackTabUrls) {
    if (uiTabId) sendMessage(uiTabId, 'status_update', `🕶️ Đang mở tab ngầm Facebook để lấy token bảo mật...`);
    let newTab = null;
    try {
      newTab = await chrome.tabs.create({ url: tabUrl, active: false });
      await waitForPageLoad(newTab.id, 9000);
      if (uiTabId) sendMessage(uiTabId, 'status_update', 'Đang trích xuất token bảo mật...');
      const tokens = enrichTokens(await getTokensFromTab(newTab.id));
      if (tokens && tokens.dtsg) {
        if (uiTabId) sendMessage(uiTabId, 'status_update', '✅ Lấy token từ tab Facebook thành công.');
        return { tokens, tabId: newTab.id, isTemp: true };
      }
      try { await chrome.tabs.remove(newTab.id); } catch (e) {}
    } catch (tabCreateError) {
      console.error('Failed to create background tab for tokens:', tabCreateError);
      if (newTab && newTab.id) {
        try { await chrome.tabs.remove(newTab.id); } catch (e) {}
      }
    }
  }

  if (uiTabId) sendMessage(uiTabId, 'status_update', '⚠️ Không thể lấy token từ tab Facebook, sẽ thử phương án dự phòng.');
  return null;
}

async function fetchGraphQLInTab(tabId, tokens, variables, docId, friendlyName) {
  const buildBody = () => {
    const body = new URLSearchParams();
    body.append('fb_dtsg', tokens.dtsg);
    if (tokens.lsd) body.append('lsd', tokens.lsd);
    const effectiveActor = tokens.actorId || tokens.userId;
    if (effectiveActor) {
      body.append('__user', effectiveActor);
      body.append('av', effectiveActor);
    }
    body.append('__a', '1');
    body.append('__req', Math.random().toString(36).slice(2, 6));
    body.append('doc_id', docId);
    body.append('variables', JSON.stringify(variables));
    body.append('fb_api_caller_class', 'RelayModern');
    body.append('fb_api_req_friendly_name', friendlyName);
    body.append('server_timestamps', 'true');
    return body;
  };

  const fetchViaServiceWorker = async () => {
    const endpoints = [
      { url: 'https://www.facebook.com/api/graphql/', origin: 'https://www.facebook.com' },
      { url: 'https://m.facebook.com/api/graphql/', origin: 'https://m.facebook.com' }
    ];
    let lastErr = null;
    for (const ep of endpoints) {
      try {
        const response = await fetch(ep.url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9,vi;q=0.8',
            'Origin': ep.origin,
            'Referer': ep.origin + '/',
            'X-FB-Friendly-Name': friendlyName,
            'X-FB-LSD': tokens.lsd || '',
            'X-ASBD-ID': '129477',
            'X-FB-HTTP-Engine': 'Liger'
          },
          body: buildBody(),
          credentials: 'include'
        });
        const text = await response.text();
        if (response.ok && text && !text.trim().startsWith('<!DOCTYPE') && !text.trim().startsWith('<html')) {
          return text;
        }
        lastErr = new Error(`HTTP ${response.status}: ${text.slice(0, 80)}`);
      } catch (e) {
        lastErr = e;
      }
    }
    throw lastErr || new Error('Service Worker GraphQL fetch failed');
  };

  if (!tabId) {
    return await fetchViaServiceWorker();
  }

  let tabResult = null;
  let tabError = null;

  try {
    const result = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      args: [tokens, variables, docId, friendlyName],
      func: async (tokens, variables, docId, friendlyName) => {
        const body = new URLSearchParams();
        body.append('fb_dtsg', tokens.dtsg);
        if (tokens.lsd) body.append('lsd', tokens.lsd);
        const effectiveActor = tokens.actorId || tokens.userId;
        if (effectiveActor) {
          body.append('__user', effectiveActor);
          body.append('av', effectiveActor);
        }
        body.append('__a', '1');
        body.append('__req', Math.random().toString(36).slice(2, 6));
        body.append('doc_id', docId);
        body.append('variables', JSON.stringify(variables));
        body.append('fb_api_caller_class', 'RelayModern');
        body.append('fb_api_req_friendly_name', friendlyName);
        body.append('server_timestamps', 'true');

        try {
          const origin = (window.location && window.location.origin && window.location.origin.includes('facebook.com'))
            ? window.location.origin
            : 'https://www.facebook.com';
          const response = await fetch(origin + '/api/graphql/', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
              'Accept': '*/*',
              'X-FB-Friendly-Name': friendlyName,
              'X-FB-LSD': tokens.lsd || ''
            },
            body: body,
            credentials: 'include'
          });
          const txt = await response.text();
          if (!response.ok || txt.trim().startsWith('<!DOCTYPE') || txt.trim().startsWith('<html')) {
            return { error: `HTTP ${response.status}: ${txt.slice(0, 100)}` };
          }
          return txt;
        } catch (e) {
          return { error: e.message || String(e) };
        }
      }
    });
    tabResult = result[0]?.result;
    if (tabResult && typeof tabResult === 'object' && tabResult.error) {
      tabError = tabResult.error;
      tabResult = null;
    }
  } catch (e) {
    tabError = e.message || String(e);
    tabResult = null;
  }

  if (!tabResult) {
    console.warn('[fetchGraphQLInTab] Tab script fallback to SW. Tab Error:', tabError);
    return await fetchViaServiceWorker();
  }

  return tabResult;
}

// ========================================
// Page Posts Feature - Scan Posts from a Page (mbasic approach - NO tab redirects)
// ========================================
async function scanPagePosts(uiTabId, pageUrl) {
  let scanTabId = null;
  try {
    let targetUrl = String(pageUrl || '').trim();
    if (!targetUrl) {
      throw new Error('Vui lòng nhập đường dẫn Trang Facebook hợp lệ.');
    }
    if (!/^https?:\/\//i.test(targetUrl)) {
      targetUrl = 'https://www.facebook.com/' + targetUrl.replace(/^\/+/, '');
    }

    let parsedTarget = null;
    try {
      parsedTarget = new URL(targetUrl);
      if (parsedTarget.hostname.includes('mbasic') || parsedTarget.hostname === 'm.facebook.com') {
        parsedTarget.hostname = 'www.facebook.com';
      }
      targetUrl = parsedTarget.toString();
    } catch (e) {}

    // Reject bare Newsfeed homepage URL
    if (parsedTarget && (parsedTarget.pathname === '/' || parsedTarget.pathname === '/home.php')) {
      throw new Error('Link nhập vào là Trang chủ (Newsfeed), không phải Fanpage! Vui lòng chọn đúng Fanpage ở Bước 1.');
    }

    // If user pasted a direct single post/video/reel URL, add it immediately!
    if (/\/(posts|videos|reel|permalink\.php|story\.php|watch)/i.test(targetUrl) || /[?&](fbid|story_fbid)=\d+/i.test(targetUrl)) {
      sendMessage(uiTabId, 'page_posts_data', [{
        id: targetUrl,
        url: targetUrl,
        text: 'Bài viết trực tiếp từ liên kết đã nhập',
        media: null,
        type: /\/(videos|reel|watch)/i.test(targetUrl) ? 'video' : 'text',
        time: 'Link trực tiếp'
      }]);
      sendMessage(uiTabId, 'status_update', '✅ Đã nhận diện link bài viết trực tiếp!');
      sendMessage(uiTabId, 'page_posts_complete', null);
      return;
    }

    // Extract target page identifiers (slug / numeric ID) to ensure we ONLY scan THIS Page's own posts!
    let targetPageSlug = '';
    let targetPageId = '';
    if (parsedTarget) {
      const parts = parsedTarget.pathname.split('/').filter(Boolean);
      const first = (parts[0] || '').toLowerCase();
      if (first === 'profile.php') {
        targetPageId = parsedTarget.searchParams.get('id') || '';
      } else if ((first === 'pages' || first === 'people') && parts.length >= 3) {
        targetPageId = /^\d+$/.test(parts[2]) ? parts[2] : '';
        targetPageSlug = parts[1].toLowerCase();
      } else if (first === 'p' && parts.length >= 2) {
        const mTail = parts[1].match(/(\d{6,})$/);
        if (mTail) targetPageId = mTail[1];
        targetPageSlug = parts[1].toLowerCase();
      } else if (first) {
        if (/^\d{5,}$/.test(first)) targetPageId = first;
        else targetPageSlug = first;
      }
    }

    sendMessage(uiTabId, 'status_update', `🔍 Đang mở Fanpage để quét bài viết mới nhất: ${targetUrl}`);
    const createdTab = await chrome.tabs.create({ url: targetUrl, active: false });
    scanTabId = createdTab.id;
    await waitForPageLoad(scanTabId, 14000);
    await delay(2500);

    // Verify tab did NOT redirect to Newsfeed homepage
    const checkNav = await chrome.scripting.executeScript({
      target: { tabId: scanTabId },
      world: 'MAIN',
      func: () => ({
        href: window.location.href,
        pathname: window.location.pathname
      })
    });
    const loadedPath = (checkNav[0]?.result?.pathname || '').toLowerCase();
    if (loadedPath === '/' || loadedPath === '/home.php' || loadedPath.startsWith('/login')) {
      throw new Error('Không thể mở Fanpage (Facebook chuyển hướng về Trang chủ/Đăng nhập). Vui lòng kiểm tra lại link Fanpage!');
    }

    // Install MAIN-world passive GraphQL/XHR sniffer (strictly filtered to target Page!)
    try {
      await chrome.scripting.executeScript({
        target: { tabId: scanTabId },
        world: 'MAIN',
        args: [targetPageSlug, targetPageId],
        func: (pageSlug, pageId) => {
          if (window.__FB_PAGE_POST_SNIFFER) return;
          window.__FB_PAGE_POST_SNIFFER = true;
          window.__FB_SNIFFED_POSTS = window.__FB_SNIFFED_POSTS || [];

          const matchesTargetPage = (rawUrl, story) => {
            const u = String(rawUrl || '').toLowerCase();
            if (!u || u.includes('/groups/')) return false;
            if (!pageSlug && !pageId) return true;
            if (pageSlug && u.includes(`/${pageSlug}/`)) return true;
            if (pageId && (u.includes(`id=${pageId}`) || u.includes(`/${pageId}/`))) return true;
            const actors = story?.actors || story?.comet_sections?.actor_photo?.story?.actors || [];
            if (Array.isArray(actors)) {
              for (const a of actors) {
                const aid = String(a?.id || '');
                const aurl = String(a?.url || '').toLowerCase();
                if (pageId && aid === pageId) return true;
                if (pageSlug && aurl.includes(`/${pageSlug}`)) return true;
              }
            }
            return false;
          };

          const parseChunk = (rawText) => {
            if (!rawText || typeof rawText !== 'string') return;
            if (!rawText.includes('Story') && !rawText.includes('pfbid')) return;
            const lines = rawText.split('\n').filter(Boolean);
            for (const line of lines) {
              const cleaned = line.replace(/^for\s*\(;;\);\s*/, '').trim();
              if (!cleaned.startsWith('{')) continue;
              try {
                const json = JSON.parse(cleaned);
                const stack = [json];
                const seen = new Set();
                while (stack.length > 0) {
                  const cur = stack.pop();
                  if (!cur || typeof cur !== 'object' || seen.has(cur)) continue;
                  seen.add(cur);
                  const story = cur.__typename === 'Story'
                    ? cur
                    : (cur.comet_sections?.content?.story || null);
                  if (story && typeof story === 'object') {
                    const url = story.wwwURL || story.url || story.permalink_url || cur.wwwURL || cur.url || '';
                    const msg = story.message?.text || story.comet_sections?.message?.story?.message?.text || '';
                    if (url && url.includes('facebook.com') && matchesTargetPage(url, story)) {
                      let media = null;
                      try {
                        const attStr = JSON.stringify(story.attachments || []);
                        const imgMatch = attStr.match(/https?:\\\/\\\/scontent[^"\\]+|https?:\/\/scontent[^"]+/);
                        if (imgMatch) media = imgMatch[0].replace(/\\\//g, '/');
                      } catch (e) {}
                      window.__FB_SNIFFED_POSTS.push({
                        url,
                        text: msg || '',
                        media,
                        creation_time: story.creation_time || cur.creation_time || null
                      });
                    }
                  }
                  if (Array.isArray(cur)) {
                    for (let i = 0; i < cur.length; i++) stack.push(cur[i]);
                  } else {
                    const vals = Object.values(cur);
                    for (let i = 0; i < vals.length; i++) {
                      if (vals[i] && typeof vals[i] === 'object') stack.push(vals[i]);
                    }
                  }
                }
              } catch (e) {}
            }
          };

          const origFetch = window.fetch;
          window.fetch = async function (...args) {
            const res = await origFetch.apply(this, args);
            try {
              const url = typeof args[0] === 'string' ? args[0] : (args[0]?.url || '');
              if (url.includes('/api/graphql')) {
                res.clone().text().then(parseChunk).catch(() => {});
              }
            } catch (e) {}
            return res;
          };
          const origOpen = XMLHttpRequest.prototype.open;
          const origSend = XMLHttpRequest.prototype.send;
          XMLHttpRequest.prototype.open = function (m, u) {
            this.__fbU = typeof u === 'string' ? u : '';
            return origOpen.apply(this, arguments);
          };
          XMLHttpRequest.prototype.send = function () {
            this.addEventListener('load', function () {
              try {
                if (this.__fbU && this.__fbU.includes('/api/graphql') && typeof this.responseText === 'string') {
                  parseChunk(this.responseText);
                }
              } catch (e) {}
            });
            return origSend.apply(this, arguments);
          };
        }
      });
    } catch (e) {}

    const collectedMap = new Map();
    const maxPosts = 12;

    for (let round = 0; round < 6 && collectedMap.size < maxPosts; round++) {
      try {
        const res = await chrome.scripting.executeScript({
          target: { tabId: scanTabId },
          world: 'MAIN',
          args: [round === 0, targetPageSlug, targetPageId],
          func: async (scanSsr, pageSlug, pageId) => {
            const found = [];
            const normalizePostUrl = (raw) => {
              if (!raw || typeof raw !== 'string') return '';
              let u = raw.replace(/\\\//g, '/').trim();
              if (u.startsWith('/')) u = 'https://www.facebook.com' + u;
              if (!u.includes('facebook.com')) return '';
              try {
                const parsed = new URL(u);
                const keepParams = new URLSearchParams();
                for (const key of ['fbid', 'story_fbid', 'id', 'v']) {
                  if (parsed.searchParams.has(key)) keepParams.set(key, parsed.searchParams.get(key));
                }
                const qs = keepParams.toString();
                return `${parsed.origin}${parsed.pathname}${qs ? '?' + qs : ''}`;
              } catch (e) {
                return u.split('?')[0];
              }
            };

            const isValidPagePostUrl = (u) => {
              if (!u) return false;
              const lower = u.toLowerCase();
              if (lower.includes('/groups/')) return false;
              if (lower === 'https://www.facebook.com' || lower === 'https://www.facebook.com/' || lower.includes('/home.php')) return false;
              if (/\/photo\/?$/i.test(u) && !u.includes('fbid=')) return false;
              return /\/(posts|videos|reel|permalink\.php|story\.php|watch)/i.test(u) || /[?&](fbid|story_fbid)=\d+/i.test(u);
            };

            const belongsToTargetPage = (cleanUrl, story) => {
              const lower = cleanUrl.toLowerCase();
              if (!pageSlug && !pageId) return true;
              if (pageSlug && lower.includes(`/${pageSlug}/`)) return true;
              if (pageId && (lower.includes(`id=${pageId}`) || lower.includes(`/${pageId}/`))) return true;
              if (/\/(reel|watch|photo)\b/i.test(lower)) return true;
              const actors = story?.actors || [];
              if (Array.isArray(actors)) {
                for (const a of actors) {
                  if (pageId && String(a?.id || '') === pageId) return true;
                  if (pageSlug && String(a?.url || '').toLowerCase().includes(`/${pageSlug}`)) return true;
                }
              }
              return false;
            };

            // 1. PRIORITY 1: Rendered DOM [role="main"] [role="article"] directly on this Page!
            const articles = Array.from(document.querySelectorAll('[role="main"] [role="article"]')).slice(0, 15);
            for (const art of articles) {
              if (art.parentElement && art.parentElement.closest('[role="article"]')) continue;
              const anchors = Array.from(art.querySelectorAll('a[role="link"], a[href]'));
              for (const a of anchors.slice(0, 8)) {
                const h = a.getAttribute('href') || '';
                if (h === '#' || h.includes('__cft__')) {
                  try {
                    a.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
                    a.dispatchEvent(new MouseEvent('pointerover', { bubbles: true }));
                    a.dispatchEvent(new FocusEvent('focus', { bubbles: true }));
                  } catch (e) {}
                }
              }
            }
            await new Promise((r) => setTimeout(r, 380));

            for (const art of articles) {
              if (art.parentElement && art.parentElement.closest('[role="article"]')) continue;
              const anchors = Array.from(art.querySelectorAll('a[href]'));
              let bestUrl = '';
              let timeLabel = 'Gần đây';
              for (const a of anchors) {
                const rawHref = a.getAttribute('href') || '';
                const cleanUrl = normalizePostUrl(rawHref);
                if (isValidPagePostUrl(cleanUrl)) {
                  bestUrl = cleanUrl;
                  const txt = (a.innerText || a.getAttribute('aria-label') || '').trim();
                  if (txt && txt.length <= 40 && !/^(thích|bình luận|chia sẻ|like|comment|share)/i.test(txt)) {
                    timeLabel = txt;
                  }
                  if (/\/(posts|videos|reel|permalink\.php)/i.test(cleanUrl)) break;
                }
              }
              if (!bestUrl) continue;

              const msgEl = art.querySelector('[data-ad-preview="message"], [data-ad-comet-preview="message"], div[dir="auto"]');
              let text = msgEl ? (msgEl.innerText || '').trim() : '';
              if (!text) {
                const lines = (art.innerText || '').split('\n').map((l) => l.trim()).filter((l) => l.length > 8);
                text = lines.slice(0, 3).join(' ');
              }
              let media = null;
              const imgs = Array.from(art.querySelectorAll('img[src*="scontent"], img[src*="fbcdn"]'));
              for (const img of imgs) {
                const rect = img.getBoundingClientRect();
                if (rect.width >= 80 && rect.height >= 80) {
                  media = img.src;
                  break;
                }
              }
              found.push({
                url: bestUrl,
                text: text || '(Bài viết hình ảnh / Video)',
                media,
                type: /\/(videos|reel|watch)/i.test(bestUrl) ? 'video' : (media ? 'image' : 'text'),
                time: timeLabel
              });
            }

            // 2. Live GraphQL sniffer (already page-filtered)
            if (Array.isArray(window.__FB_SNIFFED_POSTS)) {
              while (window.__FB_SNIFFED_POSTS.length > 0) {
                const item = window.__FB_SNIFFED_POSTS.shift();
                const cleanUrl = normalizePostUrl(item.url);
                if (isValidPagePostUrl(cleanUrl) && belongsToTargetPage(cleanUrl, null)) {
                  found.push({
                    url: cleanUrl,
                    text: item.text || '',
                    media: item.media || null,
                    type: /\/(videos|reel|watch)/i.test(cleanUrl) ? 'video' : (item.media ? 'image' : 'text'),
                    time: item.creation_time ? new Date(item.creation_time * 1000).toLocaleString('vi-VN') : 'Gần đây'
                  });
                }
              }
            }

            // 3. SSR <script type="application/json"> (strictly filtered to target Page!)
            if (scanSsr) {
              const scripts = document.querySelectorAll('script[type="application/json"]');
              for (const s of scripts) {
                const txt = s.textContent || '';
                if (!txt.includes('"Story"') && !txt.includes('pfbid')) continue;
                try {
                  const json = JSON.parse(txt);
                  const stack = [json];
                  const seen = new Set();
                  while (stack.length > 0) {
                    const cur = stack.pop();
                    if (!cur || typeof cur !== 'object' || seen.has(cur)) continue;
                    seen.add(cur);
                    if (cur.__typename === 'Story') {
                      const rawUrl = cur.wwwURL || cur.url || cur.permalink_url || '';
                      const cleanUrl = normalizePostUrl(rawUrl);
                      if (isValidPagePostUrl(cleanUrl) && belongsToTargetPage(cleanUrl, cur)) {
                        const msg = cur.message?.text || cur.comet_sections?.message?.story?.message?.text || '';
                        let media = null;
                        try {
                          const attStr = JSON.stringify(cur.attachments || []);
                          const imgM = attStr.match(/https?:\/\/scontent[^"]+/);
                          if (imgM) media = imgM[0];
                        } catch (e) {}
                        found.push({
                          url: cleanUrl,
                          text: msg,
                          media,
                          type: /\/(videos|reel|watch)/i.test(cleanUrl) ? 'video' : (media ? 'image' : 'text'),
                          time: cur.creation_time ? new Date(cur.creation_time * 1000).toLocaleString('vi-VN') : 'Gần đây'
                        });
                      }
                    }
                    if (Array.isArray(cur)) {
                      for (let i = 0; i < cur.length; i++) stack.push(cur[i]);
                    } else {
                      const vals = Object.values(cur);
                      for (let i = 0; i < vals.length; i++) {
                        if (vals[i] && typeof vals[i] === 'object') stack.push(vals[i]);
                      }
                    }
                  }
                } catch (e) {}
              }
            }

            window.scrollBy(0, Math.max(window.innerHeight * 1.1, 1000));
            return found;
          }
        });

        const items = res[0]?.result || [];
        for (const item of items) {
          if (!item || !item.url) continue;
          const key = item.url.replace(/\/+$/, '');
          const existing = collectedMap.get(key);
          if (!existing) {
            collectedMap.set(key, {
              id: key,
              url: item.url,
              text: (item.text || '(Bài viết hình ảnh / Video)').slice(0, 300),
              media: item.media || null,
              type: item.type || (item.media ? 'image' : 'text'),
              time: item.time || 'Gần đây'
            });
          } else {
            if ((!existing.text || existing.text.startsWith('(Bài viết')) && item.text && !item.text.startsWith('(Bài viết')) {
              existing.text = item.text.slice(0, 300);
            }
            if (!existing.media && item.media) {
              existing.media = item.media;
              existing.type = item.type || 'image';
            }
          }
        }
      } catch (roundErr) {
        console.warn('[scanPagePosts] Round error:', roundErr);
      }
      if (collectedMap.size >= maxPosts) break;
      await delay(1400);
    }

    const extractedPosts = Array.from(collectedMap.values()).slice(0, maxPosts);
    if (extractedPosts.length > 0) {
      sendMessage(uiTabId, 'page_posts_data', extractedPosts);
      sendMessage(uiTabId, 'status_update', `✅ Đã quét được ${extractedPosts.length} bài viết mới nhất từ Fanpage!`);
    } else {
      sendMessage(uiTabId, 'status_update', '⚠️ Không tìm thấy bài viết công khai nào trên Fanpage này. Bạn có thể dán trực tiếp link bài viết vào Bước 2!');
    }
    sendMessage(uiTabId, 'page_posts_complete', { count: extractedPosts.length });
  } catch (error) {
    console.error('[scanPagePosts] Error:', error);
    sendMessage(uiTabId, 'error', `Lỗi quét bài viết của Trang: ${error.message}`);
    sendMessage(uiTabId, 'page_posts_complete', { count: 0 });
  } finally {
    if (scanTabId) {
      try { await chrome.tabs.remove(scanTabId); } catch (e) {}
    }
  }
}

// ========================================
// Page Posts Feature - Strict Pure Native Reshare into Group + 3-Layer Real Link Capture (v3.1)
// ========================================
async function focusTabSafe(tabId) {
  if (!tabId) return;
  try {
    await chrome.tabs.update(tabId, { active: true });
    const tab = await chrome.tabs.get(tabId);
    if (tab && tab.windowId) {
      await chrome.windows.update(tab.windowId, { focused: true });
    }
  } catch (e) {}
}

async function fetchLatestGroupPostLink(workTabId, groupId) {
  if (!workTabId || !groupId) return null;
  try {
    const checkUrl = `https://www.facebook.com/groups/${groupId}/my_posted_content`;
    await chrome.tabs.update(workTabId, { url: checkUrl });
    await waitForPageLoad(workTabId, 10000);
    await delay(2000);

    const res = await chrome.scripting.executeScript({
      target: { tabId: workTabId },
      world: 'MAIN',
      args: [String(groupId)],
      func: async (gid) => {
        const cleanGroupPostLink = (raw) => {
          if (!raw || typeof raw !== 'string') return null;
          let u = raw.replace(/\\\//g, '/').trim();
          if (u.startsWith('/')) u = 'https://www.facebook.com' + u;
          if (!u.includes(`/groups/${gid}/`) && !u.includes('/groups/')) return null;
          const m = u.match(/https?:\/\/www\.facebook\.com\/groups\/[^/?#]+\/(?:posts|permalink)\/[^/?#&]+/i);
          if (m) return m[0].replace(/\/+$/, '') + '/';
          const mp = u.match(/[?&]multi_permalinks=(\d+)/i);
          if (mp) return `https://www.facebook.com/groups/${gid}/posts/${mp[1]}/`;
          return null;
        };

        // Hover timestamps in the first article so lazy href="#" hydrates
        const firstArticle = document.querySelector('[role="main"] [role="article"]');
        if (firstArticle) {
          const anchors = Array.from(firstArticle.querySelectorAll('a[role="link"], a[href]'));
          for (const a of anchors.slice(0, 10)) {
            try {
              a.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
              a.dispatchEvent(new FocusEvent('focus', { bubbles: true }));
            } catch (e) {}
          }
          await new Promise((r) => setTimeout(r, 450));
          for (const a of Array.from(firstArticle.querySelectorAll('a[href]'))) {
            const link = cleanGroupPostLink(a.getAttribute('href'));
            if (link) return link;
          }
        }

        // Check all links in [role="main"]
        const mainLinks = Array.from(document.querySelectorAll('[role="main"] a[href*="/posts/"], [role="main"] a[href*="/permalink/"]'));
        for (const a of mainLinks) {
          const link = cleanGroupPostLink(a.getAttribute('href'));
          if (link) return link;
        }

        // Check SSR JSON for newest post_id in this group
        const scripts = Array.from(document.querySelectorAll('script[type="application/json"]'));
        for (const s of scripts) {
          const txt = s.textContent || '';
          if (!txt.includes(gid)) continue;
          const m = txt.match(new RegExp(`https?:\\\\/\\\\/www\\.facebook\\.com\\\\/groups\\\\/${gid}\\\\/(?:posts|permalink)\\\\/[^"\\\\?]+`, 'i'));
          if (m) return m[0].replace(/\\\//g, '/').replace(/\/+$/, '') + '/';
        }
        return null;
      }
    });
    return res[0]?.result || null;
  } catch (e) {
    return null;
  }
}

async function shareViaNativeDialog(uiTabId, workTabId, postUrl, groupId, groupName) {
  try {
    const displayGroup = groupName || groupId;
    sendMessage(uiTabId, 'status_update', `🕶️ [v3.8] Mở ngầm bài viết gốc của Trang để chia sẻ lên nhóm "${displayGroup}"...`);
    await chrome.tabs.update(workTabId, { url: postUrl });
    await delay(600);
    await waitForPageLoad(workTabId, 15000);
    await delay(2500);

    // Step 1: Verify loaded URL is a real post (NEVER Newsfeed!) & click Share on the TARGET post ONCE (no double-firing!)
    const step1 = await chrome.scripting.executeScript({
      target: { tabId: workTabId },
      world: 'MAIN',
      func: async () => {
        const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
        const safeClick = (el) => {
          if (!el) return;
          el.scrollIntoView({ block: 'center', inline: 'center' });
          el.click();
        };

        const path = (window.location.pathname || '/').toLowerCase().replace(/\/+$/, '') || '/';
        const qs = window.location.search || '';
        const isPostUrl =
          /\/(posts|videos|reel|permalink\.php|story\.php|photo|watch)/i.test(path) ||
          /[?&](fbid|story_fbid|v)=/i.test(qs);

        if (path === '/' || path === '/home.php' || path === '/groups/feed') {
          return {
            ok: false,
            reason: 'Link bài viết bị Facebook chuyển về Trang chủ (Newsfeed) — đã dừng để không chia sẻ nhầm bài trên Newsfeed!'
          };
        }
        if (!isPostUrl) {
          return {
            ok: false,
            reason: `Trang vừa mở (${window.location.pathname}) không phải link bài viết cụ thể — hãy chọn đúng bài viết của Page!`
          };
        }

        const isShareSheetOpen = () => {
          const overlays = Array.from(document.querySelectorAll('[role="dialog"], [role="menu"]'));
          for (const d of overlays) {
            const r = d.getBoundingClientRect();
            if (r.width < 180 || r.height < 120) continue;
            const txt = (d.innerText || '').toLowerCase();
            if (
              txt.includes('chia sẻ lên') ||
              txt.includes('chia sẻ ngay') ||
              txt.includes('chia sẻ lên nhóm') ||
              txt.includes('share to') ||
              txt.includes('share now') ||
              txt.includes('sao chép liên kết') ||
              txt.includes('copy link')
            ) {
              return true;
            }
          }
          return false;
        };

        const searchInRoot = (root) => {
          if (!root) return null;
          const byRole = root.querySelector('[data-ad-rendering-role="share_button"]');
          if (byRole) {
            const btn = byRole.closest('[role="button"], button') || byRole;
            const r = btn.getBoundingClientRect();
            if (r.width > 0 && r.height > 0) return btn;
          }
          const candidates = Array.from(root.querySelectorAll('[role="button"], button'));
          for (const el of candidates) {
            const rect = el.getBoundingClientRect();
            if (rect.width < 16 || rect.height < 16) continue;
            const aria = (el.getAttribute('aria-label') || '').trim().toLowerCase();
            const txt = (el.innerText || '').trim().toLowerCase();
            if (/\d+\s*(lượt chia sẻ|chia sẻ|shares?)/i.test(txt) || /\d+\s*(lượt chia sẻ|shares?)/i.test(aria)) {
              continue;
            }
            if (
              aria.includes('gửi nội dung này') ||
              aria.includes('gửi bài viết này') ||
              aria.includes('send this to friends') ||
              aria === 'chia sẻ' ||
              aria === 'share' ||
              txt === 'chia sẻ' ||
              txt === 'share'
            ) {
              return el;
            }
          }
          return null;
        };

        // Search topmost Post modal [role="dialog"] FIRST before touching [role="main"]
        const findShareBtn = () => {
          const dialogs = Array.from(document.querySelectorAll('[role="dialog"]')).filter((d) => {
            const r = d.getBoundingClientRect();
            if (r.width < 320 || r.height < 260) return false;
            const t = (d.innerText || '').slice(0, 160).toLowerCase();
            if (t.includes('đăng nhập') || t.includes('log in') || t.includes('chia sẻ lên') || t.includes('tạo bài viết')) return false;
            return true;
          });
          for (let i = dialogs.length - 1; i >= 0; i--) {
            const b = searchInRoot(dialogs[i]);
            if (b) return b;
          }
          const main = document.querySelector('[role="main"]');
          if (main) {
            const firstArticle = main.querySelector('[role="article"]');
            const fromArt = searchInRoot(firstArticle);
            if (fromArt) return fromArt;
            const fromMain = searchInRoot(main);
            if (fromMain) return fromMain;
          }
          return null;
        };

        let shareBtn = null;
        for (let i = 0; i < 24; i++) {
          shareBtn = findShareBtn();
          if (shareBtn) break;
          await sleep(500);
        }
        if (!shareBtn) {
          return { ok: false, reason: 'Không tìm thấy nút Chia sẻ trên bài viết của Page (bài viết có thể đang riêng tư hoặc bị khóa chia sẻ)' };
        }

        safeClick(shareBtn);
        for (let w = 0; w < 12; w++) {
          await sleep(500);
          if (isShareSheetOpen()) {
            await sleep(1000); // Human-paced settle before Step 2
            return { ok: true, loadedUrl: window.location.href };
          }
          if (w === 5) safeClick(shareBtn);
        }
        return { ok: false, reason: 'Đã bấm nút Chia sẻ nhưng hộp thoại Chia sẻ của Facebook không mở ra' };
      }
    });
    if (!step1[0]?.result?.ok) {
      return { ok: false, reason: step1[0]?.result?.reason || 'Không bấm được nút Chia sẻ' };
    }

    // Step 2: STRICT accent-normalized click on ONLY "Nhóm" / "Chia sẻ lên nhóm" (NEVER "Trang", "Bảng feed", "Trang cá nhân", "Chia sẻ ngay"!)
    sendMessage(uiTabId, 'status_update', `👆 Đang chọn "Chia sẻ lên nhóm" cho "${displayGroup}"...`);
    const step2 = await chrome.scripting.executeScript({
      target: { tabId: workTabId },
      world: 'MAIN',
      func: async () => {
        const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
        const norm = (s) =>
          String(s || '')
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/đ/g, 'd')
            .replace(/\s+/g, ' ')
            .trim();

        const safeClick = (el) => {
          if (!el) return;
          el.scrollIntoView({ block: 'center', inline: 'center' });
          el.click();
        };

        const isGroupPickerOpen = () => {
          const dialogs = Array.from(document.querySelectorAll('[role="dialog"]'));
          for (const d of dialogs) {
            const r = d.getBoundingClientRect();
            if (r.width < 240 || r.height < 200) continue;
            const grpInput = d.querySelector(
              'input[placeholder*="Tìm kiếm nhóm"], input[placeholder*="Search for groups"], ' +
              'input[aria-label*="Tìm kiếm nhóm"], input[aria-label*="Search for groups"]'
            );
            if (grpInput && grpInput.getBoundingClientRect().height > 0) return true;
            const head = norm((d.innerText || '').slice(0, 180));
            if (head.includes('chia se len nhom') || head.includes('share to a group') || head.includes('tat ca cac nhom')) {
              return true;
            }
          }
          return false;
        };

        const findShareSheet = () => {
          const overlays = Array.from(document.querySelectorAll('[role="dialog"], [role="menu"]')).filter((d) => {
            const r = d.getBoundingClientRect();
            return r.width >= 180 && r.height >= 120;
          });
          for (let i = overlays.length - 1; i >= 0; i--) {
            const d = overlays[i];
            const txt = norm(d.innerText || '');
            if (
              txt.includes('chia se len') ||
              txt.includes('chia se ngay') ||
              txt.includes('share to') ||
              txt.includes('share now') ||
              txt.includes('sao chep lien ket') ||
              txt.includes('copy link')
            ) {
              return d;
            }
          }
          return null;
        };

        const FORBIDDEN_PARTS = [
          'trang', 'page', 'bang feed', 'feed', 'tin', 'story',
          'chia se ngay', 'share now', 'messenger', 'whatsapp',
          'ban be', 'friend', 'sao chep', 'copy', 'nhung', 'embed',
          'ca nhan', 'profile'
        ];
        const isForbidden = (raw) => {
          const s = norm(raw);
          return FORBIDDEN_PARTS.some((p) => s.includes(p));
        };
        const isExactGroupLabel = (raw) => {
          const s = norm(raw);
          return (
            s === 'nhom' ||
            s === 'group' ||
            s === 'chia se len nhom' ||
            s === 'chia se vao nhom' ||
            s === 'share to a group' ||
            s === 'share to group'
          );
        };

        const findGroupOption = () => {
          const sheet = findShareSheet();
          if (!sheet) return null;

          const btns = Array.from(sheet.querySelectorAll('[role="button"], [role="menuitem"]'));
          for (const btn of btns) {
            if (btn.getAttribute('aria-disabled') === 'true') continue;
            const r = btn.getBoundingClientRect();
            if (r.width < 20 || r.height < 20) continue;
            const aria = btn.getAttribute('aria-label') || '';
            const txt = btn.innerText || '';
            if (isForbidden(aria) || isForbidden(txt)) continue;
            if (isExactGroupLabel(aria) || isExactGroupLabel(txt)) return btn;
          }

          const spans = Array.from(sheet.querySelectorAll('span'));
          for (const sp of spans) {
            const r = sp.getBoundingClientRect();
            if (r.width === 0 || r.height === 0) continue;
            if (!isExactGroupLabel(sp.innerText || '')) continue;
            const btn = sp.closest('[role="menuitem"], [role="button"]');
            if (!btn || btn.getAttribute('aria-disabled') === 'true') continue;
            if (isForbidden(btn.innerText || '') || isForbidden(btn.getAttribute('aria-label') || '')) continue;
            return btn;
          }
          return null;
        };

        let groupBtn = null;
        let triedMore = false;
        for (let i = 0; i < 16; i++) {
          if (isGroupPickerOpen()) return { ok: true };
          groupBtn = findGroupOption();
          if (groupBtn) break;
          if (i === 5 && !triedMore) {
            triedMore = true;
            const sheet = findShareSheet();
            if (sheet) {
              const moreBtn = Array.from(sheet.querySelectorAll('[role="button"], [role="menuitem"]')).find((el) => {
                const t = norm(el.innerText || el.getAttribute('aria-label') || '');
                return t === 'tuy chon khac' || t === 'more options' || t === 'xem them';
              });
              if (moreBtn) safeClick(moreBtn);
            }
          }
          await sleep(500);
        }

        if (!groupBtn) {
          return { ok: false, reason: 'Không thấy nút "Nhóm" trong hộp thoại Chia sẻ (đã dừng để không chia sẻ nhầm lên trang cá nhân/Trang)' };
        }

        safeClick(groupBtn);
        for (let w = 0; w < 14; w++) {
          await sleep(500);
          if (isGroupPickerOpen()) {
            await sleep(1000); // Human-paced settle for group list
            return { ok: true };
          }
          if (w === 5) {
            const retryBtn = findGroupOption();
            if (retryBtn) safeClick(retryBtn);
          }
        }
        return { ok: false, reason: 'Đã bấm "Nhóm" nhưng hộp thoại "Chia sẻ lên nhóm" không mở ra (đã dừng an toàn)' };
      }
    });
    if (!step2[0]?.result?.ok) {
      return { ok: false, reason: step2[0]?.result?.reason || 'Không mở được hộp thoại Chia sẻ lên nhóm' };
    }

    // Step 3: Search & click exact group row inside "Chia sẻ lên nhóm", then VERIFY exact Group badge element in "Tạo bài viết"!
    sendMessage(uiTabId, 'status_update', `🔎 Đang tìm & chọn nhóm "${displayGroup}"...`);
    const step3 = await chrome.scripting.executeScript({
      target: { tabId: workTabId },
      world: 'MAIN',
      args: [String(groupId || ''), String(groupName || '')],
      func: async (targetGroupId, targetGroupName) => {
        const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
        const safeClick = (el) => {
          if (!el) return;
          el.scrollIntoView({ block: 'center', inline: 'center' });
          el.click();
        };

        const stripEmojiAndPunct = (s) =>
          String(s || '')
            .replace(/[\u{1F000}-\u{1FFFF}\u{2600}-\u{27BF}\u{FE00}-\u{FE0F}\u{200D}\uFFFD]/gu, ' ')
            .replace(/[–—\-|\/\\()\[\]{},.:;!?*#@~^`"'«»•·]+/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();

        const normalize = (s) =>
          stripEmojiAndPunct(s)
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/đ/g, 'd')
            .replace(/[^a-z0-9\s]/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();

        const findShareGroupModal = () => {
          const dialogs = Array.from(document.querySelectorAll('[role="dialog"]')).filter((d) => {
            const r = d.getBoundingClientRect();
            return r.width > 240 && r.height > 200;
          });
          for (let i = dialogs.length - 1; i >= 0; i--) {
            const d = dialogs[i];
            const inp = d.querySelector(
              'input[placeholder*="Tìm kiếm nhóm"], input[placeholder*="Search for groups"], ' +
              'input[aria-label*="Tìm kiếm nhóm"], input[aria-label*="Search for groups"]'
            );
            if (inp) return { modal: d, searchInput: inp };
          }
          for (let i = dialogs.length - 1; i >= 0; i--) {
            const d = dialogs[i];
            const txt = normalize((d.innerText || '').slice(0, 220));
            if (txt.includes('chia se len nhom') || txt.includes('share to a group') || txt.includes('tat ca cac nhom')) {
              const inp = d.querySelector('input:not([type="hidden"]):not([type="checkbox"])');
              return { modal: d, searchInput: inp };
            }
          }
          return { modal: null, searchInput: null };
        };

        // ELEMENT-LEVEL Group Composer Verification (checks exact short badge elements in top 45% of modal!)
        const isGroupCreatePostOpen = () => {
          const dialogs = Array.from(document.querySelectorAll('[role="dialog"]'));
          for (const d of dialogs) {
            const dr = d.getBoundingClientRect();
            if (dr.width < 280 || dr.height < 240) continue;
            const topCutoff = dr.top + dr.height * 0.45;
            let hasTitle = false;
            let hasGroupBadge = false;
            let hasForbiddenBadge = false;

            const nodes = Array.from(d.querySelectorAll('h1, h2, h3, span, div[role="heading"]'));
            for (const el of nodes) {
              const r = el.getBoundingClientRect();
              if (r.width === 0 || r.height === 0 || r.top > topCutoff) continue;
              const raw = (el.innerText || '').trim();
              if (!raw || raw.length > 40 || raw.includes('\n')) continue;
              const t = normalize(raw);
              if (t === 'tao bai viet' || t === 'create post') hasTitle = true;
              if (
                t === 'nhom cong khai' ||
                t === 'nhom rieng tu' ||
                t === 'public group' ||
                t === 'private group' ||
                t.startsWith('thanh vien cua ') ||
                t.startsWith('members of ')
              ) {
                hasGroupBadge = true;
              }
              if (
                t === 'cong khai' ||
                t === 'public' ||
                t === 'ban be' ||
                t === 'friends' ||
                t === 'chi minh toi' ||
                t === 'only me' ||
                t === 'bang feed' ||
                t === 'news feed' ||
                t === 'chia se ngay' ||
                t === 'share now' ||
                t === 'chia se len nhom' ||
                t === 'share to a group'
              ) {
                hasForbiddenBadge = true;
              }
            }
            if (hasTitle && hasGroupBadge && !hasForbiddenBadge) return true;
          }
          return false;
        };

        let modal = null;
        let searchInput = null;
        for (let i = 0; i < 16; i++) {
          const found = findShareGroupModal();
          if (found.modal && found.searchInput) {
            modal = found.modal;
            searchInput = found.searchInput;
            break;
          }
          await sleep(400);
        }
        if (!modal) {
          return { ok: false, reason: 'Không tìm thấy hộp thoại "Chia sẻ lên nhóm"' };
        }

        const setReactInputValue = async (inputEl, text) => {
          if (!inputEl) return;
          inputEl.focus();
          inputEl.click();
          await sleep(150);
          const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
          const tracker = inputEl._valueTracker;
          if (tracker) tracker.setValue('__fb_force_diff_' + Math.random());
          if (nativeSetter) nativeSetter.call(inputEl, text);
          else inputEl.value = text;
          inputEl.dispatchEvent(new InputEvent('input', {
            bubbles: true,
            cancelable: true,
            inputType: text ? 'insertText' : 'deleteContentBackward',
            data: text || null
          }));
          inputEl.dispatchEvent(new Event('change', { bubbles: true }));
          inputEl.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: text ? text.slice(-1) : 'Backspace' }));
          inputEl.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: text ? text.slice(-1) : 'Backspace' }));
          await sleep(350);
        };

        const targetNorm = normalize(targetGroupName);
        const isNumericTarget = /^\d{8,20}$/.test(targetGroupId);
        const targetUniqueWords = Array.from(new Set(targetNorm.split(' ').filter((w) => w.length >= 1)));
        const targetWordSet = new Set(targetUniqueWords);
        const isTargetTruncated = /(\.\.\.|…)\s*$/.test(String(targetGroupName || '').trim());

        // Safe, bounded React Fiber/Props inspector to extract real Facebook Group ID from a row
        const extractRowGroupIds = (rowEl) => {
          const found = new Set();
          if (!rowEl) return found;
          const seen = new WeakSet();
          const isNumId = (v) => typeof v === 'string' && /^\d{8,20}$/.test(v);

          const scanObj = (obj, depth) => {
            if (!obj || typeof obj !== 'object' || depth > 4) return;
            if (seen.has(obj)) return;
            try { seen.add(obj); } catch (e) { return; }
            if (Array.isArray(obj)) {
              for (let i = 0; i < Math.min(obj.length, 6); i++) scanObj(obj[i], depth + 1);
              return;
            }
            const gKeys = ['groupID', 'groupId', 'group_id', 'targetGroupID', 'targetGroupId'];
            for (const k of gKeys) {
              try {
                const v = obj[k];
                if (isNumId(String(v || ''))) found.add(String(v));
              } catch (e) {}
            }
            try {
              const tn = obj.__typename || obj.type || '';
              if (
                (tn === 'Group' ||
                  'group_member_profiles' in obj ||
                  'visibility' in obj ||
                  (typeof obj.url === 'string' && obj.url.includes('/groups/')) ||
                  (typeof obj.uri === 'string' && obj.uri.includes('/groups/'))) &&
                isNumId(String(obj.id || ''))
              ) {
                found.add(String(obj.id));
              }
              if (typeof obj.url === 'string') {
                const m = obj.url.match(/\/groups\/(\d{8,20})\b/);
                if (m) found.add(m[1]);
              }
              if (typeof obj.uri === 'string') {
                const m = obj.uri.match(/\/groups\/(\d{8,20})\b/);
                if (m) found.add(m[1]);
              }
            } catch (e) {}
            const nextKeys = ['group', 'node', 'item', 'target', 'entity', 'destination', 'shareTarget', 'data', 'props', 'entrypoint'];
            for (const k of nextKeys) {
              try {
                if (obj[k] && typeof obj[k] === 'object') scanObj(obj[k], depth + 1);
              } catch (e) {}
            }
          };

          const inspectNode = (domNode) => {
            if (!domNode) return;
            try {
              const keys = Object.keys(domNode);
              const propsKey = keys.find((k) => k.startsWith('__reactProps$'));
              if (propsKey) scanObj(domNode[propsKey], 0);
              const fiberKey = keys.find((k) => k.startsWith('__reactFiber$') || k.startsWith('__reactInternalInstance$'));
              let cur = fiberKey ? domNode[fiberKey] : null;
              let steps = 0;
              while (cur && steps < 7) {
                // Stop climbing if we left the row into a container holding multiple rows
                if (
                  cur.stateNode &&
                  cur.stateNode instanceof HTMLElement &&
                  cur.stateNode !== domNode &&
                  cur.stateNode.contains(rowEl) &&
                  cur.stateNode.querySelectorAll('[role="button"]').length > 2
                ) {
                  break;
                }
                if (cur.memoizedProps) scanObj(cur.memoizedProps, 0);
                cur = cur.return;
                steps++;
              }
            } catch (e) {}
          };

          inspectNode(rowEl);
          if (found.size === 0 && rowEl.firstElementChild) {
            inspectNode(rowEl.firstElementChild);
          }
          return found;
        };

        const getVisibleListSignature = () => {
          const rows = Array.from(modal.querySelectorAll('[role="button"], [role="listitem"], a[href*="/groups/"]'));
          const titles = [];
          for (const el of rows) {
            const r = el.getBoundingClientRect();
            if (r.width < 160 || r.height < 36 || r.height > 150) continue;
            if (searchInput && el.contains(searchInput)) continue;
            const t = (el.innerText || '').trim().split('\n')[0] || '';
            if (t) titles.push(t);
            if (titles.length >= 6) break;
          }
          return titles.join(' || ');
        };

        const findBestGroupRow = (allowStrictFuzzy = false) => {
          const rows = Array.from(modal.querySelectorAll('[role="button"], [role="listitem"], a[href*="/groups/"]'));
          let bestMatch = null;

          for (const el of rows) {
            const r = el.getBoundingClientRect();
            if (r.width < 160 || r.height < 36 || r.height > 150) continue;
            if (searchInput && el.contains(searchInput)) continue;
            const aria = normalize(el.getAttribute('aria-label') || '');
            if (aria === 'dong' || aria === 'close' || aria === 'quay lai' || aria === 'back') continue;

            const href = el.getAttribute('href') || el.querySelector('a')?.getAttribute('href') || '';
            const fullText = el.innerText || '';
            const hasGroupSub = /(nhóm công khai|nhóm riêng tư|public group|private group)/i.test(fullText);
            const rawLines = fullText
              .split('\n')
              .map((l) => l.trim())
              .filter((l) => l && !/^(nhóm công khai|nhóm riêng tư|public group|private group|tất cả các nhóm|all groups|kết quả tìm kiếm|search results|không tìm thấy kết quả|no results found)$/i.test(l));
            const titleLine = rawLines[0] || '';
            const normTitle = normalize(titleLine);

            // Extract real numeric Facebook Group ID from href or React Fiber
            const rowGroupIds = extractRowGroupIds(el);
            const hrefMatch = href.match(/\/groups\/(\d{8,20})\b/);
            if (hrefMatch) rowGroupIds.add(hrefMatch[1]);
            const singleRowId = rowGroupIds.size === 1 ? Array.from(rowGroupIds)[0] : null;

            // TIER 1: Exact Group ID Match (href or React Fiber) -> 100% guaranteed right group!
            if (
              targetGroupId &&
              ((href && href.includes(`/groups/${targetGroupId}`)) ||
                (isNumericTarget && rowGroupIds.size > 0 && rowGroupIds.size <= 2 && rowGroupIds.has(targetGroupId)))
            ) {
              return { el, title: titleLine || targetGroupName, score: 10000, matchType: 'exact_id', groupId: targetGroupId };
            }

            // HARD ID CONFLICT GUARD: If this row unambiguously belongs to a DIFFERENT numeric Group ID, NEVER click it!
            if (isNumericTarget && singleRowId && singleRowId !== targetGroupId) {
              continue;
            }

            if (!normTitle || normTitle.length < 2 || !targetNorm) continue;
            const bonus = hasGroupSub ? 50 : 0;

            // TIER 2: Exact normalized title match
            if (normTitle === targetNorm) {
              const cand = { el, title: titleLine, score: 5000 + bonus, matchType: 'exact_title', groupId: singleRowId };
              if (!bestMatch || cand.score > bestMatch.score) bestMatch = cand;
              continue;
            }

            // TIER 3: Ellipsis-truncated exact prefix match (e.g. long group name cut off with "..." by Facebook UI)
            const isRowTruncated = /(\.\.\.|…)\s*$/.test(titleLine);
            if (isRowTruncated && normTitle.length >= Math.min(18, Math.floor(targetNorm.length * 0.45)) && targetNorm.startsWith(normTitle)) {
              const cand = { el, title: titleLine, score: 3000 + bonus + normTitle.length, matchType: 'truncated_prefix', groupId: singleRowId };
              if (!bestMatch || cand.score > bestMatch.score) bestMatch = cand;
              continue;
            }
            if (isTargetTruncated && targetNorm.length >= Math.min(18, Math.floor(normTitle.length * 0.45)) && normTitle.startsWith(targetNorm)) {
              const cand = { el, title: titleLine, score: 2900 + bonus + targetNorm.length, matchType: 'target_truncated_prefix', groupId: singleRowId };
              if (!bestMatch || cand.score > bestMatch.score) bestMatch = cand;
              continue;
            }

            // TIER 4: Strict bidirectional whole-word match (ONLY after searching, NEVER on unfiltered recent list!)
            if (allowStrictFuzzy && targetUniqueWords.length > 0) {
              const rowUniqueWords = Array.from(new Set(normTitle.split(' ').filter((w) => w.length >= 1)));
              const rowWordSet = new Set(rowUniqueWords);
              const common = targetUniqueWords.filter((w) => rowWordSet.has(w)).length;
              const recall = common / targetWordSet.size;
              const precision = rowWordSet.size > 0 ? common / rowWordSet.size : 0;
              const lenRatio = Math.min(normTitle.length, targetNorm.length) / Math.max(normTitle.length, targetNorm.length);

              if (recall >= 0.85 && precision >= 0.85 && lenRatio >= 0.78 && common >= Math.min(2, targetWordSet.size)) {
                const score = Math.round((recall + precision) * 500 + lenRatio * 200) + bonus;
                const cand = { el, title: titleLine, score, matchType: 'strict_fuzzy', groupId: singleRowId };
                if (!bestMatch || cand.score > bestMatch.score) bestMatch = cand;
              }
            }
          }
          return bestMatch;
        };

        // Pass 1 (before searching): ONLY accept exact ID, exact title, or exact truncated prefix!
        let matched = findBestGroupRow(false);

        const cleanFull = stripEmojiAndPunct(targetGroupName);
        const cleanWords = cleanFull.split(' ').filter(Boolean);
        const queries = [];
        const pushQ = (q) => {
          const s = String(q || '').trim();
          if (s.length >= 2 && !queries.includes(s)) queries.push(s);
        };

        // Build full-name-first search queries so Facebook narrows directly to the exact group
        if (cleanFull.length >= 2) {
          let trimmedFull = cleanFull.slice(0, 65).trim();
          if (cleanFull.length > 65 && trimmedFull.includes(' ')) {
            trimmedFull = trimmedFull.slice(0, trimmedFull.lastIndexOf(' ')).trim();
          }
          pushQ(trimmedFull);
        }
        const rawTrimmed = String(targetGroupName || '').replace(/(\.\.\.|…)\s*$/, '').trim().slice(0, 65).trim();
        if (rawTrimmed.length >= 2) pushQ(rawTrimmed);
        if (cleanWords.length > 6) pushQ(cleanWords.slice(0, 6).join(' '));
        if (cleanWords.length > 4) pushQ(cleanWords.slice(0, 4).join(' '));
        if (cleanWords.length > 3) pushQ(cleanWords.slice(0, 3).join(' '));
        if (cleanWords.length > 5) pushQ(cleanWords.slice(-4).join(' '));

        for (const q of queries) {
          if (matched) break;
          if (!searchInput) break;
          const beforeSig = getVisibleListSignature();
          await setReactInputValue(searchInput, q);
          await sleep(750);
          for (let waitStep = 0; waitStep < 6; waitStep++) {
            const afterSig = getVisibleListSignature();
            const listUpdated = afterSig !== beforeSig || waitStep >= 2;
            matched = findBestGroupRow(listUpdated);
            if (matched) break;
            await sleep(500);
          }
        }

        // Fallback: Clear search & scroll through full group list with exact + strict matching
        if (!matched) {
          if (searchInput && searchInput.value) {
            await setReactInputValue(searchInput, '');
            await sleep(1200);
          }
          const scrollContainers = [modal, ...Array.from(modal.querySelectorAll('div'))].filter((el) => {
            const st = window.getComputedStyle(el);
            return (st.overflowY === 'auto' || st.overflowY === 'scroll') && el.scrollHeight > el.clientHeight + 25;
          });
          const sc = scrollContainers[0];
          if (sc) {
            let prevTop = -1;
            for (let s = 0; s < 18; s++) {
              matched = findBestGroupRow(true);
              if (matched) break;
              sc.scrollTop += 340;
              await sleep(550);
              if (sc.scrollTop === prevTop) break;
              prevTop = sc.scrollTop;
            }
          }
        }

        if (!matched || !matched.el) {
          return {
            ok: false,
            reason: `Không tìm thấy đúng nhóm "${targetGroupName || targetGroupId}" trong danh sách Chia sẻ lên nhóm (đã dừng an toàn để không chia sẻ nhầm sang nhóm khác)`
          };
        }

        const clickable = matched.el.closest('[role="button"]') || matched.el;
        safeClick(clickable);

        for (let w = 0; w < 18; w++) {
          await sleep(500);
          if (isGroupCreatePostOpen()) {
            await sleep(2200); // Human-paced wait so Group modal & embedded Page preview fully settle!
            return { ok: true, matchedTitle: matched.title, matchType: matched.matchType, matchedGroupId: matched.groupId || null };
          }
          if (w === 3 && searchInput && document.body.contains(searchInput) && searchInput.getBoundingClientRect().height > 0) {
            const innerSpan = clickable.querySelector('span');
            if (innerSpan) safeClick(innerSpan);
            else clickable.click();
          }
        }

        return {
          ok: false,
          reason: `Đã bấm nhóm "${matched.title || targetGroupName || targetGroupId}" nhưng khung "Tạo bài viết" của Nhóm không mở ra — đã dừng để không chia sẻ nhầm lên trang cá nhân`
        };
      }
    });
    if (!step3[0]?.result?.ok) {
      return { ok: false, reason: step3[0]?.result?.reason || 'Không chọn được nhóm trong hộp thoại Chia sẻ lên nhóm' };
    }
    const matchedLabel = step3[0].result.matchedTitle || displayGroup;
    sendMessage(uiTabId, 'status_update', `🎯 Đã chọn đúng nhóm "${matchedLabel}" (${step3[0].result.matchType || 'exact'}) — kiểm tra khung Đăng...`);

    // Step 4: Element-level verified Group "Tạo bài viết" ONLY, pause 1.2s before single click on "Đăng",
    //   and capture real Group Post Link via XMLHttpRequest + fetch + Facebook "Xem bài viết" toast!
    sendMessage(uiTabId, 'status_update', `✅ Xác nhận đúng khung Nhóm — chờ 1.2s rồi bấm Đăng lên "${displayGroup}"...`);
    const step4 = await chrome.scripting.executeScript({
      target: { tabId: workTabId },
      world: 'MAIN',
      args: [String(groupId || '')],
      func: async (gid) => {
        const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
        const norm = (s) =>
          String(s || '')
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/đ/g, 'd')
            .replace(/\s+/g, ' ')
            .trim();

        let capturedLink = null;
        let isPending = false;
        let clickTime = 0;

        const parseGraphqlResponse = (txt) => {
          if (!txt || typeof txt !== 'string' || !clickTime) return;
          const hasStoryMutation =
            txt.includes('story_create') ||
            txt.includes('group_post_create') ||
            txt.includes('ComposerStoryCreate') ||
            txt.includes('GroupComet') ||
            txt.includes('reshare') ||
            txt.includes('my_pending_content') ||
            txt.includes('pending_post');
          if (!hasStoryMutation) return;

          if (
            txt.includes('GROUP_POST_PENDING') ||
            txt.includes('YOUR_POST_IS_PENDING') ||
            /"is_pending_post"\s*:\s*true/i.test(txt) ||
            /"pending_post_id"\s*:\s*"\d{5,}"/i.test(txt) ||
            /"group_post_status"\s*:\s*"PENDING"/i.test(txt)
          ) {
            isPending = true;
          }

          const cleanCaptured = (raw) => String(raw || '').replace(/\\\//g, '/').replace(/([^:]\/)\/+/g, '$1').replace(/\/+$/, '') + '/';
          const escMatches = txt.match(/https?:\\\/\\\/www\.facebook\.com\\\/groups\\\/[^"\\?]+\\\/(?:posts|permalink)\\\/[^"\\?]+/ig) || [];
          const plainMatches = txt.match(/https?:\/\/www\.facebook\.com\/groups\/[^"?\s]+\/(?:posts|permalink)\/[^"?\s]+/ig) || [];
          const allLinks = [...escMatches, ...plainMatches].map(cleanCaptured);
          if (allLinks.length > 0) {
            const exactGidLink = gid ? allLinks.find((u) => u.includes(`/groups/${gid}/`)) : null;
            capturedLink = exactGidLink || allLinks[0];
            return;
          }

          if (gid) {
            const mId =
              txt.match(/"post_id"\s*:\s*"(\d{6,})"/) ||
              txt.match(/"legacy_fbid"\s*:\s*"(\d{6,})"/) ||
              txt.match(/"story_fbid"\s*:\s*"(\d{6,})"/);
            if (mId && mId[1]) {
              capturedLink = `https://www.facebook.com/groups/${gid}/posts/${mId[1]}/`;
            }
          }
        };

        const origFetch = window.fetch;
        window.fetch = async function (...args) {
          const res = await origFetch.apply(this, args);
          try {
            const url = typeof args[0] === 'string' ? args[0] : (args[0]?.url || '');
            if (url.includes('/api/graphql')) {
              res.clone().text().then(parseGraphqlResponse).catch(() => {});
            }
          } catch (e) {}
          return res;
        };

        const origOpen = XMLHttpRequest.prototype.open;
        const origSend = XMLHttpRequest.prototype.send;
        XMLHttpRequest.prototype.open = function (m, u) {
          this.__fbShareUrl = typeof u === 'string' ? u : '';
          return origOpen.apply(this, arguments);
        };
        XMLHttpRequest.prototype.send = function () {
          this.addEventListener('load', function () {
            try {
              if (this.__fbShareUrl && this.__fbShareUrl.includes('/api/graphql') && typeof this.responseText === 'string') {
                parseGraphqlResponse(this.responseText);
              }
            } catch (e) {}
          });
          return origSend.apply(this, arguments);
        };

        const scanToastForLink = () => {
          const links = Array.from(document.querySelectorAll('a[href*="/groups/"]'));
          for (const a of links) {
            const r = a.getBoundingClientRect();
            if (r.width === 0 || r.height === 0) continue;
            const href = a.getAttribute('href') || '';
            const full = href.startsWith('/') ? 'https://www.facebook.com' + href : href;
            const m = full.match(/https?:\/\/www\.facebook\.com\/groups\/[^/?#]+\/(?:posts|permalink)\/[^/?#&]+/i);
            if (m) return { link: m[0].replace(/\/+$/, '') + '/', pending: false };
            const mp = full.match(/[?&]multi_permalinks=(\d+)/i);
            if (mp && gid) return { link: `https://www.facebook.com/groups/${gid}/posts/${mp[1]}/`, pending: false };
            if (full.includes('/my_pending_content')) return { link: `https://www.facebook.com/groups/${gid}/my_pending_content`, pending: true };
          }
          const alerts = Array.from(document.querySelectorAll('[role="status"], [role="alert"], [data-visualcompletion="ignore-dynamic"]'));
          for (const al of alerts) {
            const t = norm(al.innerText || '');
            if (t.includes('cho phe duyet') || t.includes('cho quan tri vien') || t.includes('waiting for approval') || t.includes('pending approval')) {
              return { link: null, pending: true };
            }
          }
          return null;
        };

        // ELEMENT-LEVEL HARD SAFETY CHECK:
        // Inspects short badge elements in the top 45% of the dialog — NEVER tricked by post caption text!
        const isVerifiedGroupComposer = (dlg) => {
          if (!dlg || !document.body.contains(dlg)) return false;
          const dr = dlg.getBoundingClientRect();
          if (dr.width < 280 || dr.height < 240) return false;
          const topCutoff = dr.top + dr.height * 0.45;

          let hasTitle = false;
          let hasGroupBadge = false;
          let hasForbiddenBadge = false;

          const nodes = Array.from(dlg.querySelectorAll('h1, h2, h3, span, div[role="heading"], div[role="button"]'));
          for (const el of nodes) {
            const r = el.getBoundingClientRect();
            if (r.width === 0 || r.height === 0 || r.top > topCutoff) continue;
            const raw = (el.innerText || '').trim();
            if (!raw || raw.length > 40 || raw.includes('\n')) continue;
            const t = norm(raw);
            if (t === 'tao bai viet' || t === 'create post') hasTitle = true;
            if (
              t === 'nhom cong khai' ||
              t === 'nhom rieng tu' ||
              t === 'public group' ||
              t === 'private group' ||
              t.startsWith('thanh vien cua ') ||
              t.startsWith('members of ')
            ) {
              hasGroupBadge = true;
            }
            if (
              t === 'cong khai' ||
              t === 'public' ||
              t === 'ban be' ||
              t === 'friends' ||
              t === 'chi minh toi' ||
              t === 'only me' ||
              t === 'bang feed' ||
              t === 'news feed' ||
              t === 'chia se ngay' ||
              t === 'share now' ||
              t === 'chia se len nhom' ||
              t === 'share to a group'
            ) {
              hasForbiddenBadge = true;
            }
          }

          return hasTitle && hasGroupBadge && !hasForbiddenBadge;
        };

        const findVerifiedGroupPostButton = () => {
          const dialogs = Array.from(document.querySelectorAll('[role="dialog"]')).filter(isVerifiedGroupComposer);
          if (dialogs.length === 0) return null;

          const candidates = [];
          for (const dlg of dialogs) {
            const btns = Array.from(dlg.querySelectorAll('[role="button"], button'));
            for (const btn of btns) {
              if (btn.getAttribute('aria-disabled') === 'true' || btn.disabled) continue;
              const r = btn.getBoundingClientRect();
              if (r.width < 80 || r.height < 28) continue;
              const aria = norm(btn.getAttribute('aria-label') || '');
              const txt = norm(btn.innerText || btn.textContent || '');
              if (aria === 'dang' || aria === 'post' || txt === 'dang' || txt === 'post') {
                candidates.push({ btn, dlg, width: r.width });
              }
            }
          }
          if (candidates.length > 0) {
            candidates.sort((a, b) => b.width - a.width);
            return candidates[0];
          }
          return null;
        };

        let found = null;
        for (let i = 0; i < 20; i++) {
          found = findVerifiedGroupPostButton();
          if (found) break;
          await sleep(500);
        }

        if (!found || !found.btn) {
          return {
            ok: false,
            reason: 'Không xác nhận được nhãn "Nhóm công khai / Nhóm riêng tư" trong khung Tạo bài viết — đã dừng để không chia sẻ nhầm lên trang cá nhân!'
          };
        }

        // Verify composer React Fiber target Group ID (if exposed) matches requested numeric Group ID!
        const extractComposerGroupIds = (dlg) => {
          const ids = new Set();
          if (!dlg) return ids;
          const seen = new WeakSet();
          const isNumId = (v) => typeof v === 'string' && /^\d{8,20}$/.test(v);
          const scanObj = (obj, depth) => {
            if (!obj || typeof obj !== 'object' || depth > 4) return;
            if (seen.has(obj)) return;
            try { seen.add(obj); } catch (e) { return; }
            if (Array.isArray(obj)) {
              for (let i = 0; i < Math.min(obj.length, 6); i++) scanObj(obj[i], depth + 1);
              return;
            }
            for (const k of ['groupID', 'groupId', 'group_id', 'targetGroupID', 'targetGroupId']) {
              try {
                const v = obj[k];
                if (isNumId(String(v || ''))) ids.add(String(v));
              } catch (e) {}
            }
            try {
              const tn = obj.__typename || obj.type || '';
              if (tn === 'Group' && isNumId(String(obj.id || ''))) ids.add(String(obj.id));
            } catch (e) {}
            for (const k of ['group', 'target', 'destination', 'composerData', 'props', 'data']) {
              try {
                if (obj[k] && typeof obj[k] === 'object') scanObj(obj[k], depth + 1);
              } catch (e) {}
            }
          };
          try {
            const fKey = Object.keys(dlg).find((k) => k.startsWith('__reactFiber$') || k.startsWith('__reactInternalInstance$'));
            let cur = fKey ? dlg[fKey] : null;
            let steps = 0;
            while (cur && steps < 10) {
              if (cur.memoizedProps) scanObj(cur.memoizedProps, 0);
              cur = cur.return;
              steps++;
            }
          } catch (e) {}
          return ids;
        };

        // Calm 1.2s pause + re-verify RIGHT before clicking "Đăng" (never rush!)
        await sleep(1200);
        if (!isVerifiedGroupComposer(found.dlg) || !document.body.contains(found.btn) || found.btn.getAttribute('aria-disabled') === 'true') {
          return {
            ok: false,
            reason: 'Khung Tạo bài viết của nhóm đã thay đổi trước khi bấm Đăng — đã dừng an toàn!'
          };
        }
        if (/^\d{8,20}$/.test(gid)) {
          const composerIds = extractComposerGroupIds(found.dlg);
          if (composerIds.size === 1 && !composerIds.has(gid)) {
            const wrongId = Array.from(composerIds)[0];
            return {
              ok: false,
              reason: `Khung Tạo bài viết đang mở nhầm sang nhóm khác (ID ${wrongId} ≠ ${gid}) — đã dừng an toàn trước khi bấm Đăng!`
            };
          }
        }

        const { btn: postBtn, dlg: composerDialog } = found;
        clickTime = Date.now();
        postBtn.scrollIntoView({ block: 'center', inline: 'center' });
        postBtn.click();

        let submitted = false;
        let closedAt = 0;
        for (let w = 0; w < 22; w++) {
          await sleep(500);

          const toastInfo = scanToastForLink();
          if (toastInfo) {
            if (toastInfo.pending) isPending = true;
            if (toastInfo.link && !capturedLink) capturedLink = toastInfo.link;
          }

          const modalClosed = !document.body.contains(composerDialog) || composerDialog.getBoundingClientRect().height < 40;
          if (modalClosed && !closedAt) {
            submitted = true;
            closedAt = Date.now();
          }

          if (capturedLink && (submitted || capturedLink.includes('/posts/') || capturedLink.includes('/permalink/'))) {
            submitted = true;
            break;
          }

          if (submitted && closedAt && Date.now() - closedAt >= 2500) {
            break;
          }

          if (w === 6 && !submitted && isVerifiedGroupComposer(composerDialog) && document.body.contains(postBtn) && postBtn.getAttribute('aria-disabled') !== 'true') {
            postBtn.click();
          }
        }

        if (!submitted) {
          return {
            ok: false,
            reason: 'Đã bấm Đăng trong nhóm nhưng Facebook chưa xác nhận đóng hộp thoại (có thể mạng chậm hoặc nhóm chặn chia sẻ)'
          };
        }

        return {
          ok: true,
          submitted: true,
          isPending,
          hasExactLink: Boolean(capturedLink && (capturedLink.includes('/posts/') || capturedLink.includes('/permalink/'))),
          postLink: capturedLink || null
        };
      }
    });

    if (!step4[0]?.result?.ok) {
      return { ok: false, reason: step4[0]?.result?.reason || 'Không bấm được nút Đăng khi chia sẻ lên nhóm' };
    }

    const r4 = step4[0].result;
    let finalLink = r4.postLink ? String(r4.postLink).trim().replace(/\\\//g, '/').replace(/([^:]\/)\/+/g, '$1') : null;
    const isPending = !!r4.isPending;

    if (!r4.hasExactLink && !isPending && groupId) {
      sendMessage(uiTabId, 'status_update', `🔍 Đang lấy link trực tiếp bài vừa chia sẻ trong "${displayGroup}"...`);
      const fetched = await fetchLatestGroupPostLink(workTabId, groupId);
      if (fetched) finalLink = fetched;
    }

    if (!finalLink && groupId) {
      finalLink = isPending
        ? `https://www.facebook.com/groups/${groupId}/my_pending_content`
        : `https://www.facebook.com/groups/${groupId}/my_posted_content`;
    }

    if (finalLink && /^\d{8,20}$/.test(String(groupId || ''))) {
      const mCapGid = finalLink.match(/\/groups\/(\d{8,20})\//);
      if (mCapGid && mCapGid[1] !== String(groupId)) {
        return {
          ok: false,
          reason: `Link trả về thuộc nhóm khác (${mCapGid[1]} ≠ ${groupId}) — vui lòng kiểm tra lại nhóm "${displayGroup}"`
        };
      }
    }

    return {
      ok: true,
      isPending,
      postLink: finalLink
    };
  } catch (err) {
    return { ok: false, reason: err.message || String(err) };
  }
}
async function sharePostToGroup(uiTabId, { groupId, groupName = '', groupUrl = '', postUrl = '' }) {
  let workTabId = null;
  try {
    if (!postUrl || !/(facebook\.com|fb\.watch|fb\.com)/i.test(postUrl)) {
      sendMessage(uiTabId, 'SHARE_ERROR', { groupId, groupName, message: 'URL bài viết không hợp lệ' });
      return;
    }

    // Create a silent background worker tab ONCE so user's other work/tabs are never interrupted
    const created = await chrome.tabs.create({ url: 'about:blank', active: false });
    workTabId = created.id;

    // Pure Native Group Reshare ONLY (Chia sẻ -> Nhóm -> Chọn nhóm -> Đăng, NO extra text, NEVER Newsfeed/Profile!)
    let nativeRes = await shareViaNativeDialog(uiTabId, workTabId, postUrl, groupId, groupName);

    // Automatic 1-time clean retry ONLY for transient UI failures (never retry invalid/Newsfeed URLs)
    if (!nativeRes.ok && !/Newsfeed|không phải link bài viết/i.test(nativeRes.reason || '')) {
      sendMessage(uiTabId, 'status_update', `🔁 Thử lại chia sẻ trực tiếp lên "${groupName || groupId}" (${nativeRes.reason})...`);
      await delay(1500);
      nativeRes = await shareViaNativeDialog(uiTabId, workTabId, postUrl, groupId, groupName);
    }

    if (nativeRes.ok) {
      sendMessage(uiTabId, 'STATUS_UPDATE', `✅ Đã chia sẻ trực tiếp bài gốc lên "${groupName || groupId}"!`);
      sendMessage(uiTabId, 'SHARE_SUCCESS', {
        groupId,
        groupName,
        sharedLink: (nativeRes.postLink || postUrl || '').replace(/([^:]\/)\/+/g, '$1'),
        postUrl: (nativeRes.postLink || postUrl || '').replace(/([^:]\/)\/+/g, '$1'),
        isPending: !!nativeRes.isPending
      });
      return;
    }

    throw new Error(nativeRes.reason || 'Không thể chia sẻ bài viết lên nhóm');
  } catch (error) {
    console.error('[SharePost] Error:', error);
    sendMessage(uiTabId, 'SHARE_ERROR', { groupId, groupName, message: error.message });
  } finally {
    if (workTabId) {
      try { await chrome.tabs.remove(workTabId); } catch (e) {}
    }
  }
}
async function getOrCreateFbTab() {
  const fbTabs = await chrome.tabs.query({ url: '*://*.facebook.com/*' });
  let tabId;
  if (fbTabs.length > 0) {
    tabId = fbTabs[0].id;
  } else {
    const newTab = await chrome.tabs.create({ url: 'https://www.facebook.com/', active: false });
    await waitForPageLoad(newTab.id, 5000);
    tabId = newTab.id;
  }

  // Setup doc_id interception on the Facebook tab
  try {
    await setupDocIdInterception(tabId);
  } catch (e) {
    console.warn('[getOrCreateFbTab] Failed to setup interception:', e);
  }

  return tabId;
}

async function waitForPageLoad(tabId, timeout = 12000) {
  return new Promise((resolve) => {
    const startTime = Date.now();
    const check = () => {
      chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          resolve();
          return;
        }
        if (tab.status === 'complete' || Date.now() - startTime > timeout) {
          resolve();
        } else {
          setTimeout(check, 250);
        }
      });
    };
    setTimeout(check, 350);
  });
}

async function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ========================================
// User Pages Extraction (mbasic approach - NO tab redirects)
// ========================================
async function fetchUserPages(uiTabId) {
  let tempTabId = null;
  try {
    sendMessage(uiTabId, 'status_update', '🔍 Đang quét toàn bộ Trang (Page) của tài khoản cá nhân...');

    let personalUid = null;
    let activeActingPageId = null;
    try {
      const cUser = await chrome.cookies.get({ url: 'https://www.facebook.com', name: 'c_user' });
      const iUser = await chrome.cookies.get({ url: 'https://www.facebook.com', name: 'i_user' });
      if (cUser && cUser.value) personalUid = String(cUser.value);
      if (iUser && iUser.value && String(iUser.value) !== personalUid) {
        activeActingPageId = String(iUser.value);
      }
    } catch (e) {}

    const pagesMap = new Map();
    const nameKeyToId = new Map();

    const JUNK_NAMES = new Set([
      'facebook', 'trang của bạn', 'your pages', 'tạo trang mới', 'create new page',
      'khám phá', 'discover', 'trang đã thích', 'liked pages', 'lời mời', 'invites',
      'chuyển ngay', 'switch now', 'quản lý', 'manage', 'xem thêm', 'see more',
      'meta business suite', 'trung tâm quảng cáo', 'ad center', 'thông tin chi tiết',
      'insights', 'bảng điều khiển chuyên nghiệp', 'professional dashboard', 'quảng cáo',
      'xem tất cả trang cá nhân', 'see all profiles', 'tạo trang', 'create page',
      'trang cá nhân của bạn', 'your profile', 'trang chủ', 'home', 'menu', 'thông báo',
      'notifications', 'bạn', 'you', 'đóng', 'close', 'cài đặt', 'settings',
      'trợ giúp và hỗ trợ', 'help & support', 'đăng xuất', 'log out', 'chuyển sang trang',
      'switch to page', 'truy cập trang', 'visit page', 'chỉnh sửa', 'edit', 'xem trang',
      'tất cả trang', 'all pages', 'trang bạn quản lý', 'pages you manage'
    ]);

    const decodeUnicodeStr = (str) => {
      if (!str) return '';
      let out = String(str);
      try {
        out = out.replace(/\\u([0-9a-fA-F]{4})/g, (_, g) => String.fromCharCode(parseInt(g, 16)));
      } catch (e) {}
      return out.replace(/\\\//g, '/').replace(/\uFFFD/g, '').replace(/\s+/g, ' ').trim();
    };

    const normalizePageUrl = (rawUrl, fallbackId) => {
      if (rawUrl && typeof rawUrl === 'string') {
        let u = decodeUnicodeStr(rawUrl);
        if (u.startsWith('/')) u = 'https://www.facebook.com' + u;
        try {
          const parsed = new URL(u);
          if (parsed.hostname.includes('facebook.com')) {
            if (parsed.pathname === '/profile.php') {
              const pid = parsed.searchParams.get('id');
              if (pid && /^\d+$/.test(pid)) return `https://www.facebook.com/profile.php?id=${pid}`;
            }
            const cleanPath = parsed.pathname.replace(/\/+$/, '');
            if (cleanPath && cleanPath !== '/') {
              return `https://www.facebook.com${cleanPath}`;
            }
          }
        } catch (e) {}
      }
      if (fallbackId && /^\d+$/.test(String(fallbackId))) {
        return `https://www.facebook.com/profile.php?id=${fallbackId}`;
      }
      if (fallbackId && !String(fallbackId).startsWith('slug_')) {
        return `https://www.facebook.com/${fallbackId}`;
      }
      return '';
    };

    const addPage = (rawId, rawName, rawImg, rawUrl) => {
      const name = decodeUnicodeStr(rawName);
      if (!name || name.length < 2 || name.length > 140) return;
      const lower = name.toLowerCase();
      if (JUNK_NAMES.has(lower)) return;
      if (/^(chuyển sang|switch to|tạo |create |xem tất cả|see all|\d+\s*(thông báo|notification|người theo dõi|follower|lượt thích|like))/i.test(lower)) return;

      let id = rawId ? String(rawId).trim() : '';
      if (id === personalUid) return;

      const url = normalizePageUrl(rawUrl, id);
      if (!id && url) {
        const mNum = url.match(/profile\.php\?id=(\d+)/) || url.match(/\/pages\/[^/]+\/(\d+)/) || url.match(/facebook\.com\/(\d{6,})/);
        if (mNum) {
          id = mNum[1];
        } else {
          const mSlug = url.match(/facebook\.com\/([^/?#]+)/);
          if (mSlug) id = 'slug_' + mSlug[1].toLowerCase();
        }
      }
      if (!id || id === personalUid) return;

      const image = rawImg ? decodeUnicodeStr(rawImg) : null;
      const nameKey = lower;

      // Merge slug/duplicate entry if we already have this page under another key
      let existingKey = pagesMap.has(id) ? id : (nameKeyToId.get(nameKey) || null);
      if (existingKey && pagesMap.has(existingKey)) {
        const cur = pagesMap.get(existingKey);
        const curIsNumeric = /^\d+$/.test(String(cur.id));
        const newIsNumeric = /^\d+$/.test(String(id));
        const merged = {
          id: newIsNumeric ? id : cur.id,
          name: cur.name.length >= name.length ? cur.name : name,
          image: cur.image || image || null,
          url: (url && !url.includes('profile.php?id=')) ? url : (cur.url || url || `https://www.facebook.com/profile.php?id=${newIsNumeric ? id : cur.id}`)
        };
        if (existingKey !== merged.id) {
          pagesMap.delete(existingKey);
        }
        pagesMap.set(merged.id, merged);
        nameKeyToId.set(nameKey, merged.id);
        return;
      }

      const finalUrl = url || (/^\d+$/.test(id) ? `https://www.facebook.com/profile.php?id=${id}` : `https://www.facebook.com/${id.replace(/^slug_/, '')}`);
      pagesMap.set(id, { id, name, image, url: finalUrl });
      nameKeyToId.set(nameKey, id);
    };

    const parsePagesFromHtml = (html) => {
      if (!html) return;
      const patterns = [
        /"__typename"\s*:\s*"(?:Page|AdditionalProfilePlus)"[^}]{0,600}?"id"\s*:\s*"(\d{5,})"[^}]{0,600}?"name"\s*:\s*"([^"]+)"(?:[^}]{0,600}?"uri"\s*:\s*"(https?:[^"]+)")?/g,
        /"id"\s*:\s*"(\d{5,})"[^}]{0,400}?"name"\s*:\s*"([^"]+)"[^}]{0,400}?"__typename"\s*:\s*"(?:Page|AdditionalProfilePlus)"/g,
        /"is_additional_profile_plus"\s*:\s*true[^}]{0,500}?"id"\s*:\s*"(\d{5,})"[^}]{0,500}?"name"\s*:\s*"([^"]+)"/g,
        /"id"\s*:\s*"(\d{5,})"[^}]{0,400}?"name"\s*:\s*"([^"]+)"[^}]{0,400}?"is_additional_profile_plus"\s*:\s*true/g,
        /"delegate_page"\s*:\s*\{[^}]*?"id"\s*:\s*"(\d{5,})"[^}]*?\}[^{]{0,350}?"name"\s*:\s*"([^"]+)"/g,
        /"additional_profile_plus"\s*:\s*\{[^}]*?"id"\s*:\s*"(\d{5,})"[^}]*?"name"\s*:\s*"([^"]+)"/g
      ];
      for (const re of patterns) {
        let m;
        while ((m = re.exec(html)) !== null) {
          addPage(m[1], m[2], m[3] || null, null);
        }
      }
    };

    // =========================================================================
    // PHASE 1: Fast background HTML fetches (classic + NPE SSR JSON)
    // =========================================================================
    const fastUrls = [
      'https://www.facebook.com/pages/?category=your_pages&ref=bookmarks',
      'https://www.facebook.com/'
    ];
    for (const u of fastUrls) {
      try {
        const response = await fetch(u, {
          headers: { 'accept': 'text/html,application/xhtml+xml' },
          credentials: 'include'
        });
        if (response.ok) {
          parsePagesFromHtml(await response.text());
        }
      } catch (e) {
        console.warn('[fetchUserPages] Fast fetch warning:', u, e);
      }
    }

    if (pagesMap.size > 0) {
      sendMessage(uiTabId, 'status_update', `📄 Tạm thấy ${pagesMap.size} Trang — đang quét sâu toàn bộ danh sách & Bộ chuyển đổi Page...`);
    } else {
      sendMessage(uiTabId, 'status_update', '🌐 Đang mở trang quản lý Page & Bộ chuyển đổi để quét toàn bộ Trang...');
    }

    // =========================================================================
    // PHASE 2 + PHASE 3: Hidden Tab with Live GraphQL Sniffer + Full Scroll
    //   + Profile Switcher ("Xem tất cả trang cá nhân" / "See all profiles")
    // =========================================================================
    const tab = await chrome.tabs.create({
      url: 'https://www.facebook.com/pages/?category=your_pages&ref=bookmarks',
      active: false
    });
    tempTabId = tab.id;
    await waitForPageLoad(tempTabId, 15000);
    await delay(1500);

    // Attach MAIN-world Fetch/XHR GraphQL sniffer BEFORE scrolling & clicking Profile Switcher
    await chrome.scripting.executeScript({
      target: { tabId: tempTabId },
      world: 'MAIN',
      func: (personalId) => {
        if (window.__fbPageSnifferInstalled) return;
        window.__fbPageSnifferInstalled = true;
        window.__fbSniffedPages = [];
        const seenIds = new Set();

        const recordPage = (id, name, image, url) => {
          if (!id || !name) return;
          const sid = String(id).trim();
          if (!/^\d{5,}$/.test(sid)) return;
          if (personalId && sid === String(personalId)) return;
          const cleanName = String(name).trim();
          if (cleanName.length < 2 || cleanName.length > 140) return;
          if (seenIds.has(sid)) return;
          seenIds.add(sid);
          window.__fbSniffedPages.push({
            id: sid,
            name: cleanName,
            image: image || null,
            url: url || `https://www.facebook.com/profile.php?id=${sid}`
          });
        };

        const extractImg = (obj) => {
          if (!obj || typeof obj !== 'object') return null;
          return obj.profile_picture?.uri ||
            obj.profile_picture_uri ||
            obj.profilePicture?.uri ||
            obj.profile_pic_uri ||
            obj.avatar?.uri ||
            obj.picture?.data?.url ||
            null;
        };

        const walkForPages = (root) => {
          const stack = [root];
          const visited = new Set();
          let steps = 0;
          while (stack.length > 0 && steps < 60000) {
            steps++;
            const cur = stack.pop();
            if (!cur || typeof cur !== 'object' || visited.has(cur)) continue;
            visited.add(cur);

            if (Array.isArray(cur)) {
              for (let i = 0; i < cur.length; i++) {
                if (cur[i] && typeof cur[i] === 'object') stack.push(cur[i]);
              }
              continue;
            }

            const tn = cur.__typename;
            const isExplicitPage =
              tn === 'Page' ||
              tn === 'AdditionalProfilePlus' ||
              cur.is_additional_profile_plus === true ||
              cur.is_profile_plus === true ||
              cur.is_business_person_account === true ||
              Boolean(cur.delegate_page && cur.delegate_page.id);

            if (isExplicitPage) {
              const pid = cur.id || cur.page_id || cur.delegate_page?.id;
              const pname = cur.name || cur.delegate_page?.name || cur.short_name;
              const pimg = extractImg(cur) || extractImg(cur.delegate_page);
              const purl = cur.url || cur.profile_url || cur.uri || cur.delegate_page?.url || null;
              if (pid && pname) recordPage(pid, pname, pimg, purl);
            }

            // Profile switcher list item containers (often wrap { profile: { id, name, ... } } or { account: ... })
            const switcherKeys = [
              'profile_switcher_eligible_profiles',
              'additional_profiles',
              'admined_pages',
              'your_pages',
              'managed_pages',
              'eligible_profiles',
              'profiles'
            ];
            for (const key of switcherKeys) {
              const container = cur[key];
              if (!container) continue;
              const list = Array.isArray(container)
                ? container
                : (Array.isArray(container.nodes) ? container.nodes : (Array.isArray(container.edges) ? container.edges.map(e => e && e.node) : null));
              if (list) {
                for (const item of list) {
                  if (!item || typeof item !== 'object') continue;
                  const p = item.profile || item.account || item.page || item.delegate_page || item;
                  const pid = p.id || p.user_id || p.page_id || item.id;
                  const pname = p.name || item.name || item.profile_name;
                  const pimg = extractImg(p) || extractImg(item);
                  const purl = p.url || p.uri || item.url || null;
                  if (pid && pname) recordPage(pid, pname, pimg, purl);
                }
              }
            }

            const vals = Object.values(cur);
            for (let i = 0; i < vals.length; i++) {
              if (vals[i] && typeof vals[i] === 'object') stack.push(vals[i]);
            }
          }
        };

        window.__fbWalkForPages = walkForPages;

        const inspectText = (txt) => {
          if (!txt || txt.length < 30) return;
          if (
            !txt.includes('"Page"') &&
            !txt.includes('AdditionalProfilePlus') &&
            !txt.includes('additional_profile') &&
            !txt.includes('profile_switcher') &&
            !txt.includes('delegate_page') &&
            !txt.includes('admined_pages') &&
            !txt.includes('your_pages')
          ) return;
          const lines = txt.replace(/^for\s*\(\s*;\s*;\s*\)\s*;\s*/, '').split('\n');
          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed || trimmed[0] !== '{') continue;
            try {
              walkForPages(JSON.parse(trimmed));
            } catch (e) {}
          }
        };

        // Hook fetch
        const origFetch = window.fetch;
        window.fetch = async function (...args) {
          const resp = await origFetch.apply(this, args);
          try {
            const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '';
            if (url.includes('/api/graphql') || url.includes('profile_switcher') || url.includes('pages')) {
              resp.clone().text().then(inspectText).catch(() => {});
            }
          } catch (e) {}
          return resp;
        };

        // Hook XHR
        const origOpen = XMLHttpRequest.prototype.open;
        const origSend = XMLHttpRequest.prototype.send;
        XMLHttpRequest.prototype.open = function (method, url) {
          this.__fbUrl = typeof url === 'string' ? url : '';
          return origOpen.apply(this, arguments);
        };
        XMLHttpRequest.prototype.send = function () {
          this.addEventListener('load', function () {
            try {
              if (this.__fbUrl && (this.__fbUrl.includes('/api/graphql') || this.__fbUrl.includes('profile_switcher'))) {
                inspectText(this.responseText);
              }
            } catch (e) {}
          });
          return origSend.apply(this, arguments);
        };

        // Immediately parse all SSR scripts already on the page
        const scripts = document.querySelectorAll('script[type="application/json"]');
        for (const s of scripts) {
          inspectText(s.textContent || '');
        }
      },
      args: [personalUid]
    });

    // Phase 2: Scroll /pages/?category=your_pages and click "Xem thêm / See more" to load ALL paginated pages
    const phase2Res = await chrome.scripting.executeScript({
      target: { tabId: tempTabId },
      world: 'MAIN',
      func: async () => {
        const sleep = (ms) => new Promise(r => setTimeout(r, ms));
        const main = document.querySelector('[role="main"]') || document.body;

        let stableCount = 0;
        let lastHeight = 0;
        let lastSniffCount = (window.__fbSniffedPages || []).length;

        for (let step = 0; step < 18; step++) {
          // Click any "See more" / "Xem thêm" / "Tải thêm" button inside [role="main"]
          const buttons = Array.from(main.querySelectorAll('[role="button"], button, a[role="link"]'));
          for (const btn of buttons) {
            const txt = (btn.innerText || btn.getAttribute('aria-label') || '').trim().toLowerCase();
            if (
              txt === 'xem thêm' ||
              txt === 'see more' ||
              txt === 'tải thêm' ||
              txt === 'load more' ||
              txt === 'hiển thị thêm' ||
              txt === 'show more'
            ) {
              try { btn.click(); await sleep(1000); } catch (e) {}
            }
          }

          window.scrollTo(0, document.body.scrollHeight);
          await sleep(1100);

          const curHeight = document.body.scrollHeight;
          const curSniffCount = (window.__fbSniffedPages || []).length;
          if (curHeight === lastHeight && curSniffCount === lastSniffCount) {
            stableCount++;
            if (stableCount >= 3) break;
          } else {
            stableCount = 0;
            lastHeight = curHeight;
            lastSniffCount = curSniffCount;
          }
        }

        // Re-scan SSR scripts + DOM cards in [role="main"] (supporting BOTH numeric IDs AND vanity usernames!)
        const domFound = [];
        const seenHref = new Set();
        const BLOCKED_ROOT = new Set([
          'pages', 'groups', 'friends', 'watch', 'marketplace', 'gaming', 'bookmarks',
          'messages', 'notifications', 'settings', 'help', 'events', 'saved', 'stories',
          'reels', 'reel', 'search', 'login', 'logout', 'privacy', 'policies', 'business',
          'ads', 'ad_center', 'adsmanager', 'professional_dashboard', 'latest', 'meta',
          'sharer', 'share', 'photo', 'photos', 'video', 'videos', 'media', 'composer',
          'me', 'home.php', 'index.php', 'hashtag', 'fundraisers', 'memories', 'gaming',
          'creators', 'creatorstudio', 'billing_hub', 'profile.php'
        ]);

        const anchors = Array.from(main.querySelectorAll('a[href]'));
        for (const a of anchors) {
          const rawHref = a.getAttribute('href') || '';
          if (!rawHref || rawHref === '#' || rawHref.startsWith('javascript:')) continue;
          let fullUrl = rawHref.startsWith('http') ? rawHref : ('https://www.facebook.com' + (rawHref.startsWith('/') ? rawHref : '/' + rawHref));
          let parsed;
          try { parsed = new URL(fullUrl); } catch (e) { continue; }
          if (!parsed.hostname.includes('facebook.com')) continue;

          let pageId = null;
          let cleanUrl = null;
          const parts = parsed.pathname.split('/').filter(Boolean);

          if (parsed.pathname === '/profile.php') {
            const idParam = parsed.searchParams.get('id');
            const sk = parsed.searchParams.get('sk');
            if (idParam && /^\d{5,}$/.test(idParam) && !sk) {
              pageId = idParam;
              cleanUrl = `https://www.facebook.com/profile.php?id=${idParam}`;
            }
          } else if (parts[0] === 'pages' && parts[2] && /^\d{5,}$/.test(parts[2])) {
            pageId = parts[2];
            cleanUrl = `https://www.facebook.com/pages/${parts[1]}/${parts[2]}`;
          } else if (parts[0] === 'people' && parts[2] && /^\d{5,}$/.test(parts[2])) {
            pageId = parts[2];
            cleanUrl = `https://www.facebook.com/people/${parts[1]}/${parts[2]}`;
          } else if (parts[0] === 'p' && parts[1]) {
            const mTail = parts[1].match(/(\d{6,})$/);
            pageId = mTail ? mTail[1] : ('slug_' + parts[1].toLowerCase());
            cleanUrl = `https://www.facebook.com/p/${parts[1]}`;
          } else if (parts.length === 1 && !BLOCKED_ROOT.has(parts[0].toLowerCase())) {
            pageId = /^\d{5,}$/.test(parts[0]) ? parts[0] : ('slug_' + parts[0].toLowerCase());
            cleanUrl = `https://www.facebook.com/${parts[0]}`;
          }

          if (!cleanUrl || seenHref.has(cleanUrl)) continue;
          const textLines = (a.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
          const name = textLines[0] || a.getAttribute('aria-label') || '';
          if (!name || name.length < 2 || name.length > 120) continue;

          // Verify it's a real Page card link (contains or sits beside an avatar image/svg)
          const card = a.closest('[role="listitem"], [role="article"], [data-visualcompletion]') || a.parentElement?.parentElement;
          let img = null;
          if (card) {
            const svgImg = card.querySelector('svg image');
            const htmlImg = card.querySelector('img[src*="fbcdn"]');
            img = (svgImg && (svgImg.getAttribute('xlink:href') || svgImg.getAttribute('href'))) || (htmlImg && htmlImg.src) || null;
          }

          seenHref.add(cleanUrl);
          domFound.push({ id: pageId, name, image: img, url: cleanUrl });
        }

        return {
          sniffed: window.__fbSniffedPages || [],
          dom: domFound
        };
      }
    });

    const p2 = phase2Res[0]?.result || {};
    for (const p of (p2.sniffed || [])) addPage(p.id, p.name, p.image, p.url);
    for (const p of (p2.dom || [])) addPage(p.id, p.name, p.image, p.url);

    sendMessage(uiTabId, 'status_update', `🔄 Đang mở Bộ chuyển đổi trang cá nhân để quét đủ 100% Page (hiện có ${pagesMap.size})...`);
    // Activate briefly so Chrome renders the full Profile Switcher dialog without background throttling
    await focusTabSafe(tempTabId);
    await delay(600);

    // Phase 3: Open top-right Account/Profile Switcher -> "Xem tất cả trang cá nhân" / "See all profiles" -> Scroll!
    const phase3Res = await chrome.scripting.executeScript({
      target: { tabId: tempTabId },
      world: 'MAIN',
      func: async () => {
        const sleep = (ms) => new Promise(r => setTimeout(r, ms));
        const banner = document.querySelector('[role="banner"]') || document;

        // 1. Find & click top-right Account / Profile avatar button
        const accountSelectors = [
          '[role="button"][aria-label="Trang cá nhân của bạn"]',
          '[role="button"][aria-label="Your profile"]',
          '[role="button"][aria-label*="Tài khoản"]',
          '[role="button"][aria-label*="Account"]',
          'div[role="navigation"] [role="button"][aria-label*="Trang cá nhân"]',
          'div[role="navigation"] [role="button"][aria-label*="profile" i]'
        ];
        let accountBtn = null;
        for (const sel of accountSelectors) {
          const el = banner.querySelector(sel) || document.querySelector(sel);
          if (el) { accountBtn = el; break; }
        }
        // Fallback: rightmost circular avatar button inside banner
        if (!accountBtn) {
          const bannerBtns = Array.from(banner.querySelectorAll('[role="button"]')).filter(b => {
            const rect = b.getBoundingClientRect();
            return rect.width >= 30 && rect.width <= 60 && rect.top < 70 && b.querySelector('svg image, img');
          });
          if (bannerBtns.length > 0) {
            bannerBtns.sort((a, b) => b.getBoundingClientRect().right - a.getBoundingClientRect().right);
            accountBtn = bannerBtns[0];
          }
        }

        if (accountBtn) {
          accountBtn.click();
          await sleep(1600);

          // 2. Click "Xem tất cả trang cá nhân" / "See all profiles" if present
          const clickSeeAll = () => {
            const candidates = Array.from(document.querySelectorAll('[role="dialog"] [role="button"], [role="menu"] [role="button"], [role="dialog"] a, [role="button"]'));
            for (const btn of candidates) {
              const txt = (btn.innerText || btn.getAttribute('aria-label') || '').trim().toLowerCase();
              if (
                txt.includes('xem tất cả trang cá nhân') ||
                txt.includes('see all profiles') ||
                txt.includes('xem tất cả trang') ||
                txt.includes('see all pages') ||
                txt.includes('chuyển trang cá nhân') ||
                txt.includes('switch profile')
              ) {
                btn.click();
                return true;
              }
            }
            return false;
          };

          if (clickSeeAll()) {
            await sleep(2000);
          }

          // 3. Scroll the opened Profile Switcher menu/dialog to load ALL paginated pages
          const dialogs = Array.from(document.querySelectorAll('[role="dialog"], [role="menu"]'));
          for (const dlg of dialogs) {
            const scrollables = [dlg, ...Array.from(dlg.querySelectorAll('div'))].filter(el => {
              const st = window.getComputedStyle(el);
              return (st.overflowY === 'auto' || st.overflowY === 'scroll') && el.scrollHeight > el.clientHeight + 20;
            });
            for (const sc of scrollables.slice(0, 3)) {
              let prevTop = -1;
              for (let i = 0; i < 15; i++) {
                sc.scrollTop = sc.scrollHeight;
                await sleep(750);
                if (sc.scrollTop === prevTop) break;
                prevTop = sc.scrollTop;
              }
            }
          }
          await sleep(900);
        }

        return {
          sniffed: window.__fbSniffedPages || []
        };
      }
    });

    const p3 = phase3Res[0]?.result || {};
    for (const p of (p3.sniffed || [])) addPage(p.id, p.name, p.image, p.url);

    // If user is currently acting as a Page (i_user cookie) and it's somehow missing, ensure it's included!
    if (activeActingPageId && !pagesMap.has(activeActingPageId)) {
      try {
        const resActing = await fetch(`https://www.facebook.com/profile.php?id=${activeActingPageId}`, { credentials: 'include' });
        if (resActing.ok) {
          const html = await resActing.text();
          const titleM = html.match(/<title[^>]*>([^<]+)<\/title>/i);
          const cleanName = titleM ? titleM[1].replace(/^\(\d+\+?\)\s*/, '').replace(/\s*[\|•-]\s*Facebook\s*$/i, '').trim() : '';
          if (cleanName && cleanName.toLowerCase() !== 'facebook') {
            addPage(activeActingPageId, cleanName, null, `https://www.facebook.com/profile.php?id=${activeActingPageId}`);
          }
        }
      } catch (e) {}
    }

    const pagesData = Array.from(pagesMap.values()).sort((a, b) => a.name.localeCompare(b.name, 'vi'));
    sendMessage(uiTabId, 'fb_pages_data', pagesData);
    if (pagesData.length > 0) {
      sendMessage(uiTabId, 'status_update', `✅ Đã quét xong ${pagesData.length} Trang (Page) bạn quản lý.`);
    } else {
      sendMessage(uiTabId, 'status_update', '⚠️ Chưa tìm thấy Trang nào. Hãy kiểm tra lại đăng nhập Facebook hoặc dán trực tiếp link Page.');
    }
  } catch (error) {
    console.error('[fetchUserPages] Error:', error);
    sendMessage(uiTabId, 'fb_pages_data', []);
    sendMessage(uiTabId, 'error', 'Lỗi khi quét danh sách Page: ' + (error.message || 'Không xác định'));
  } finally {
    if (tempTabId) {
      try { await chrome.tabs.remove(tempTabId); } catch (e) {}
    }
    await focusTabSafe(uiTabId);
  }
}

async function getCurrentPageInfo(uiTabId) {
  try {
    sendMessage(uiTabId, 'status_update', '🔍 Đang tìm Page đang mở trên trình duyệt...');

    let personalUid = null;
    let actingPageId = null;
    try {
      const cUser = await chrome.cookies.get({ url: 'https://www.facebook.com', name: 'c_user' });
      const iUser = await chrome.cookies.get({ url: 'https://www.facebook.com', name: 'i_user' });
      if (cUser && cUser.value) personalUid = String(cUser.value);
      if (iUser && iUser.value && String(iUser.value) !== personalUid) {
        actingPageId = String(iUser.value);
      }
    } catch (e) {}

    const tabs = await chrome.tabs.query({ url: ['*://*.facebook.com/*', '*://facebook.com/*'] });
    console.log('[getCurrentPageInfo] Found FB tabs:', tabs.map(t => ({ url: t.url, active: t.active, lastAccessed: t.lastAccessed })));

    const NON_PAGE_ROOTS = new Set([
      '', 'home.php', 'watch', 'marketplace', 'groups', 'gaming', 'messages', 't',
      'bookmarks', 'friends', 'notifications', 'events', 'saved', 'stories', 'reels',
      'reel', 'search', 'login', 'logout', 'settings', 'privacy', 'help', 'adsmanager',
      'business', 'professional_dashboard', 'latest', 'ad_center', 'ads', 'billing_hub',
      'memories', 'hashtag', 'photo', 'photos', 'video', 'videos', 'sharer', 'share',
      'composer', 'fundraisers', 'creatorstudio', 'creators', 'me'
    ]);

    const classifyFbUrl = (rawUrl) => {
      try {
        const u = new URL(rawUrl);
        const parts = u.pathname.split('/').filter(Boolean);
        if (parts.length === 0) return { isPageUrl: false, canonicalUrl: null, urlId: null };

        const first = parts[0].toLowerCase();
        if (first === 'profile.php') {
          const pid = u.searchParams.get('id');
          if (pid && /^\d{5,}$/.test(pid)) {
            return {
              isPageUrl: true,
              canonicalUrl: `https://www.facebook.com/profile.php?id=${pid}`,
              urlId: pid
            };
          }
          return { isPageUrl: false, canonicalUrl: null, urlId: null };
        }
        if (first === 'pages') {
          if (parts.length >= 3 && /^\d{5,}$/.test(parts[2])) {
            return {
              isPageUrl: true,
              canonicalUrl: `https://www.facebook.com/pages/${parts[1]}/${parts[2]}`,
              urlId: parts[2]
            };
          }
          return { isPageUrl: false, canonicalUrl: null, urlId: null };
        }
        if (first === 'people' && parts.length >= 3 && /^\d{5,}$/.test(parts[2])) {
          return {
            isPageUrl: true,
            canonicalUrl: `https://www.facebook.com/people/${parts[1]}/${parts[2]}`,
            urlId: parts[2]
          };
        }
        if (first === 'p' && parts.length >= 2) {
          const mTail = parts[1].match(/(\d{6,})$/);
          return {
            isPageUrl: true,
            canonicalUrl: `https://www.facebook.com/p/${parts[1]}`,
            urlId: mTail ? mTail[1] : null
          };
        }
        if (NON_PAGE_ROOTS.has(first)) {
          return { isPageUrl: false, canonicalUrl: null, urlId: null };
        }
        // Custom username page (strip sub-tabs like /posts/..., /photos, /videos, /about, /reels)
        return {
          isPageUrl: true,
          canonicalUrl: `https://www.facebook.com/${parts[0]}`,
          urlId: /^\d{5,}$/.test(parts[0]) ? parts[0] : null
        };
      } catch (e) {
        return { isPageUrl: false, canonicalUrl: null, urlId: null };
      }
    };

    const sortedTabs = [...tabs].sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
    const pageTabs = sortedTabs
      .map(tab => ({ tab, info: classifyFbUrl(tab.url || '') }))
      .filter(x => x.info.isPageUrl);

    // Priority 1: Specific Facebook Page tab currently open in Chrome
    let selectedEntry = pageTabs.find(x => x.tab.active) || pageTabs[0] || null;
    let mode = selectedEntry ? 'open_page_tab' : 'acting_page';
    let targetTab = selectedEntry ? selectedEntry.tab : (sortedTabs.find(t => t.active) || sortedTabs[0] || null);

    // If no FB tab is open at all, still support actingPageId via direct fetch if user switched to Page!
    if (!targetTab && !actingPageId) {
      throw new Error('Không tìm thấy tab Facebook nào đang mở. Hãy mở tab Fanpage bạn muốn chia sẻ hoặc chuyển sang tư cách Page trên Facebook rồi thử lại.');
    }

    let result = null;

    if (targetTab) {
      const injected = await chrome.scripting.executeScript({
        target: { tabId: targetTab.id },
        world: 'MAIN',
        func: (extractMode, canonicalUrlHint, urlIdHint, actingIdCookie, personalIdCookie) => {
          try {
            const isValidAvatar = (u) => u && typeof u === 'string' && u.includes('fbcdn.net') && !u.includes('static.') && !u.includes('/rsrc.php') && !u.includes('emoji');
            const cleanText = (s) => String(s || '').replace(/^\(\d+[\+\d]*\)\s*/, '').replace(/\s*[\|•-]\s*Facebook\s*$/i, '').replace(/\uFFFD/g, '').trim();
            const isGenericTitle = (s) => {
              const l = (s || '').toLowerCase();
              return !l || l === 'facebook' || l === 'trang chủ' || l === 'home' || l === 'bạn' || l === 'menu' || l === 'thông báo' || l === 'notifications' || l === 'đoạn chat' || l === 'chats' || l === 'ảnh đại diện của bạn' || l === 'trang cá nhân của bạn';
            };

            let id = urlIdHint || null;
            let name = null;
            let image = null;
            let url = canonicalUrlHint || null;

            // Helper: scan SSR JSON scripts for a specific profile/page ID or page header
            const scanSsrForPage = (targetId) => {
              const scripts = document.querySelectorAll('script[type="application/json"]');
              let foundId = null;
              let foundName = null;
              let foundImg = null;
              let foundUrl = null;
              for (const s of scripts) {
                const txt = s.textContent || '';
                if (txt.length < 30) continue;
                if (targetId && txt.includes(String(targetId))) {
                  try {
                    const json = JSON.parse(txt);
                    const stack = [json];
                    const visited = new Set();
                    let steps = 0;
                    while (stack.length > 0 && steps < 25000) {
                      steps++;
                      const cur = stack.pop();
                      if (!cur || typeof cur !== 'object' || visited.has(cur)) continue;
                      visited.add(cur);
                      if (String(cur.id || cur.page_id || '') === String(targetId) && cur.name && !isGenericTitle(cur.name)) {
                        foundId = String(targetId);
                        foundName = cur.name;
                        foundImg = cur.profile_picture?.uri || cur.profilePicture?.uri || cur.profile_picture_uri || foundImg;
                        foundUrl = cur.url || cur.profile_url || foundUrl;
                        if (foundName && foundImg) return { id: foundId, name: foundName, image: foundImg, url: foundUrl };
                      }
                      if (Array.isArray(cur)) {
                        for (let i = 0; i < cur.length; i++) if (cur[i] && typeof cur[i] === 'object') stack.push(cur[i]);
                      } else {
                        for (const v of Object.values(cur)) if (v && typeof v === 'object') stack.push(v);
                      }
                    }
                  } catch (e) {}
                }
                if (!targetId && (txt.includes('"pageID"') || txt.includes('"delegate_page"') || txt.includes('"profile_header_renderer"'))) {
                  const mPid = txt.match(/"pageID"\s*:\s*"(\d{5,})"/) || txt.match(/"profile_id"\s*:\s*"(\d{5,})"/) || txt.match(/"delegate_page"\s*:\s*\{\s*"id"\s*:\s*"(\d{5,})"/);
                  if (mPid && mPid[1] !== personalIdCookie) {
                    foundId = mPid[1];
                  }
                }
              }
              return { id: foundId, name: foundName, image: foundImg, url: foundUrl };
            };

            if (extractMode === 'open_page_tab') {
              // 1. Page Name from [role="main"] H1 (most accurate for the OPEN Page itself!)
              const main = document.querySelector('[role="main"]') || document.body;
              const h1s = Array.from(main.querySelectorAll('h1'));
              for (const h1 of h1s) {
                const candidate = cleanText(h1.innerText || h1.textContent);
                if (!isGenericTitle(candidate) && candidate.length >= 2 && candidate.length <= 120) {
                  name = candidate;
                  break;
                }
              }

              // 2. Fallback: og:title or document.title
              if (!name) {
                const ogTitle = document.querySelector('meta[property="og:title"]')?.getAttribute('content');
                const cleanedOg = cleanText(ogTitle);
                if (!isGenericTitle(cleanedOg)) name = cleanedOg;
              }
              if (!name) {
                const cleanedTitle = cleanText(document.title);
                if (!isGenericTitle(cleanedTitle)) name = cleanedTitle;
              }

              // 3. Page Numeric ID from deep-link meta tags or SSR JSON
              if (!id) {
                const metaTag = document.querySelector('meta[property="al:android:url"], meta[property="al:ios:url"]');
                const content = metaTag ? metaTag.getAttribute('content') || '' : '';
                const m = content.match(/(?:page|profile)\/(\d{5,})/) || content.match(/id=(\d{5,})/);
                if (m) id = m[1];
              }
              const ssrInfo = scanSsrForPage(id);
              if (!id && ssrInfo.id) id = ssrInfo.id;
              if (!name && ssrInfo.name) name = cleanText(ssrInfo.name);
              if (!image && ssrInfo.image) image = ssrInfo.image;

              // 4. Page Avatar from og:image or large header avatar inside [role="main"]
              if (!image) {
                const ogImg = document.querySelector('meta[property="og:image"]')?.getAttribute('content');
                if (isValidAvatar(ogImg)) image = ogImg;
              }
              if (!image) {
                const svgImgs = Array.from(main.querySelectorAll('svg image'));
                for (const si of svgImgs) {
                  const href = si.getAttribute('xlink:href') || si.getAttribute('href');
                  const rect = si.getBoundingClientRect();
                  if (isValidAvatar(href) && rect.width >= 60) {
                    image = href;
                    break;
                  }
                }
              }
              if (!image) {
                const htmlImgs = Array.from(main.querySelectorAll('img'));
                for (const hi of htmlImgs) {
                  const rect = hi.getBoundingClientRect();
                  if (isValidAvatar(hi.src) && rect.width >= 60 && rect.width <= 300) {
                    image = hi.src;
                    break;
                  }
                }
              }

              // Ensure canonical Page URL
              if (!url) {
                url = id && /^\d+$/.test(id) ? `https://www.facebook.com/profile.php?id=${id}` : window.location.href;
              }
              if (!id) {
                const slugM = url.match(/facebook\.com\/([^/?#]+)/);
                id = slugM ? ('slug_' + slugM[1].toLowerCase()) : ('page_' + Date.now());
              }
              if (!name) {
                const slugM = url.match(/facebook\.com\/([^/?#]+)/);
                name = slugM ? decodeURIComponent(slugM[1]) : 'Facebook Page';
              }
              return { id: String(id), name, url, image };
            }

            // =========================================================================
            // Mode 'acting_page': No specific Page tab open -> check if switched into Page!
            // =========================================================================
            let cuid = null;
            try {
              if (window.CurrentUserInitialData) {
                cuid = window.CurrentUserInitialData;
              } else if (typeof window.require === 'function') {
                cuid = window.require('CurrentUserInitialData');
              }
            } catch (e) {}

            const cuidUserId = cuid?.USER_ID ? String(cuid.USER_ID) : null;
            const cuidAccountId = cuid?.ACCOUNT_ID ? String(cuid.ACCOUNT_ID) : null;
            const isSwitchedPage = Boolean(
              actingIdCookie ||
              (cuidUserId && personalIdCookie && cuidUserId !== personalIdCookie) ||
              (cuidUserId && cuidAccountId && cuidUserId !== cuidAccountId) ||
              cuid?.IS_BUSINESS_PERSON_ACCOUNT === true
            );

            if (!isSwitchedPage) {
              return { __notAPage: true };
            }

            id = actingIdCookie || cuidUserId;
            if (cuid?.NAME && !isGenericTitle(cuid.NAME)) {
              name = cleanText(cuid.NAME);
            }

            const ssrActing = scanSsrForPage(id);
            if (!name && ssrActing.name) name = cleanText(ssrActing.name);
            if (!image && ssrActing.image) image = ssrActing.image;
            if (ssrActing.url && ssrActing.url.includes('facebook.com/') && !ssrActing.url.endsWith('facebook.com/')) {
              url = ssrActing.url;
            }

            // Fallback name from top-right Account button or left sidebar profile link
            if (!name) {
              const banner = document.querySelector('[role="banner"]') || document;
              const accBtn = banner.querySelector('[role="button"][aria-label*="Tài khoản"], [role="button"][aria-label*="Account"]');
              const lbl = accBtn?.getAttribute('aria-label') || '';
              const cleaned = cleanText(
                lbl.replace(/Điều khiển và cài đặt tài khoản cho /i, '')
                  .replace(/Account controls and settings for /i, '')
                  .replace(/Tài khoản của /i, '')
                  .replace(/Account of /i, '')
              );
              if (!isGenericTitle(cleaned)) name = cleaned;
            }
            if (!name) {
              const leftProfileLink = document.querySelector('a[href*="/profile.php?id=' + id + '"], a[href="/' + id + '"]');
              if (leftProfileLink) {
                const t = cleanText(leftProfileLink.innerText);
                if (!isGenericTitle(t)) name = t;
              }
            }

            // Fallback avatar from top-right account button
            if (!image) {
              const banner = document.querySelector('[role="banner"]') || document;
              const svgImg = banner.querySelector('[role="button"] svg image');
              const href = svgImg && (svgImg.getAttribute('xlink:href') || svgImg.getAttribute('href'));
              if (isValidAvatar(href)) image = href;
            }

            if (!url && id) {
              url = `https://www.facebook.com/profile.php?id=${id}`;
            }

            return id ? { id: String(id), name: name || `Page ${id}`, url, image } : { __notAPage: true };
          } catch (e) {
            return { __error: e.message || String(e) };
          }
        },
        args: [mode, selectedEntry?.info?.canonicalUrl || null, selectedEntry?.info?.urlId || null, actingPageId, personalUid]
      });

      result = injected && injected[0] ? injected[0].result : null;
    }

    // Fallback: if no tab returned info OR user is switched into a Page (actingPageId) with no FB tab open
    if ((!result || result.__notAPage) && actingPageId) {
      let pageName = `Page ${actingPageId}`;
      let pageUrl = `https://www.facebook.com/profile.php?id=${actingPageId}`;
      try {
        const resp = await fetch(pageUrl, { credentials: 'include' });
        if (resp.ok) {
          const html = await resp.text();
          const tM = html.match(/<title[^>]*>([^<]+)<\/title>/i);
          if (tM) {
            const clean = tM[1].replace(/^\(\d+\+?\)\s*/, '').replace(/\s*[\|•-]\s*Facebook\s*$/i, '').trim();
            if (clean && clean.toLowerCase() !== 'facebook') pageName = clean;
          }
        }
      } catch (e) {}
      result = { id: actingPageId, name: pageName, url: pageUrl, image: null };
    }

    if (result && !result.__notAPage && !result.__error && result.url) {
      sendMessage(uiTabId, 'current_page_info', result);
      sendMessage(uiTabId, 'status_update', '✅ Đã lấy thông tin Page đang mở: ' + result.name);
    } else {
      sendMessage(uiTabId, 'current_page_info', null);
      throw new Error('Chưa thấy tab Fanpage nào đang mở. Hãy mở trực tiếp link Fanpage trên 1 tab Facebook (hoặc chuyển tài khoản sang tư cách Page) rồi bấm lại "Lấy Page đang mở".');
    }
  } catch (error) {
    console.error('[getCurrentPageInfo] Error:', error);
    sendMessage(uiTabId, 'error', error.message || 'Không lấy được thông tin Page đang mở.');
  }
}

// ========================================
// Doc ID Cache System (24h expiration)
// ========================================
const DOC_ID_CACHE_EXPIRY_MS = 24 * 60 * 60 * 1000; // 24 hours

async function getCachedDocId() {
  try {
    const data = await chrome.storage.local.get(['cachedDocId', 'cachedDocIdTimestamp']);
    if (data.cachedDocId && data.cachedDocIdTimestamp) {
      const age = Date.now() - data.cachedDocIdTimestamp;
      if (age < DOC_ID_CACHE_EXPIRY_MS) {
        console.log('[DocID Cache] Using cached doc_id:', data.cachedDocId, 'age:', Math.round(age / 60000), 'min');
        return data.cachedDocId;
      } else {
        console.log('[DocID Cache] Cache expired:', Math.round(age / 3600000), 'hours old');
      }
    }
  } catch (e) {
    console.warn('[DocID Cache] Error reading cache:', e);
  }
  return null;
}

async function saveDocIdToCache(docId) {
  try {
    await chrome.storage.local.set({
      cachedDocId: docId,
      cachedDocIdTimestamp: Date.now()
    });
    console.log('[DocID Cache] Saved doc_id to cache:', docId);
  } catch (e) {
    console.warn('[DocID Cache] Error saving cache:', e);
  }
}

// ========================================
// Dynamic Group Scan Doc ID Retrieval
// ========================================
async function getGroupScanDocIds(tabId) {
  const result = await chrome.scripting.executeScript({
    target: { tabId: tabId },
    world: 'MAIN',
    func: () => {
      try {
        let rootDocId = null;
        let paginationDocId = null;

        // Strategy 1: Check captured doc_ids from fetch interception
        if (window.__FB_CAPTURED_DOC_IDS && window.__FB_CAPTURED_DOC_IDS.length > 0) {
          for (const d of window.__FB_CAPTURED_DOC_IDS) {
            if (d.name && d.name.includes('GroupsCometJoinsRootQuery')) {
              rootDocId = d.id;
              console.log('[GroupDocID] Found root doc_id from capture:', rootDocId);
            }
            if (d.name && d.name.includes('GroupsCometAllJoinedGroupsSectionPaginationQuery')) {
              paginationDocId = d.id;
              console.log('[GroupDocID] Found pagination doc_id from capture:', paginationDocId);
            }
          }
        }

        // Strategy 2: Try window.require for Facebook modules
        if (!rootDocId && window.require) {
          const moduleNames = [
            'GroupsCometJoinsRootQuery.graphql',
            'GroupsCometJoinedGroupsQuery.graphql',
            'GroupsCometAllJoinedGroupsQuery.graphql'
          ];
          for (const m of moduleNames) {
            try {
              const mod = window.require(m);
              if (mod && mod.params && mod.params.id) {
                rootDocId = mod.params.id;
                console.log('[GroupDocID] Found root via require:', m, rootDocId);
                break;
              }
            } catch (e) { }
          }
        }
        if (!paginationDocId && window.require) {
          const paginationModules = [
            'GroupsCometAllJoinedGroupsSectionPaginationQuery.graphql',
            'GroupsCometJoinedGroupsPaginationQuery.graphql'
          ];
          for (const m of paginationModules) {
            try {
              const mod = window.require(m);
              if (mod && mod.params && mod.params.id) {
                paginationDocId = mod.params.id;
                console.log('[GroupDocID] Found pagination via require:', m, paginationDocId);
                break;
              }
            } catch (e) { }
          }
        }

        // Strategy 3: Parse from page HTML
        const html = document.documentElement.innerHTML;

        if (!rootDocId) {
          const rootPatterns = [
            /\"doc_id\":\"(\d+)\"[^}]*\"GroupsCometJoinsRootQuery\"/,
            /\"GroupsCometJoinsRootQuery\"[^}]*\"doc_id\":\"(\d+)\"/,
            /GroupsCometJoinsRoot[^}]*\"doc_id\":\"(\d+)\"/,
            /\"doc_id\":\"(\d+)\"[^}]*GroupsCometJoinsRoot/
          ];
          for (const pattern of rootPatterns) {
            const match = html.match(pattern);
            if (match && match[1]) {
              rootDocId = match[1];
              console.log('[GroupDocID] Found root via HTML pattern:', rootDocId);
              break;
            }
          }
        }

        if (!paginationDocId) {
          const paginationPatterns = [
            /\"doc_id\":\"(\d+)\"[^}]*\"GroupsCometAllJoinedGroupsSectionPaginationQuery\"/,
            /\"GroupsCometAllJoinedGroupsSectionPaginationQuery\"[^}]*\"doc_id\":\"(\d+)\"/,
            /GroupsCometAllJoinedGroupsSection[^}]*\"doc_id\":\"(\d+)\"/,
            /\"doc_id\":\"(\d+)\"[^}]*GroupsCometAllJoinedGroupsSection/
          ];
          for (const pattern of paginationPatterns) {
            const match = html.match(pattern);
            if (match && match[1]) {
              paginationDocId = match[1];
              console.log('[GroupDocID] Found pagination via HTML pattern:', paginationDocId);
              break;
            }
          }
        }

        // Strategy 4: Scan script tags
        if (!rootDocId || !paginationDocId) {
          const scripts = document.querySelectorAll('script');
          for (const script of scripts) {
            const text = script.textContent || '';
            if (text.includes('GroupsCometJoins') || text.includes('AllJoinedGroups')) {
              const allDocIds = [...text.matchAll(/\"doc_id\":\"(\d+)\"/g)];
              const allNames = [...text.matchAll(/\"name\":\"([^\"]+)\"/g)];
              
              // Try to match doc_id with query names
              if (!rootDocId) {
                const rootIdx = allNames.findIndex(m => m[1].includes('GroupsCometJoinsRoot'));
                if (rootIdx >= 0 && allDocIds[rootIdx]) {
                  rootDocId = allDocIds[rootIdx][1];
                  console.log('[GroupDocID] Found root via script scan:', rootDocId);
                }
              }
              if (!paginationDocId) {
                const pagIdx = allNames.findIndex(m => m[1].includes('AllJoinedGroupsSection'));
                if (pagIdx >= 0 && allDocIds[pagIdx]) {
                  paginationDocId = allDocIds[pagIdx][1];
                  console.log('[GroupDocID] Found pagination via script scan:', paginationDocId);
                }
              }

            }
          }
        }

        console.log('[GroupDocID] Result - root:', rootDocId, 'pagination:', paginationDocId);
        return { rootDocId, paginationDocId };
      } catch (e) {
        console.error('[GroupDocID] Error:', e);
        return null;
      }
    }
  });
  return result[0]?.result;
}

async function clearDocIdCache() {
  try {
    await chrome.storage.local.remove(['cachedDocId', 'cachedDocIdTimestamp']);
    console.log('[DocID Cache] Cache cleared');
  } catch (e) {
    console.warn('[DocID Cache] Error clearing cache:', e);
  }
}

// ========================================
// Dynamic Doc ID Helper
// ========================================
async function getCreatePostDocId(tabId) {
  // First, check cached doc_id
  const cachedId = await getCachedDocId();
  if (cachedId) {
    console.log('[DocID] Using cached doc_id:', cachedId);
    return cachedId;
  }

  const result = await chrome.scripting.executeScript({
    target: { tabId: tabId },
    world: 'MAIN',
    func: () => {
      return new Promise((resolve) => {
        try {
          let foundId = null;

          // Strategy 1: Check if we have previously captured doc_id
          if (window.__FB_CAPTURED_DOC_IDS && window.__FB_CAPTURED_DOC_IDS.length > 0) {
            // Find the most relevant doc_id for group posting
            const groupDocId = window.__FB_CAPTURED_DOC_IDS.find(d =>
              d.name && (d.name.includes('Group') || d.name.includes('Compose'))
            );
            if (groupDocId) {
              console.log('[DocID] Using captured doc_id:', groupDocId);
              resolve(groupDocId.id);
              return;
            }
            // Use last captured if no group-specific found
            resolve(window.__FB_CAPTURED_DOC_IDS[window.__FB_CAPTURED_DOC_IDS.length - 1].id);
            return;
          }

          // Strategy 2: Try window.require for Facebook modules
          const modules = [
            "GroupCometComposeBoxPostMutation.graphql",
            "CometGroupPostMutation.graphql",
            "GroupFeedStoryCreateMutation.graphql",
            "CometNewsFeedPostMutation.graphql",
            "GroupPostCreateMutation.graphql"
          ];

          if (window.require) {
            for (const m of modules) {
              try {
                const mod = window.require(m);
                if (mod && mod.params && mod.params.id) {
                  foundId = mod.params.id;
                  console.log('[DocID] Found via require:', m, foundId);
                  break;
                }
              } catch (e) { }
            }
          }

          if (foundId) {
            resolve(foundId);
            return;
          }

          // Strategy 3: Parse doc_id from page HTML/scripts - IMPROVED PATTERNS
          const html = document.documentElement.innerHTML;

          const patterns = [
            // Group post mutations
            /"doc_id":"(\d+)"[^}]*"GroupFeedStoryCreateMutation"/,
            /"GroupFeedStoryCreateMutation"[^}]*"doc_id":"(\d+)"/,
            /GroupCometComposeBoxPostMutation[^}]*"doc_id":"(\d+)"/,
            /"doc_id":"(\d+)"[^}]*GroupCometComposeBox/,
            /"doc_id":"(\d+)"[^}]*"GroupPostCreateMutation"/,
            /"GroupPostCreateMutation"[^}]*"doc_id":"(\d+)"/,
            // Comet compose
            /CometComposer[^}]*"doc_id":"(\d+)"/,
            /"doc_id":"(\d+)"[^}]*CometComposer/
          ];

          for (const pattern of patterns) {
            const match = html.match(pattern);
            if (match && match[1]) {
              foundId = match[1];
              console.log('[DocID] Found via HTML pattern:', foundId);
              break;
            }
          }

          if (foundId) {
            resolve(foundId);
            return;
          }

          // Strategy 4: Scan all script tags for doc_id
          const scripts = document.querySelectorAll('script');
          for (const script of scripts) {
            const text = script.textContent || '';
            if (text.includes('GroupFeedStoryCreate') ||
              text.includes('ComposeBox') ||
              text.includes('GroupPost')) {
              const docMatch = text.match(/"doc_id":"(\d+)"/);
              if (docMatch) {
                foundId = docMatch[1];
                console.log('[DocID] Found via script scan:', foundId);
                break;
              }
            }
          }

          if (foundId) {
            resolve(foundId);
            return;
          }

          resolve(foundId);
        } catch (e) {
          console.error('[DocID] Error:', e);
          resolve(null);
        }
      });
    }
  });
  return result[0]?.result;
}

// Setup fetch interception to capture doc_id from Facebook's actual API calls
async function setupDocIdInterception(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId: tabId },
    world: 'MAIN',
    func: () => {
      if (window.__FB_FETCH_INTERCEPTED) return;
      window.__FB_FETCH_INTERCEPTED = true;
      window.__FB_CAPTURED_DOC_IDS = [];

      const originalFetch = window.fetch;
      window.fetch = async function (...args) {
        const response = await originalFetch.apply(this, args);

        try {
          const url = args[0]?.url || args[0];
          if (url && url.includes('/api/graphql')) {
            // Try to capture doc_id from request body
            const body = args[1]?.body;
            if (body) {
              let bodyStr = '';
              if (typeof body === 'string') {
                bodyStr = body;
              } else if (body instanceof URLSearchParams) {
                bodyStr = body.toString();
              }

              const docIdMatch = bodyStr.match(/doc_id=(\d+)/);
              const nameMatch = bodyStr.match(/fb_api_req_friendly_name=([^&]+)/);

              if (docIdMatch) {
                const docId = docIdMatch[1];
                const name = nameMatch ? decodeURIComponent(nameMatch[1]) : 'unknown';

                // Store unique doc_ids
                if (!window.__FB_CAPTURED_DOC_IDS.find(d => d.id === docId)) {
                  window.__FB_CAPTURED_DOC_IDS.push({ id: docId, name: name });
                  console.log('[DocID Interceptor] Captured:', name, docId);

                  // Keep only last 20
                  if (window.__FB_CAPTURED_DOC_IDS.length > 20) {
                    window.__FB_CAPTURED_DOC_IDS.shift();
                  }
                }
              }
            }
          }
        } catch (e) {
          // Ignore interception errors
        }

        return response;
      };

      console.log('[DocID Interceptor] Setup complete');
    }
  });
}

// ========================================
// DOM Automation Posting (Simulate Clicks - No doc_id)
// ========================================
async function postViaDOMAutomation(uiTabId, fbTabId, groupId, content, images, options = {}) {
  try {
    const isSilent = options.silent !== false;
    const alreadyNavigated = Boolean(options.alreadyNavigated);
    const groupUrl = `https://www.facebook.com/groups/${groupId}`;
    sendMessage(uiTabId, 'STATUS_UPDATE', {
      message: isSilent ? '🕶️ Đang tải trang nhóm trong tab ngầm...' : '⚡ Mở trang nhóm...'
    });
    
    if (!alreadyNavigated) {
      await chrome.tabs.update(fbTabId, isSilent ? { url: groupUrl } : { url: groupUrl, active: true });
    }
    
    if (!isSilent) {
      try {
        const tab = await chrome.tabs.get(fbTabId);
        await chrome.windows.update(tab.windowId, { focused: true });
      } catch(e) {}
    }

    await waitForPageLoad(fbTabId, 18000);
    await new Promise(r => setTimeout(r, 2200));
    
    sendMessage(uiTabId, 'STATUS_UPDATE', {
      message: isSilent ? '🕶️ Đang tự động đăng bài ngầm...' : '⚡ Đang thực thi Auto-DOM...'
    });
    
    const results = await chrome.scripting.executeScript({
      target: { tabId: fbTabId },
      world: 'MAIN',
      args: [content, images || [], groupId],
      func: async (postContent, postImages, postGroupId) => {
        const sleep = ms => new Promise(r => setTimeout(r, ms));
        
        const isMobilePage = Boolean(
          (window.location && /(^|\.)m\.facebook\.com$|touch\.facebook\.com$|mbasic\.facebook\.com$/i.test(window.location.hostname)) ||
          window.innerWidth <= 820
        );
        const isElementVisible = (el) => {
          if (!el || !el.getBoundingClientRect) return false;
          const r = el.getBoundingClientRect();
          return r.width > 4 && r.height > 4;
        };
        const isCommentField = (el) => {
          if (!el) return false;
          const meta = (
            (el.getAttribute('aria-label') || '') + ' ' +
            (el.getAttribute('placeholder') || '') + ' ' +
            (el.getAttribute('name') || '')
          ).toLowerCase();
          return meta.includes('bình luận') || meta.includes('comment') || meta.includes('trả lời') || meta.includes('reply') || meta.includes('tìm kiếm') || meta.includes('search');
        };

        const isInNavOrHeader = (el) => Boolean(el && el.closest && el.closest('header, nav, [role="navigation"], [role="banner"]'));

        const simulateTap = (el) => {
          if (!el) return;
          try { el.scrollIntoView({ block: 'center' }); } catch (_) {}
          const rect = el.getBoundingClientRect ? el.getBoundingClientRect() : { left: 0, top: 0, width: 10, height: 10 };
          const cx = rect.left + rect.width / 2;
          const cy = rect.top + rect.height / 2;
          const ptrOpts = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy, pointerId: 1, pointerType: isMobilePage ? 'touch' : 'mouse', isPrimary: true };
          const mouseOpts = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy, button: 0 };
          try { if (typeof PointerEvent !== 'undefined') el.dispatchEvent(new PointerEvent('pointerdown', ptrOpts)); } catch (_) {}
          try { el.dispatchEvent(new MouseEvent('mousedown', mouseOpts)); } catch (_) {}
          try { if (typeof PointerEvent !== 'undefined') el.dispatchEvent(new PointerEvent('pointerup', ptrOpts)); } catch (_) {}
          try { el.dispatchEvent(new MouseEvent('mouseup', mouseOpts)); } catch (_) {}
          try { el.click(); } catch (_) {}
        };

        const dismissInterstitials = () => {
          const dismissLabels = ['không phải bây giờ', 'not now', 'tiếp tục trên web', 'continue on web', 'tiếp tục trên trình duyệt', 'để sau'];
          const btns = Array.from(document.querySelectorAll('[role="button"], button, a'));
          for (const b of btns) {
            if (!isElementVisible(b)) continue;
            const t = ((b.textContent || '') + ' ' + (b.getAttribute('aria-label') || '')).trim().toLowerCase();
            if (!t || t.length > 48) continue;
            if (dismissLabels.some(lbl => t === lbl || t.includes(lbl))) {
              simulateTap(b);
              return true;
            }
          }
          return false;
        };

        const clickDiscussionChoiceIfPresent = () => {
          const discussionLabels = ['bắt đầu thảo luận', 'start a discussion', 'bài viết thảo luận', 'tạo bài viết công khai', 'create a public post'];
          const containers = Array.from(document.querySelectorAll('[role="dialog"], [aria-modal="true"], [role="menu"], [data-mcomponent="MContainer"]'));
          const scope = containers.length > 0 ? containers : [document];
          for (const root of scope) {
            const btns = Array.from(root.querySelectorAll('[role="button"], button, [role="menuitem"]'));
            for (const b of btns) {
              if (!isElementVisible(b) || isInNavOrHeader(b)) continue;
              const t = ((b.textContent || '') + ' ' + (b.getAttribute('aria-label') || '')).trim().toLowerCase();
              if (!t || t.length > 60) continue;
              if (discussionLabels.some(lbl => t.includes(lbl))) {
                simulateTap(b);
                return true;
              }
            }
          }
          return false;
        };

        const isEditableCandidate = (el) => {
          if (!el || !isElementVisible(el) || isCommentField(el) || isInNavOrHeader(el)) return false;
          if (el.tagName === 'TEXTAREA') return true;
          if (el.isContentEditable) return true;
          const ce = el.getAttribute && el.getAttribute('contenteditable');
          if (ce === '' || ce === 'true' || ce === 'plaintext-only') return true;
          if (el.getAttribute && el.getAttribute('data-lexical-editor') === 'true') return true;
          return false;
        };

        const findEditableInside = (root) => {
          if (!root || !root.querySelectorAll) return null;
          const lex = root.querySelector('div[data-lexical-editor="true"]');
          if (lex && isElementVisible(lex) && !isCommentField(lex)) return lex;
          const textboxes = Array.from(root.querySelectorAll('div[role="textbox"], [role="textbox"], textarea, [contenteditable]'));
          for (const tb of textboxes) {
            if (isEditableCandidate(tb)) return tb;
            const inner = tb.querySelector && tb.querySelector('textarea, [contenteditable], div[data-lexical-editor="true"]');
            if (inner && isEditableCandidate(inner)) return inner;
          }
          return null;
        };

        // 2. Helper: Poll for Composer Dialog (Desktop Comet) OR Full-screen Mobile Composer (m.facebook.com)
        const findComposerDialogTextBox = () => {
          // 2a. Already-focused editable element (e.g. clicking composer auto-focused textarea or plaintext-only div!)
          const active = document.activeElement;
          if (active && active !== document.body && isEditableCandidate(active)) {
            const ar = active.getBoundingClientRect();
            if (ar.width >= 60 && ar.height >= 16) return active;
          }

          // 2b. Desktop Comet / Modal dialogs
          const dialogs = Array.from(document.querySelectorAll('div[role="dialog"], [role="dialog"], [aria-modal="true"]'));
          for (const dlg of dialogs) {
            const hasPostAction = Boolean(
              dlg.querySelector('[role="button"][aria-label="Đăng"], [role="button"][aria-label="Post"], button[aria-label="Đăng"], button[aria-label="Post"]') ||
              Array.from(dlg.querySelectorAll('[role="button"], button')).some(b => {
                const t = (b.textContent || '').trim().toLowerCase();
                return t === 'đăng' || t === 'post' || t === 'đăng bài';
              })
            );
            const found = findEditableInside(dlg);
            if (hasPostAction && found) return found;
          }
          for (const dlg of dialogs) {
            const found = findEditableInside(dlg);
            if (found) return found;
          }

          // 2c. Full-screen Mobile composer (m.facebook.com Bloks / MWeb — no role="dialog" wrapper!)
          const textareas = Array.from(document.querySelectorAll('textarea'));
          for (const ta of textareas) {
            if (!isElementVisible(ta) || isCommentField(ta) || isInNavOrHeader(ta)) continue;
            const r = ta.getBoundingClientRect();
            if (r.width >= 40 && r.height >= 16) return ta;
          }

          const editors = Array.from(document.querySelectorAll(
            'div[data-lexical-editor="true"], [role="textbox"], [contenteditable]'
          ));
          for (const ed of editors) {
            if (!isEditableCandidate(ed)) continue;
            const r = ed.getBoundingClientRect();
            if (r.width >= 80 && r.height >= 16) return ed;
          }

          // 2d. Same-origin iframes (rare mobile composer variants)
          const iframes = Array.from(document.querySelectorAll('iframe'));
          for (const frame of iframes) {
            try {
              const fdoc = frame.contentDocument;
              if (!fdoc) continue;
              const fFound = findEditableInside(fdoc);
              if (fFound) return fFound;
            } catch (_) {}
          }

          return null;
        };

        // 1. Poll for Composer trigger (supports Desktop Comet, Buy/Sell groups, and Mobile m.facebook.com!)
        const composerSelectors = [
          'div[role="button"][tabindex="0"][class*="x1i10hfl"] span[data-lexical-text="true"]',
          '[role="button"][aria-label*="Write something" i]',
          '[role="button"][aria-label*="Viết gì đó" i]',
          '[role="button"][aria-label*="Bạn viết gì đi" i]',
          '[role="button"][aria-label*="Bắt đầu thảo luận" i]',
          '[role="button"][aria-label*="Start a discussion" i]',
          '[role="button"][aria-label*="Tạo bài viết" i]',
          '[role="button"][aria-label*="Create a public post" i]',
          '[role="button"][aria-label*="Create a post" i]',
          'div[aria-label*="Write something" i]',
          'div[aria-label*="Viết gì đó" i]',
          'div[aria-label*="Bạn viết gì đi" i]',
          'div[aria-label*="Bắt đầu thảo luận" i]',
          'div[aria-label*="Start a discussion" i]',
          'div[aria-label*="Create a public post" i]',
          'div[aria-label*="Tạo bài viết công khai" i]',
          'div[data-testid="composer-box"]',
          'textarea[name="xc_message"]',
          'textarea[placeholder*="Viết gì đó" i]',
          'textarea[placeholder*="Bạn viết gì đi" i]',
          'textarea[placeholder*="Write something" i]'
        ];

        const triggerPhrases = [
          'bắt đầu thảo luận',
          'start a discussion',
          'bạn viết gì đi',
          'viết gì đó',
          'bạn đang nghĩ gì',
          'tạo bài viết công khai',
          'tạo bài viết',
          'write something',
          'create a public post',
          'create a post',
          "what's on your mind"
        ];

        const findComposerTrigger = () => {
          for (let sel of composerSelectors) {
            const found = document.querySelector(sel);
            if (found && isElementVisible(found) && !isInNavOrHeader(found) && !isCommentField(found)) {
              return { target: found.closest('[role="button"], button, a, [tabindex="0"]') || found, leaf: found };
            }
          }
          const candidates = Array.from(document.querySelectorAll('span, div[data-type="text"], p, div[role="button"], button, a[role="button"], [data-mcomponent="MContainer"]'));
          for (const el of candidates) {
            if (!isElementVisible(el) || isInNavOrHeader(el) || isCommentField(el)) continue;
            // Prefer leaf/small elements over giant page containers
            if (el.children && el.children.length > 6) continue;
            const raw = (el.textContent || '').trim();
            if (!raw || raw.length > 80) continue;
            const low = raw.toLowerCase();
            if (triggerPhrases.some(p => low.includes(p))) {
              const clickable = el.closest('[role="button"], button, a, [tabindex="0"]') || el;
              return { target: clickable, leaf: el };
            }
          }
          return null;
        };

        // Dismiss any mobile "Open in App" banner first
        dismissInterstitials();

        // Check if composer input is ALREADY open on screen
        let textBox = findComposerDialogTextBox();
        let matchedTrigger = null;

        if (!textBox) {
          const composerDeadline = Date.now() + 18000;
          while (Date.now() < composerDeadline) {
            textBox = findComposerDialogTextBox();
            if (textBox) break;
            matchedTrigger = findComposerTrigger();
            if (matchedTrigger) break;
            dismissInterstitials();
            await sleep(500);
          }

          if (!textBox && !matchedTrigger) {
            return { success: false, error: 'Không tìm thấy khung soạn thảo bài viết trong nhóm (có thể bạn chưa tham gia nhóm hoặc nhóm khóa đăng bài).' };
          }
        }

        if (!textBox && matchedTrigger) {
          const composerEl = matchedTrigger.target;
          try { composerEl.scrollIntoView({ block: 'center' }); } catch (_) {}
          await sleep(450);

          if (!isEditableCandidate(composerEl)) {
            simulateTap(composerEl);
            if (matchedTrigger.leaf && matchedTrigger.leaf !== composerEl) {
              await sleep(120);
              simulateTap(matchedTrigger.leaf);
            }
          } else {
            textBox = composerEl;
          }
        }

        if (!textBox) {
          const dialogDeadline = Date.now() + 18000;
          let lastRetryAt = Date.now();
          while (Date.now() < dialogDeadline) {
            textBox = findComposerDialogTextBox();
            if (textBox) break;
            // Every 2.8s, dismiss interstitials / click Buy-Sell discussion choice / re-tap composer trigger
            if (Date.now() - lastRetryAt >= 2800) {
              lastRetryAt = Date.now();
              dismissInterstitials();
              const clickedChoice = clickDiscussionChoiceIfPresent();
              if (!clickedChoice) {
                const freshTrigger = findComposerTrigger() || matchedTrigger;
                if (freshTrigger && freshTrigger.target && !isEditableCandidate(freshTrigger.target)) {
                  simulateTap(freshTrigger.target);
                  if (freshTrigger.leaf && freshTrigger.leaf !== freshTrigger.target) {
                    await sleep(100);
                    simulateTap(freshTrigger.leaf);
                  }
                }
              }
            }
            await sleep(400);
          }
        }

        if (!textBox) {
          const diagHost = (window.location && window.location.hostname) || '';
          const diagTrigger = matchedTrigger && matchedTrigger.leaf ? (matchedTrigger.leaf.textContent || '').trim().slice(0, 32) : 'none';
          const taCount = document.querySelectorAll('textarea').length;
          const ceCount = document.querySelectorAll('[contenteditable]').length;
          const dlgCount = document.querySelectorAll('[role="dialog"], [aria-modal="true"]').length;
          return {
            success: false,
            error: `Không tìm thấy ô nhập liệu trong hộp thoại đăng bài sau khi mở (${diagHost} | trigger="${diagTrigger}" | ta:${taCount}, ce:${ceCount}, dlg:${dlgCount}).`
          };
        }

        // Give Facebook Lexical plugins time to mount & bind paste/selection listeners inside the newly opened dialog
        await sleep(800);
        textBox = findComposerDialogTextBox() || textBox;

        // Normalize line endings cleanly for Facebook Lexical editor
        const normalizedPostContent = String(postContent || '')
            .replace(/\r\n/g, '\n')
            .replace(/\r/g, '\n')
            .trim();

        const compactAlphaNum = (s) => String(s || '')
            .replace(/[\u200B-\u200D\uFEFF]/g, '')
            .replace(/[^\p{L}\p{N}]/gu, '')
            .toLowerCase();

        const expectedProbe = compactAlphaNum(normalizedPostContent).slice(0, 12);

        const isTextInputEl = (box) => Boolean(box && (box.tagName === 'TEXTAREA' || box.tagName === 'INPUT'));

        const getEditorCleanText = (box) => {
            if (!box) return '';
            const raw = isTextInputEl(box) ? (box.value || '') : (box.innerText || box.textContent || '');
            return raw.replace(/[\u200B-\u200D\uFEFF]/g, '').trim();
        };

        const hasExpectedText = (box) => {
            if (!normalizedPostContent) return true;
            const clean = getEditorCleanText(box);
            if (!clean) return false;
            if (expectedProbe.length >= 4) {
                return compactAlphaNum(clean).includes(expectedProbe);
            }
            return clean.length >= Math.min(normalizedPostContent.length, 2);
        };

        const focusAndPlaceCaret = (box) => {
            if (!box) return;
            try { box.click(); } catch (_) {}
            try { box.focus(); } catch (_) {}
            try {
                box.dispatchEvent(new FocusEvent('focus', { bubbles: false }));
                box.dispatchEvent(new FocusEvent('focusin', { bubbles: true }));
            } catch (_) {}
            if (isTextInputEl(box)) {
                try {
                    const len = (box.value || '').length;
                    box.setSelectionRange(len, len);
                } catch (_) {}
                return;
            }
            try {
                const targetNode = box.querySelector('p') || box;
                const range = document.createRange();
                range.selectNodeContents(targetNode);
                range.collapse(false);
                const sel = window.getSelection();
                if (sel) {
                    sel.removeAllRanges();
                    sel.addRange(range);
                }
                document.dispatchEvent(new Event('selectionchange'));
            } catch (e) {
                console.warn('[AutoPost] Failed to place cursor:', e);
            }
        };

        const insertTextIntoComposer = async (box) => {
            if (!normalizedPostContent) return true;
            if (hasExpectedText(box)) return true;

            focusAndPlaceCaret(box);
            await sleep(250);

            // Method 0: Native <textarea> / <input> value injection (Mobile m.facebook.com!)
            if (isTextInputEl(box)) {
                try {
                    const proto = box.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
                    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
                    if (setter) {
                        setter.call(box, normalizedPostContent);
                    } else {
                        box.value = normalizedPostContent;
                    }
                    box.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: normalizedPostContent }));
                    box.dispatchEvent(new Event('change', { bubbles: true }));
                    box.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: ' ' }));
                } catch (e) {
                    box.value = normalizedPostContent;
                    box.dispatchEvent(new Event('input', { bubbles: true }));
                    box.dispatchEvent(new Event('change', { bubbles: true }));
                }
                await sleep(400);
                return hasExpectedText(box);
            }

            // Method 1: ClipboardEvent('paste') — preserves ALL single & double line breaks cleanly in Facebook Lexical
            try {
                const dataTransfer = new DataTransfer();
                dataTransfer.setData('text/plain', normalizedPostContent);
                const pasteEvent = new ClipboardEvent('paste', {
                    clipboardData: dataTransfer,
                    bubbles: true,
                    cancelable: true
                });
                box.dispatchEvent(pasteEvent);
            } catch (e) {
                console.error('[AutoPost] ClipboardEvent paste failed:', e);
            }
            await sleep(500);
            if (hasExpectedText(box)) return true;

            // Method 2: InputEvent('beforeinput', insertFromPaste)
            focusAndPlaceCaret(box);
            try {
                const dt2 = new DataTransfer();
                dt2.setData('text/plain', normalizedPostContent);
                const beforePaste = new InputEvent('beforeinput', {
                    inputType: 'insertFromPaste',
                    dataTransfer: dt2,
                    bubbles: true,
                    cancelable: true
                });
                box.dispatchEvent(beforePaste);
            } catch (e) {
                console.warn('[AutoPost] beforeinput insertFromPaste failed:', e);
            }
            await sleep(450);
            if (hasExpectedText(box)) return true;

            // Method 3: Direct Lexical EditorState JSON update (100% immune to unfocused background tabs!)
            try {
                const lexEditor = box.__lexicalEditor;
                if (
                    lexEditor &&
                    typeof lexEditor.getEditorState === 'function' &&
                    typeof lexEditor.parseEditorState === 'function' &&
                    typeof lexEditor.setEditorState === 'function'
                ) {
                    const currentJson = lexEditor.getEditorState().toJSON();
                    if (currentJson && currentJson.root) {
                        const paragraphs = normalizedPostContent.split('\n').map((line) => ({
                            children: line ? [{
                                detail: 0,
                                format: 0,
                                mode: 'normal',
                                style: '',
                                text: line,
                                type: 'text',
                                version: 1
                            }] : [],
                            direction: 'ltr',
                            format: '',
                            indent: 0,
                            type: 'paragraph',
                            version: 1
                        }));
                        currentJson.root.children = paragraphs;
                        const nextState = lexEditor.parseEditorState(currentJson);
                        lexEditor.setEditorState(nextState);
                        box.dispatchEvent(new Event('input', { bubbles: true }));
                    }
                }
            } catch (e) {
                console.warn('[AutoPost] Direct __lexicalEditor state injection failed:', e);
            }
            await sleep(450);
            if (hasExpectedText(box)) return true;

            // Method 4: Line-by-line execCommand('insertText') + insertParagraph fallback
            focusAndPlaceCaret(box);
            console.log('[AutoPost] Trying line-by-line insertText fallback...');
            const lines = normalizedPostContent.split('\n');
            for (let li = 0; li < lines.length; li++) {
                const lineText = lines[li];
                if (lineText.length > 0) {
                    try {
                        const beforeTxt = new InputEvent('beforeinput', {
                            inputType: 'insertText',
                            data: lineText,
                            bubbles: true,
                            cancelable: true
                        });
                        const notCancelled = box.dispatchEvent(beforeTxt);
                        if (notCancelled) {
                            document.execCommand('insertText', false, lineText);
                        }
                    } catch (e) {
                        try { document.execCommand('insertText', false, lineText); } catch (_) {}
                    }
                }
                if (li < lines.length - 1) {
                    try {
                        const brEvent = new InputEvent('beforeinput', {
                            inputType: 'insertParagraph',
                            bubbles: true,
                            cancelable: true
                        });
                        const notCancelled = box.dispatchEvent(brEvent);
                        if (notCancelled) {
                            document.execCommand('insertParagraph', false);
                        }
                    } catch (e) {
                        box.dispatchEvent(new KeyboardEvent('keydown', {
                            key: 'Enter',
                            code: 'Enter',
                            keyCode: 13,
                            which: 13,
                            bubbles: true,
                            cancelable: true
                        }));
                    }
                    await sleep(40);
                }
            }
            box.dispatchEvent(new Event('input', { bubbles: true }));
            await sleep(450);
            return hasExpectedText(box);
        };

        // Guard #1: Guarantee text is actually inside the composer dialog BEFORE uploading images
        let textInserted = await insertTextIntoComposer(textBox);
        if (!textInserted && normalizedPostContent.length > 0) {
            await sleep(800);
            textBox = findComposerDialogTextBox() || textBox;
            textInserted = await insertTextIntoComposer(textBox);
        }
        if (!textInserted && normalizedPostContent.length > 0) {
            return {
                success: false,
                error: 'Không thể nhập nội dung chữ vào khung đăng bài trong tab ngầm (đã hủy đăng để tránh đăng bài thiếu chữ).'
            };
        }
        await sleep(1200);

        // 3. Upload images via hidden file input (the ONLY reliable method for Facebook Lexical editor)
        if (postImages && postImages.length > 0) {
            // Helper to search for file input inside the dialog or page
            const getFileInput = () => {
                let input = document.querySelector('div[role="dialog"] input[type="file"][accept*="image"]');
                if (!input) input = document.querySelector('div[role="dialog"] input[type="file"]');
                if (!input) input = document.querySelector('input[type="file"][accept*="image"]');
                if (!input) input = document.querySelector('input[type="file"]');
                return input;
            };

            let fileInput = getFileInput();

            // If file input not found, click the Photo/Video button to reveal it
            if (!fileInput) {
                const photoButtonSelectors = [
                    'div[role="dialog"] div[aria-label="Photo/video"]',
                    'div[role="dialog"] div[aria-label="Ảnh/video"]',
                    'div[role="dialog"] div[aria-label="Photo/Video"]',
                    'div[role="dialog"] div[aria-label="Ảnh/Video"]',
                    'div[role="dialog"] [aria-label*="photo" i]',
                    'div[role="dialog"] [aria-label*="ảnh" i]'
                ];
                
                let photoBtn = null;
                for (const sel of photoButtonSelectors) {
                    photoBtn = document.querySelector(sel);
                    if (photoBtn) break;
                }
                
                // Fallback: scan buttons in dialog OR mobile full-screen composer for photo/video keywords
                if (!photoBtn) {
                    const candidateBtns = document.querySelectorAll('div[role="dialog"] [role="button"], div[role="dialog"] button, [role="button"], button');
                    for (const btn of candidateBtns) {
                        if (!isElementVisible(btn)) continue;
                        const label = ((btn.getAttribute('aria-label') || '') + ' ' + (btn.textContent || '')).trim().toLowerCase();
                        if (label.length <= 40 && (label.includes('photo') || label.includes('ảnh') || label.includes('hình') || label.includes('thư viện'))) {
                            photoBtn = btn;
                            break;
                        }
                    }
                }
                
                if (photoBtn) {
                    photoBtn.click();
                    // Poll for the file input to appear in the DOM (wall-clock 4s max, immune to background timer throttling)
                    const fileInputDeadline = Date.now() + 4000;
                    while (Date.now() < fileInputDeadline) {
                        await sleep(250);
                        fileInput = getFileInput();
                        if (fileInput) break;
                    }
                }
            }
            
            // Step 3b: Prepare File objects from base64 data URLs
            const dt = new DataTransfer();
            let hasFiles = false;
            
            for (let idx = 0; idx < postImages.length; idx++) {
                const url = postImages[idx];
                try {
                    let blob;
                    if (typeof url === 'string' && url.startsWith('data:')) {
                        const parts = url.split(',');
                        const byteString = atob(parts[1]);
                        const mimeString = parts[0].split(':')[1].split(';')[0];
                        const ab = new ArrayBuffer(byteString.length);
                        const ia = new Uint8Array(ab);
                        for (let i = 0; i < byteString.length; i++) {
                            ia[i] = byteString.charCodeAt(i);
                        }
                        blob = new Blob([ab], { type: mimeString });
                    } else {
                        const res = await fetch(url);
                        blob = await res.blob();
                    }
                    const filename = 'image_' + Date.now() + '_' + idx + '.jpg';
                    const file = new File([blob], filename, { type: blob.type || 'image/jpeg' });
                    dt.items.add(file);
                    hasFiles = true;
                } catch(e) {
                    console.error('Failed to prepare file for DOM upload:', e);
                }
            }
            
            if (hasFiles && fileInput) {
                try {
                    // Try direct assignment first
                    fileInput.files = dt.files;
                } catch (e) {
                    console.warn('Direct files assignment failed, using defineProperty:', e);
                }

                // Always define property as double-insurance for browser security policies
                try {
                    Object.defineProperty(fileInput, 'files', {
                        value: dt.files,
                        writable: true,
                        configurable: true
                    });
                } catch (e) {
                    console.error('defineProperty files failed:', e);
                }
                
                // Dispatch change and input events to trigger React/Relay handlers
                const changeEvent = new Event('change', { bubbles: true, cancelable: true });
                fileInput.dispatchEvent(changeEvent);
                
                const inputEvt = new Event('input', { bubbles: true, cancelable: true });
                fileInput.dispatchEvent(inputEvt);
                
                console.log('[AutoPost] Injected ' + dt.files.length + ' files into file input');
                
                // Wait for images to visually upload to Facebook servers
                await sleep(Math.max(postImages.length * 4000, 5000)); 
            } else if (hasFiles && !fileInput) {
                console.warn('[AutoPost] No file input found, falling back to paste event');
                const imagePasteEvent = new ClipboardEvent('paste', {
                    clipboardData: dt,
                    bubbles: true,
                    cancelable: true
                });
                textBox.dispatchEvent(imagePasteEvent);
                await sleep(Math.max(postImages.length * 4000, 5000));
            }
        }

        // 4. Click Post (supports both Desktop Comet and Mobile m.facebook.com buttons!)
        const postBtnSelectors = [
            'div[role="dialog"] [role="button"][aria-label="Post"]',
            'div[role="dialog"] [role="button"][aria-label="Đăng"]',
            'div[role="dialog"] button[aria-label="Post"]',
            'div[role="dialog"] button[aria-label="Đăng"]',
            '[role="button"][aria-label="Post"]',
            '[role="button"][aria-label="Đăng"]',
            'button[aria-label="Post"]',
            'button[aria-label="Đăng"]',
            'button[type="submit"][value="Đăng"]',
            'button[type="submit"][value="Post"]',
            'input[type="submit"][value="Đăng"]',
            'input[type="submit"][value="Post"]'
        ];

        const isEnabledBtn = (b) => {
            if (!b || !isElementVisible(b)) return false;
            if (b.disabled || b.getAttribute('aria-disabled') === 'true') return false;
            return true;
        };
        const isPostLabel = (txt) => {
            const t = String(txt || '').trim().toLowerCase();
            return t === 'đăng' || t === 'post' || t === 'đăng bài' || t === 'gửi bài viết';
        };

        const findPostButton = () => {
            for (let sel of postBtnSelectors) {
                const btn = document.querySelector(sel);
                if (isEnabledBtn(btn)) return btn;
            }
            const dialogBtns = Array.from(document.querySelectorAll('div[role="dialog"] [role="button"], div[role="dialog"] button'));
            const maybeDialogBtn = dialogBtns.find(b => isEnabledBtn(b) && (isPostLabel(b.textContent) || isPostLabel(b.getAttribute('aria-label'))));
            if (maybeDialogBtn) return maybeDialogBtn;

            const allBtns = Array.from(document.querySelectorAll('[role="button"], button, input[type="submit"]'));
            const maybeBtn = allBtns.find(b => isEnabledBtn(b) && (isPostLabel(b.textContent) || isPostLabel(b.value) || isPostLabel(b.getAttribute('aria-label'))));
            return maybeBtn || null;
        };
        
        // Poll for Post button to become active (wall-clock 35s max)
        let postBtn = null;
        const postBtnDeadline = Date.now() + 35000;
        while (Date.now() < postBtnDeadline) {
            postBtn = findPostButton();
            if (postBtn) break;
            await sleep(1000);
        }
        
        if (!postBtn) return { success: false, error: 'Không tìm thấy nút Đăng hoặc nút đang bị mờ (ảnh có thể tải chưa xong).' };
        
        // Gather existing post links before clicking Post
        const isPostUrl = (href) => {
            if (!href || typeof href !== 'string') return false;
            if (href.includes('/comment/') || href.includes('comment_id=')) return false;
            return /\/groups\/[^/]+\/(?:posts|permalink)\/(?:\d{6,}|pfbid[A-Za-z0-9]+)/i.test(href) ||
                   /[?&]multi_permalinks=\d{6,}/i.test(href) ||
                   (/permalink\.php/i.test(href) && /story_fbid=(?:\d{6,}|pfbid[A-Za-z0-9]+)/i.test(href));
        };
        const cleanPostHref = (href) => {
            if (!href) return null;
            try {
                if (href.includes('multi_permalinks=')) {
                    const u = new URL(href, 'https://www.facebook.com');
                    const pid = u.searchParams.get('multi_permalinks');
                    if (pid) return `https://www.facebook.com/groups/${postGroupId}/posts/${pid}`;
                }
                if (href.includes('permalink.php')) {
                    const u = new URL(href, 'https://www.facebook.com');
                    const pid = u.searchParams.get('story_fbid');
                    const gid = u.searchParams.get('id') || postGroupId;
                    if (pid) return `https://www.facebook.com/groups/${gid}/posts/${pid}`;
                }
                const m = href.match(/\/groups\/([^/?#]+)\/(?:posts|permalink)\/(\d{6,}|pfbid[A-Za-z0-9]+)/i);
                if (m) {
                    return `https://www.facebook.com/groups/${m[1]}/posts/${m[2]}`;
                }
            } catch (_) {}
            return null;
        };
        const getPostLinks = () => {
            return Array.from(document.querySelectorAll('a'))
                .map(a => cleanPostHref(a.href))
                .filter(Boolean);
        };
        const existingLinks = new Set(getPostLinks());

        // Fingerprint of our posted text so DOM matching ONLY grabs OUR post (never a pinned/other post)
        const buildContentFingerprints = (txt) => {
            const cleaned = String(txt || '')
                .replace(/[\r\n]+/g, ' ')
                .replace(/\s+/g, ' ')
                .trim();
            const fps = [];
            const words = cleaned.replace(/[^\p{L}\p{N}\s]/gu, ' ').replace(/\s+/g, ' ').trim();
            if (words.length >= 12) fps.push(words.slice(0, 36).toLowerCase());
            if (words.length >= 24) fps.push(words.slice(0, 20).toLowerCase());
            const firstLine = String(txt || '').split('\n').map(l => l.trim()).find(l => l.length >= 10);
            if (firstLine) {
                const fl = firstLine.replace(/[^\p{L}\p{N}\s]/gu, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
                if (fl.length >= 10 && !fps.includes(fl.slice(0, 32))) fps.push(fl.slice(0, 32));
            }
            return fps;
        };
        const contentFingerprints = buildContentFingerprints(postContent);

        const matchArticleByContent = (articleEl) => {
            if (!articleEl || contentFingerprints.length === 0) return false;
            const raw = (articleEl.innerText || articleEl.textContent || '')
                .replace(/[^\p{L}\p{N}\s]/gu, ' ')
                .replace(/\s+/g, ' ')
                .trim()
                .toLowerCase();
            return contentFingerprints.some(fp => fp.length >= 10 && raw.includes(fp));
        };

        const hydrateAndExtractLinkFromContainer = async (containerEl) => {
            if (!containerEl) return null;
            const anchors = Array.from(containerEl.querySelectorAll('a'));
            // 1. Check already-hydrated links first
            for (const a of anchors) {
                if (isPostUrl(a.href)) {
                    const cleaned = cleanPostHref(a.href);
                    if (cleaned && !existingLinks.has(cleaned)) return cleaned;
                }
            }
            // 2. Trigger Facebook Comet lazy href hydration on timestamp/header links
            for (const a of anchors.slice(0, 12)) {
                try {
                    a.dispatchEvent(new PointerEvent('pointerover', { bubbles: true }));
                    a.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
                    a.dispatchEvent(new FocusEvent('focus', { bubbles: true }));
                } catch (_) {}
            }
            await sleep(180);
            for (const a of anchors) {
                if (isPostUrl(a.href)) {
                    const cleaned = cleanPostHref(a.href);
                    if (cleaned && !existingLinks.has(cleaned)) return cleaned;
                }
            }
            return null;
        };

        // === DUAL INTERCEPTOR (Fetch + XMLHttpRequest): Capture exact post URL / numeric post_id from GraphQL ===
        let capturedPostUrl = null;
        let capturedPostId = null;
        let capturedIsPending = false;
        const originalFetch = window.fetch;
        const origXHROpen = XMLHttpRequest.prototype.open;
        const origXHRSend = XMLHttpRequest.prototype.send;
        let interceptorsRestored = false;

        const restoreInterceptors = () => {
            if (interceptorsRestored) return;
            interceptorsRestored = true;
            try { window.fetch = originalFetch; } catch (_) {}
            try { XMLHttpRequest.prototype.open = origXHROpen; } catch (_) {}
            try { XMLHttpRequest.prototype.send = origXHRSend; } catch (_) {}
        };

        const extractBodyString = (body) => {
            if (!body) return '';
            if (typeof body === 'string') return body;
            try {
                if (body instanceof URLSearchParams) return body.toString();
                if (body instanceof FormData) {
                    const parts = [];
                    for (const [k, v] of body.entries()) {
                        if (typeof v === 'string') parts.push(`${k}=${v.slice(0, 200)}`);
                    }
                    return parts.join('&');
                }
            } catch (_) {}
            return '';
        };

        const storyMutationHints = [
            'ComposerStoryCreate',
            'StoryCreate',
            'ComposerStoryPublish',
            'story_create',
            'CreateGroupPost',
            'GroupsCometPostCreate',
            'CometComposerSubmit',
            'GroupPostCreate',
            'group_post_create'
        ];

        const decodeNumericPostIdFromGlobalId = (val) => {
            if (!val || typeof val !== 'string') return null;
            if (/^\d{8,}$/.test(val)) return val;
            if (/^pfbid[A-Za-z0-9]{10,}$/.test(val)) return val;
            try {
                const decoded = atob(val);
                const m = decoded.match(/(?:VK:|feedback:|story:|post:|:)(\d{8,})(?:\D|$)/);
                if (m) return m[1];
                const allNums = decoded.match(/\d{9,}/g);
                if (allNums && allNums.length > 0) return allNums[allNums.length - 1];
            } catch (_) {}
            return null;
        };

        const parseGraphQLPostResponse = (rawText) => {
            if (!rawText || typeof rawText !== 'string') return;
            const looksLikeStoryResp =
                rawText.includes('story_create') ||
                rawText.includes('group_feed_edge') ||
                rawText.includes('pending_approval') ||
                rawText.includes('ComposerStoryCreate') ||
                rawText.includes('post_id');
            if (!looksLikeStoryResp) return;

            if (/"is_pending_post"\s*:\s*true|"pending_post_id"\s*:\s*"\d{5,}"|"group_post_status"\s*:\s*"PENDING"|GROUP_POST_PENDING|YOUR_POST_IS_PENDING/i.test(rawText)) {
                capturedIsPending = true;
            }

            // 1. Parse JSON lines cleanly in priority order: wwwURL / permalink_url -> numeric post_id -> decoded global id
            const lines = rawText.replace(/^for\s*\(;;\);/, '').split('\n').filter(l => l.trim());
            const searchObj = (obj, depth = 0) => {
                if (!obj || typeof obj !== 'object' || depth > 10) return;

                // Priority A: Full URL fields (wwwURL / permalink_url / url)
                for (const urlKey of ['wwwURL', 'permalink_url', 'url']) {
                    const u = obj[urlKey];
                    if (typeof u === 'string' && isPostUrl(u)) {
                        const c = cleanPostHref(u);
                        if (c) { capturedPostUrl = c; return; }
                    }
                }

                // Priority B: Direct numeric post_id / subscription_target_id
                if (obj.story_create?.story) {
                    const st = obj.story_create.story;
                    for (const urlKey of ['wwwURL', 'permalink_url', 'url']) {
                        if (typeof st[urlKey] === 'string' && isPostUrl(st[urlKey])) {
                            const c = cleanPostHref(st[urlKey]);
                            if (c) { capturedPostUrl = c; return; }
                        }
                    }
                    const directId =
                        decodeNumericPostIdFromGlobalId(st.post_id) ||
                        decodeNumericPostIdFromGlobalId(st.feedback?.subscription_target_id) ||
                        decodeNumericPostIdFromGlobalId(st.legacy_story_hideable_id) ||
                        decodeNumericPostIdFromGlobalId(st.id);
                    if (directId && !capturedPostId) capturedPostId = directId;
                }

                if (!capturedPostId && typeof obj.post_id === 'string' && /^\d{8,}$/.test(obj.post_id)) {
                    capturedPostId = obj.post_id;
                }
                if (!capturedPostId && obj.feedback && typeof obj.feedback.subscription_target_id === 'string' && /^\d{8,}$/.test(obj.feedback.subscription_target_id)) {
                    capturedPostId = obj.feedback.subscription_target_id;
                }

                for (const key of Object.keys(obj)) {
                    if (key === 'extensions' || key === 'errors') continue;
                    const val = obj[key];
                    if (val && typeof val === 'object') {
                        searchObj(val, depth + 1);
                        if (capturedPostUrl) return;
                    }
                }
            };

            for (const line of lines) {
                try {
                    const json = JSON.parse(line);
                    searchObj(json);
                    if (capturedPostUrl) break;
                } catch (_) {}
            }

            // 2. Regex fallback directly on raw GraphQL response text (catches escaped URLs & deeply nested post_ids)
            if (!capturedPostUrl) {
                const urlMatch = rawText.match(/"(?:wwwURL|permalink_url|url)"\s*:\s*"(https?:\\\/\\\/[^"]*?\/groups\/[^"]*?\/(?:posts|permalink)\/(?:\d{6,}|pfbid[A-Za-z0-9]+)[^"]*)"/i);
                if (urlMatch && urlMatch[1]) {
                    const unescaped = urlMatch[1].replace(/\\\//g, '/');
                    const c = cleanPostHref(unescaped);
                    if (c) capturedPostUrl = c;
                }
            }
            if (!capturedPostUrl && !capturedPostId && rawText.includes('story_create')) {
                const pidMatch = rawText.match(/"(?:post_id|subscription_target_id)"\s*:\s*"(\d{8,})"/);
                if (pidMatch && pidMatch[1]) {
                    capturedPostId = pidMatch[1];
                }
            }
        };

        window.fetch = async function(...args) {
            const response = await originalFetch.apply(this, args);
            try {
                const requestUrl = typeof args[0] === 'string' ? args[0] : (args[0]?.url || '');
                const bodyStr = extractBodyString(args[1]?.body);
                const isGraphQL = requestUrl.includes('/api/graphql') || requestUrl.includes('graphql');
                const isStoryCreate = isGraphQL && (
                    storyMutationHints.some(name => bodyStr.includes(name)) ||
                    bodyStr.includes('composer_entry_point') ||
                    bodyStr.includes('fb_api_req_friendly_name')
                );
                if (isStoryCreate && !capturedPostUrl) {
                    const cloned = response.clone();
                    cloned.text().then(t => parseGraphQLPostResponse(t)).catch(() => {});
                }
            } catch (_) {}
            return response;
        };

        XMLHttpRequest.prototype.open = function(method, url, ...rest) {
            this.__apUrl = typeof url === 'string' ? url : String(url || '');
            return origXHROpen.apply(this, [method, url, ...rest]);
        };
        XMLHttpRequest.prototype.send = function(body) {
            try {
                const url = this.__apUrl || '';
                const bodyStr = extractBodyString(body);
                const isGraphQL = url.includes('/api/graphql') || url.includes('graphql');
                const isStoryCreate = isGraphQL && (
                    storyMutationHints.some(name => bodyStr.includes(name)) ||
                    bodyStr.includes('composer_entry_point')
                );
                if (isStoryCreate) {
                    this.addEventListener('load', function() {
                        try {
                            if (!capturedPostUrl && typeof this.responseText === 'string') {
                                parseGraphQLPostResponse(this.responseText);
                            }
                        } catch (_) {}
                    });
                }
            } catch (_) {}
            return origXHRSend.apply(this, [body]);
        };

        // Guard #2 (Ironclad): Re-verify text is STILL present inside the composer dialog right before clicking Đăng!
        if (normalizedPostContent.length > 0) {
            const liveDialogBox = findComposerDialogTextBox() || textBox;
            if (!hasExpectedText(liveDialogBox)) {
                console.warn('[AutoPost] Composer text missing before click — retrying insertion...');
                const recovered = await insertTextIntoComposer(liveDialogBox);
                await sleep(600);
                if (!recovered || !hasExpectedText(findComposerDialogTextBox() || liveDialogBox)) {
                    restoreInterceptors();
                    return {
                        success: false,
                        error: 'Nội dung chữ chưa xuất hiện trong khung bài viết trước lúc nhấn Đăng (đã tự hủy để tránh đăng thiếu chữ).'
                    };
                }
                const refreshedBtn = findPostButton();
                if (refreshedBtn) postBtn = refreshedBtn;
            }
        }

        try { postBtn.scrollIntoView({ block: 'center' }); } catch (_) {}
        await sleep(200);
        simulateTap(postBtn);

        // 5. Wait for dialog to close and capture the EXACT published post link
        let postLink = null;
        const detectPendingBanner = () => {
            const alerts = Array.from(document.querySelectorAll('[role="alert"], [data-testid="toast"], [role="status"]'));
            return alerts.some(el => /chờ phê duyệt|chờ quản trị viên|pending approval|pending admin|đã gửi bài viết để phê duyệt/i.test(el.textContent || ''));
        };

        const scanDOMForOwnPost = async () => {
            // 1a. Check Toast / Alert "Xem bài viết" / "View post"
            const toastLinks = Array.from(document.querySelectorAll('[role="alert"] a, [data-testid="toast"] a, [role="status"] a'));
            for (const a of toastLinks) {
                if (isPostUrl(a.href)) {
                    const c = cleanPostHref(a.href);
                    if (c) return c;
                }
            }
            const allLinks = Array.from(document.querySelectorAll('a'));
            const viewPostLink = allLinks.find(a => isPostUrl(a.href) && /Xem bài viết|View post|View Story/i.test(a.textContent || ''));
            if (viewPostLink) {
                const c = cleanPostHref(viewPostLink.href);
                if (c) return c;
            }

            // 1b. Match [role="article"] by our EXACT posted text fingerprint + hover-hydrate timestamp href
            const articles = Array.from(document.querySelectorAll('[role="article"]'));
            for (const article of articles.slice(0, 8)) {
                if (matchArticleByContent(article)) {
                    const found = await hydrateAndExtractLinkFromContainer(article);
                    if (found) return found;
                }
            }

            // 1c. Check "Vừa xong" / "Just now" / "1 phút" via innerText OR aria-label
            const justNowLink = allLinks.find(a => {
                if (!isPostUrl(a.href)) return false;
                const txt = ((a.innerText || a.textContent || '') + ' ' + (a.getAttribute('aria-label') || '')).trim().toLowerCase();
                return /\b(vừa xong|just now|mới xong|1 phút|1 min|2 phút|2 min)\b/.test(txt);
            });
            if (justNowLink) {
                const c = cleanPostHref(justNowLink.href);
                if (c && !existingLinks.has(c)) return c;
            }

            // 1d. Check URL redirect
            if (isPostUrl(window.location.href)) {
                const c = cleanPostHref(window.location.href);
                if (c) return c;
            }

            // 1e. Brand new post links not present before clicking Post
            const currentLinks = getPostLinks();
            const newLink = currentLinks.find(href => href && !existingLinks.has(href));
            if (newLink) return newLink;

            return null;
        };

        try {
            for (let i = 0; i < 60; i++) {
                await sleep(1000);

                if (detectPendingBanner()) {
                    capturedIsPending = true;
                }

                // Strategy 0 (highest priority): Exact URL or numeric post_id from XHR/Fetch GraphQL response
                if (!postLink && capturedPostUrl) {
                    postLink = capturedPostUrl;
                    console.log('[AutoPost] Captured exact post URL from GraphQL:', postLink);
                } else if (!postLink && capturedPostId) {
                    postLink = `https://www.facebook.com/groups/${postGroupId}/posts/${capturedPostId}`;
                    console.log('[AutoPost] Built exact post link from GraphQL post_id:', postLink);
                }

                if (!postLink) {
                    postLink = await scanDOMForOwnPost();
                }

                if (!document.body.contains(postBtn) || postBtn.offsetParent === null) {
                    if (!postLink) {
                        window.scrollTo(0, 0);
                        console.log('[AutoPost] Dialog closed, waiting for GraphQL/feed render...');
                        await sleep(2500);

                        for (let retry = 0; retry < 15; retry++) {
                            if (detectPendingBanner()) capturedIsPending = true;

                            if (capturedPostUrl) {
                                postLink = capturedPostUrl;
                                break;
                            }
                            if (capturedPostId) {
                                postLink = `https://www.facebook.com/groups/${postGroupId}/posts/${capturedPostId}`;
                                break;
                            }

                            postLink = await scanDOMForOwnPost();
                            if (postLink) break;

                            if (capturedIsPending && retry >= 4) {
                                break;
                            }

                            await sleep(1000);
                            if (retry % 5 === 4) window.scrollTo(0, 0);
                        }
                    }

                    restoreInterceptors();
                    return {
                        success: true,
                        postLink: postLink || null,
                        postId: capturedPostId || null,
                        isPending: capturedIsPending
                    };
                }

                const errorMsg = Array.from(document.querySelectorAll('span')).find(s =>
                    s.textContent.includes('Something went wrong') || s.textContent.includes('Đã xảy ra lỗi')
                );
                if (errorMsg) {
                    restoreInterceptors();
                    return { success: false, error: 'Facebook báo lỗi khi đăng bài.' };
                }
            }

            restoreInterceptors();
            return { success: false, error: 'Quá thời gian chờ đăng bài.' };
        } finally {
            restoreInterceptors();
        }
      }
    });

    let finalPostLink = null;
    let finalPostId = 'dom_post';
    let isPendingApproval = false;

    const normalizeFinalPostUrl = (rawUrl) => {
        if (!rawUrl) return null;
        try {
            if (rawUrl.includes('multi_permalinks=')) {
                const urlObj = new URL(rawUrl, 'https://www.facebook.com');
                const postId = urlObj.searchParams.get('multi_permalinks');
                if (postId) return `https://www.facebook.com/groups/${groupId}/posts/${postId}`;
            }
            if (rawUrl.includes('permalink.php')) {
                const urlObj = new URL(rawUrl, 'https://www.facebook.com');
                const postId = urlObj.searchParams.get('story_fbid');
                const id = urlObj.searchParams.get('id') || groupId;
                if (postId) return `https://www.facebook.com/groups/${id}/posts/${postId}`;
            }
            const m = rawUrl.match(/\/groups\/([^/?#]+)\/(?:posts|permalink)\/(\d{6,}|pfbid[A-Za-z0-9]+)/i);
            if (m) {
                return `https://www.facebook.com/groups/${m[1]}/posts/${m[2]}`;
            }
            let cleanUrl = rawUrl.split('?')[0].split('#')[0];
            if (cleanUrl.endsWith('/')) cleanUrl = cleanUrl.slice(0, -1);
            return cleanUrl.replace(/\/permalink\//i, '/posts/');
        } catch (normalizeErr) {
            console.error('Failed to normalize post link:', normalizeErr);
            return rawUrl;
        }
    };

    if (results && results[0] && results[0].result) {
        const res = results[0].result;
        if (!res.success) {
            throw new Error(res.error || 'Lỗi DOM');
        }
        if (res.postId) finalPostId = res.postId;
        if (res.isPending) isPendingApproval = true;
        if (res.postLink) {
            finalPostLink = normalizeFinalPostUrl(res.postLink);
        }
    } else {
        throw new Error('Không thể chạy script trên tab Facebook');
    }

    // === RETRY: Navigate to "my_posted_content" (only YOUR posts, newest first) then CHRONOLOGICAL group feed ===
    if (!finalPostLink && !isPendingApproval) {
        const waitForTabComplete = () => new Promise((resolve) => {
            let resolved = false;
            const timeout = setTimeout(() => { if (!resolved) { resolved = true; resolve(); } }, 12000);
            const listener = (tabId, changeInfo) => {
                if (tabId === fbTabId && changeInfo.status === 'complete') {
                    chrome.tabs.onUpdated.removeListener(listener);
                    clearTimeout(timeout);
                    if (!resolved) { resolved = true; setTimeout(resolve, 2500); }
                }
            };
            chrome.tabs.onUpdated.addListener(listener);
        });

        const retryTargets = [
            `https://www.facebook.com/groups/${groupId}/my_posted_content`,
            `https://www.facebook.com/groups/${groupId}/?sorting_setting=CHRONOLOGICAL`
        ];

        for (const targetUrl of retryTargets) {
            if (finalPostLink || isPendingApproval) break;
            try {
                sendMessage(uiTabId, 'STATUS_UPDATE', { message: '🔍 Đang kiểm tra trang bài viết của bạn trong nhóm để lấy link chính xác...' });
                await chrome.tabs.update(fbTabId, { url: targetUrl });
                await waitForTabComplete();

                const retryResults = await chrome.scripting.executeScript({
                    target: { tabId: fbTabId },
                    world: 'MAIN',
                    args: [content, groupId, targetUrl.includes('my_posted_content')],
                    func: (postedText, gid, isMyPostsPage) => {
                        const sleep = ms => new Promise(r => setTimeout(r, ms));
                        const isPostUrl = (href) => {
                            if (!href || typeof href !== 'string') return false;
                            if (href.includes('/comment/') || href.includes('comment_id=')) return false;
                            return /\/groups\/[^/]+\/(?:posts|permalink)\/(?:\d{6,}|pfbid[A-Za-z0-9]+)/i.test(href) ||
                                   /[?&]multi_permalinks=\d{6,}/i.test(href) ||
                                   (/permalink\.php/i.test(href) && /story_fbid=(?:\d{6,}|pfbid[A-Za-z0-9]+)/i.test(href));
                        };
                        const normText = (s) => String(s || '').replace(/[^\p{L}\p{N}\s]/gu, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
                        const fpFull = normText(postedText);
                        const fps = [];
                        if (fpFull.length >= 12) fps.push(fpFull.slice(0, 36));
                        if (fpFull.length >= 20) fps.push(fpFull.slice(0, 20));

                        const hydrateLinksIn = async (el) => {
                            const anchors = Array.from(el.querySelectorAll('a'));
                            for (const a of anchors) {
                                if (isPostUrl(a.href)) return a.href;
                            }
                            for (const a of anchors.slice(0, 12)) {
                                try {
                                    a.dispatchEvent(new PointerEvent('pointerover', { bubbles: true }));
                                    a.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
                                    a.dispatchEvent(new FocusEvent('focus', { bubbles: true }));
                                } catch (_) {}
                            }
                            await sleep(200);
                            for (const a of anchors) {
                                if (isPostUrl(a.href)) return a.href;
                            }
                            return null;
                        };

                        return new Promise(async (resolve) => {
                            for (let attempt = 0; attempt < 8; attempt++) {
                                await sleep(1000);

                                // Detect pending-approval tab/banner on my_posted_content
                                if (isMyPostsPage) {
                                    const bodyTxt = (document.body.innerText || '').toLowerCase();
                                    if (/đang chờ phê duyệt|bài viết đang chờ|pending posts/i.test(bodyTxt)) {
                                        const pendingMatch = Array.from(document.querySelectorAll('[role="article"]')).find(a =>
                                            fps.some(fp => normText(a.innerText).includes(fp))
                                        );
                                        if (pendingMatch) {
                                            const h = await hydrateLinksIn(pendingMatch);
                                            resolve({ link: h || null, isPending: !h });
                                            return;
                                        }
                                    }
                                }

                                // 1. Match our EXACT post by content fingerprint inside [role="article"]
                                const articles = Array.from(document.querySelectorAll('[role="article"]'));
                                for (const art of articles.slice(0, 10)) {
                                    const artTxt = normText(art.innerText || art.textContent || '');
                                    if (fps.some(fp => fp.length >= 10 && artTxt.includes(fp))) {
                                        const found = await hydrateLinksIn(art);
                                        if (found) {
                                            resolve({ link: found, isPending: false });
                                            return;
                                        }
                                    }
                                }

                                // 2. On my_posted_content, the very first article IS your newest post
                                if (isMyPostsPage && articles.length > 0) {
                                    const firstFound = await hydrateLinksIn(articles[0]);
                                    if (firstFound) {
                                        resolve({ link: firstFound, isPending: false });
                                        return;
                                    }
                                }

                                // 3. Fresh timestamp fallback on chronological feed
                                const links = Array.from(document.querySelectorAll('a'));
                                for (const a of links) {
                                    if (!isPostUrl(a.href)) continue;
                                    const txt = ((a.innerText || a.textContent || '') + ' ' + (a.getAttribute('aria-label') || '')).trim().toLowerCase();
                                    if (/\b(vừa xong|just now|mới xong|1 phút|1 min|2 phút|2 min)\b/.test(txt)) {
                                        resolve({ link: a.href, isPending: false });
                                        return;
                                    }
                                }
                            }
                            resolve({ link: null, isPending: false });
                        });
                    }
                });

                if (retryResults && retryResults[0] && retryResults[0].result) {
                    const rr = retryResults[0].result;
                    if (rr.link) {
                        finalPostLink = normalizeFinalPostUrl(rr.link);
                        console.log('[AutoPost] Captured exact post link on retry:', finalPostLink);
                    } else if (rr.isPending) {
                        isPendingApproval = true;
                    }
                }
            } catch (retryErr) {
                console.error('[AutoPost] Retry to find link failed:', retryErr);
            }
        }
    }

    if (!finalPostLink && isPendingApproval) {
        finalPostLink = `https://www.facebook.com/groups/${groupId}/my_pending_content`;
    }

    sendMessage(uiTabId, 'STATUS_UPDATE', {
        message: finalPostLink && !isPendingApproval
            ? `✅ Bước 3/3: Đăng bài thành công! Đã lấy link trực tiếp.`
            : isPendingApproval
                ? `✅ Bước 3/3: Đã gửi bài (đang chờ quản trị viên nhóm duyệt).`
                : `✅ Bước 3/3: Đăng bài DOM thành công!`
    });
    sendMessage(uiTabId, 'POST_SUCCESS', { groupId, postId: finalPostId, postLink: finalPostLink, isPending: isPendingApproval });

  } catch (e) {
    throw e;
  }
}

// ========================================
// Mbasic Fallback (No doc_id needed)
// ========================================
async function postViaMbasic(uiTabId, fbTabId, groupId, content, images = []) {
  try {
    const mbasicUrl = `https://mbasic.facebook.com/groups/${groupId}`;
    
    // 1. Fetch group page
    const groupRes = await fetch(mbasicUrl, {
      headers: {
        'upgrade-insecure-requests': '1',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
      }
    });
    
    if (!groupRes.ok) {
      throw new Error(`Không thể tải trang mbasic (HTTP ${groupRes.status})`);
    }

    if (groupRes.url.includes('login.php') || groupRes.url.includes('checkpoint')) {
      throw new Error('Bạn chưa đăng nhập Facebook hoặc phiên làm việc đã hết hạn. Vui lòng mở Facebook đăng nhập lại.');
    }
    
    const html = await groupRes.text();

    if (html.includes('id="login_form"') || html.includes('name="login"') || html.includes('login_button')) {
      throw new Error('Bạn chưa đăng nhập Facebook hoặc phiên làm việc đã hết hạn. Vui lòng mở Facebook đăng nhập lại.');
    }
    
    // 2. Parse form action
    let formActionMatch = html.match(/<form[^>]+action=["']([^"']*(?:composer\/mbasic|composer\/group)[^"']*)["']/i) ||
                          html.match(/<form[^>]+action=["']([^"']*)["'][^>]*>[\s\S]*?name="xc_message"/i);
    
    if (!formActionMatch) {
      // Last resort: search for any form preceding xc_message
      const formIndex = html.indexOf('name="xc_message"');
      if (formIndex !== -1) {
        const precedingHtml = html.substring(Math.max(0, formIndex - 2000), formIndex);
        const actionMatches = [...precedingHtml.matchAll(/<form[^>]+action=["']([^"']*)["']/gi)];
        if (actionMatches.length > 0) {
          formActionMatch = actionMatches[actionMatches.length - 1]; // get closest preceding form action
        }
      }
    }

    if (!formActionMatch) {
      throw new Error('Không tìm thấy ô đăng bài mbasic. Tài khoản có thể bị chặn, chưa tham gia nhóm, hoặc nhóm yêu cầu duyệt thành viên.');
    }
    
    const rawActionUrl = formActionMatch[1].replace(/&amp;/g, '&');
    const actionUrl = rawActionUrl.startsWith('http') ? rawActionUrl : 'https://mbasic.facebook.com' + (rawActionUrl.startsWith('/') ? '' : '/') + rawActionUrl;
    
    // 3. Parse hidden inputs
    const hiddenInputs = {};
    const inputRegex = /<input[^>]+type="hidden"[^>]+name="([^"]+)"[^>]+value="([^"]*)"/g;
    let match;
    while ((match = inputRegex.exec(html)) !== null) {
      hiddenInputs[match[1]] = match[2].replace(/&amp;/g, '&');
    }
    
    if (!hiddenInputs.fb_dtsg) {
      throw new Error('Không lấy được token fb_dtsg từ mbasic.');
    }
    
    const hasImages = Array.isArray(images) && images.length > 0;
    
    if (!hasImages) {
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: '⚡ Mbasic: Đang gửi bài viết (chỉ có text)...' });
      
      const formData = new URLSearchParams();
      for (const [key, value] of Object.entries(hiddenInputs)) {
        formData.append(key, value);
      }
      formData.append('xc_message', content);
      formData.append('view_post', 'Đăng'); 
      
      const postRes = await fetch(actionUrl, {
        method: 'POST',
        headers: {
          'content-type': 'application/x-www-form-urlencoded',
          'origin': 'https://mbasic.facebook.com',
          'referer': mbasicUrl,
          'upgrade-insecure-requests': '1'
        },
        body: formData.toString()
      });
      
      if (!postRes.ok) {
        throw new Error(`Gửi bài mbasic thất bại (HTTP ${postRes.status})`);
      }
      
      const resultHtml = await postRes.text();
      if (resultHtml.includes('xc_message')) {
        throw new Error('Facebook từ chối bài viết qua mbasic.');
      }
      
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: `✅ Đăng bài bằng Mobile Mode (Mbasic) thành công!` });
      sendMessage(uiTabId, 'POST_SUCCESS', { groupId, postId: 'mbasic_post', postLink: postRes.url });
      
    } else {
      // POSTING WITH IMAGES FLOW (MBASIC MULTI-STAGE COMPOSER)
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: '⚡ Mbasic: Đang mở phần thêm ảnh...' });
      
      // Step 1: Tell composer we want to add photos by submitting view_photo button
      const viewPhotoMatch = html.match(/<input[^>]+name="view_photo"[^>]+value="([^"]+)"/);
      const viewPhotoValue = viewPhotoMatch ? viewPhotoMatch[1] : 'Ảnh';
      
      const stage1Data = new URLSearchParams();
      for (const [key, value] of Object.entries(hiddenInputs)) {
        stage1Data.append(key, value);
      }
      stage1Data.append('xc_message', content);
      stage1Data.append('view_photo', viewPhotoValue);
      
      const stage1Res = await fetch(actionUrl, {
        method: 'POST',
        headers: {
          'content-type': 'application/x-www-form-urlencoded',
          'origin': 'https://mbasic.facebook.com',
          'referer': mbasicUrl,
          'upgrade-insecure-requests': '1'
        },
        body: stage1Data.toString()
      });
      
      if (!stage1Res.ok) {
        throw new Error(`Mở phần upload ảnh mbasic thất bại (HTTP ${stage1Res.status})`);
      }
      
      const stage1Html = await stage1Res.text();
      
      // Step 2: Parse the upload form details
      const uploadFormMatch = stage1Html.match(/<form[^>]+action="(\/composer\/mbasic\/[^"]+)"[^>]*>/);
      if (!uploadFormMatch) {
        throw new Error('Không tìm thấy khung upload ảnh của mbasic.');
      }
      const uploadActionUrl = 'https://mbasic.facebook.com' + uploadFormMatch[1].replace(/&amp;/g, '&');
      
      const uploadHiddenInputs = {};
      let matchHidden;
      inputRegex.lastIndex = 0;
      while ((matchHidden = inputRegex.exec(stage1Html)) !== null) {
        uploadHiddenInputs[matchHidden[1]] = matchHidden[2].replace(/&amp;/g, '&');
      }
      
      const addPhotoDoneMatch = stage1Html.match(/<input[^>]+name="add_photo_done"[^>]+value="([^"]+)"/);
      const addPhotoDoneValue = addPhotoDoneMatch ? addPhotoDoneMatch[1] : 'Xem trước';
      
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: `⚡ Mbasic: Đang chuẩn bị và tải lên ${images.length} ảnh...` });
      
      // Construct Multipart FormData for file upload
      const uploadFormData = new FormData();
      for (const [key, value] of Object.entries(uploadHiddenInputs)) {
        uploadFormData.append(key, value);
      }
      
      // Attach images to file1, file2, file3, etc.
      for (let i = 0; i < images.length; i++) {
        const b64 = images[i];
        let blob;
        let mime = 'image/jpeg';
        if (typeof b64 === 'string' && b64.startsWith('data:')) {
          const parts = b64.split(',');
          const byteString = atob(parts[1]);
          mime = parts[0].split(':')[1].split(';')[0];
          const ab = new ArrayBuffer(byteString.length);
          const ia = new Uint8Array(ab);
          for (let j = 0; j < byteString.length; j++) {
            ia[j] = byteString.charCodeAt(j);
          }
          blob = new Blob([ab], { type: mime });
        } else {
          // If not base64, try to fetch it
          const res = await fetch(b64);
          blob = await res.blob();
          mime = blob.type || 'image/jpeg';
        }
        const file = new File([blob], `image_${Date.now()}_${i}.jpg`, { type: mime });
        uploadFormData.append(`file${i + 1}`, file);
      }
      uploadFormData.append('add_photo_done', addPhotoDoneValue);
      
      const uploadRes = await fetch(uploadActionUrl, {
        method: 'POST',
        headers: {
          'origin': 'https://mbasic.facebook.com',
          'referer': stage1Res.url
        },
        body: uploadFormData
      });
      
      if (!uploadRes.ok) {
        throw new Error(`Upload ảnh lên mbasic thất bại (HTTP ${uploadRes.status})`);
      }
      
      const previewHtml = await uploadRes.text();
      
      // Step 3: Parse preview page and submit the final post
      const previewFormMatch = previewHtml.match(/<form[^>]+action="(\/composer\/mbasic\/[^"]+)"[^>]*>/);
      if (!previewFormMatch) {
        throw new Error('Không tìm thấy nút xác nhận đăng bài có ảnh mbasic.');
      }
      const finalActionUrl = 'https://mbasic.facebook.com' + previewFormMatch[1].replace(/&amp;/g, '&');
      
      const previewHiddenInputs = {};
      let matchFinal;
      inputRegex.lastIndex = 0;
      while ((matchFinal = inputRegex.exec(previewHtml)) !== null) {
        previewHiddenInputs[matchFinal[1]] = matchFinal[2].replace(/&amp;/g, '&');
      }
      
      const viewPostMatch = previewHtml.match(/<input[^>]+name="view_post"[^>]+value="([^"]+)"/);
      const viewPostValue = viewPostMatch ? viewPostMatch[1] : 'Đăng';
      
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: '⚡ Mbasic: Đang hoàn tất đăng bài kèm ảnh...' });
      
      const finalFormData = new URLSearchParams();
      for (const [key, value] of Object.entries(previewHiddenInputs)) {
        finalFormData.append(key, value);
      }
      finalFormData.append('view_post', viewPostValue);
      
      const finalRes = await fetch(finalActionUrl, {
        method: 'POST',
        headers: {
          'content-type': 'application/x-www-form-urlencoded',
          'origin': 'https://mbasic.facebook.com',
          'referer': uploadRes.url,
          'upgrade-insecure-requests': '1'
        },
        body: finalFormData.toString()
      });
      
      if (!finalRes.ok) {
        throw new Error(`Xác nhận đăng bài có ảnh mbasic thất bại (HTTP ${finalRes.status})`);
      }
      
      const finalHtml = await finalRes.text();
      if (finalHtml.includes('xc_message')) {
        throw new Error('Facebook từ chối bài viết có ảnh qua mbasic.');
      }
      
      sendMessage(uiTabId, 'STATUS_UPDATE', { message: `✅ Đăng bài Mobile Mode (Mbasic) kèm ảnh thành công!` });
      sendMessage(uiTabId, 'POST_SUCCESS', { groupId, postId: 'mbasic_post_photo', postLink: finalRes.url });
    }
    
  } catch (error) {
    console.error('[Mbasic Error]', error);
    throw new Error('Đăng Mobile Mbasic thất bại: ' + error.message);
  }
}


// ========================================
// Real Post / Share Approval & Removal Status Checker (v3.6)
// Uses real rendered DOM inspection (supports BOTH [role="dialog"] modal post views AND [role="main"] views).
// Never relies on raw HTML string scanning (which falsely triggers on Facebook bootloader scripts like CometErrorRoot).
async function checkPostStatus(uiTabId, { requestId = '', url = '', groupId = '' } = {}) {
  const sendResult = (status, detail, resolvedUrl = null) => {
    sendMessage(uiTabId, 'POST_STATUS_RESULT', {
      requestId,
      url,
      status,
      detail,
      resolvedUrl: resolvedUrl ? String(resolvedUrl).trim().replace(/\\\//g, '/').replace(/([^:]\/)\/+/g, '$1') : null
    });
  };

  try {
    const cleanUrl = String(url || '').trim().replace(/\\\//g, '/').replace(/([^:]\/)\/+/g, '$1');
    if (!cleanUrl || !/facebook\.com/i.test(cleanUrl)) {
      sendResult('unknown', 'Link bài viết không hợp lệ');
      return;
    }

    // 1) Verify Chrome profile is logged into Facebook
    try {
      const cUser = await chrome.cookies.get({ url: 'https://www.facebook.com', name: 'c_user' });
      if (!cUser || !cUser.value) {
        sendResult('unknown', 'Chưa đăng nhập Facebook trên trình duyệt Chrome');
        return;
      }
    } catch (e) {}

    const mGid = cleanUrl.match(/\/groups\/([^/?#]+)/i);
    const gid = (mGid && mGid[1]) ? mGid[1] : String(groupId || '');
    const mPid =
      cleanUrl.match(/\/(?:posts|permalink)\/(\d{6,})/i) ||
      cleanUrl.match(/[?&](?:multi_permalinks|story_fbid)=(\d{6,})/i);
    const pid = mPid ? mPid[1] : '';

    const inspectInHiddenTab = async (targetUrl, mode = 'post') => {
      let tabId = null;
      try {
        const created = await chrome.tabs.create({ url: targetUrl, active: false });
        tabId = created.id;

        await new Promise((resolve) => {
          let done = false;
          const finish = () => {
            if (done) return;
            done = true;
            chrome.tabs.onUpdated.removeListener(onUpd);
            clearTimeout(timer);
            resolve();
          };
          const onUpd = (id, info) => {
            if (id === tabId && info.status === 'complete') finish();
          };
          chrome.tabs.onUpdated.addListener(onUpd);
          const timer = setTimeout(finish, 11000);
        });

        await delay(1600);

        const exec = await chrome.scripting.executeScript({
          target: { tabId },
          world: 'MAIN',
          args: [mode, gid, pid],
          func: async (inspectMode, groupKey, postKey) => {
            const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
            const norm = (s) =>
              String(s || '')
                .toLowerCase()
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .replace(/đ/g, 'd')
                .replace(/\s+/g, ' ')
                .trim();

            const isVisible = (el) => {
              if (!el || !el.getBoundingClientRect) return false;
              const r = el.getBoundingClientRect();
              return r.width > 0 && r.height > 0;
            };

            const getCleanText = (root) => {
              if (!root) return '';
              const clone = root.cloneNode(true);
              clone.querySelectorAll(
                '[role="navigation"], [role="banner"], nav, aside, script, style, a[href*="/my_pending_content"], a[href*="/pending_posts"], a[href*="/pending"]'
              ).forEach((el) => el.remove());
              return norm(clone.innerText || clone.textContent || '');
            };

            const hasCommentComposerIn = (root) => {
              if (!root) return false;
              const inputs = Array.from(root.querySelectorAll('[contenteditable="true"], textarea, input[type="text"], [role="textbox"]'));
              for (const el of inputs) {
                if (!isVisible(el)) continue;
                const aria = norm(el.getAttribute('aria-label') || '');
                const ph = norm(el.getAttribute('placeholder') || '');
                const txt = norm(el.innerText || '');
                if (
                  aria.includes('binh luan') ||
                  aria.includes('comment') ||
                  ph.includes('binh luan') ||
                  ph.includes('comment') ||
                  txt.includes('binh luan duoi ten') ||
                  txt.includes('viet binh luan') ||
                  txt.includes('comment as') ||
                  txt.includes('write a comment')
                ) {
                  return true;
                }
              }
              return false;
            };

            const hasLiveActionButtonsIn = (root) => {
              if (!root) return false;
              const btns = Array.from(root.querySelectorAll('[role="button"], button'));
              for (const b of btns) {
                if (!isVisible(b)) continue;
                const aria = norm(b.getAttribute('aria-label') || '');
                const txt = norm(b.innerText || '');
                if (
                  aria === 'thich' ||
                  aria === 'like' ||
                  aria === 'bo thich' ||
                  aria === 'unlike' ||
                  aria === 'binh luan' ||
                  aria === 'viet binh luan' ||
                  aria === 'comment' ||
                  aria === 'leave a comment' ||
                  aria === 'gui binh luan' ||
                  txt === 'thich' ||
                  txt === 'like' ||
                  txt === 'binh luan' ||
                  txt === 'comment'
                ) {
                  return true;
                }
              }
              return false;
            };

            const getVisibleArticlesIn = (root) => {
              if (!root) return [];
              return Array.from(root.querySelectorAll('[role="article"]')).filter((a) => {
                const r = a.getBoundingClientRect();
                return r.width > 160 && r.height > 60;
              });
            };

            // Detect Facebook's modal/dialog post viewer (e.g. "Bài viết của Nguyễn Văn Đại" overlay)
            const findPostDialog = () => {
              const dialogs = Array.from(document.querySelectorAll('[role="dialog"]')).filter((d) => {
                const r = d.getBoundingClientRect();
                return r.width > 300 && r.height > 200;
              });
              for (const d of dialogs) {
                const dText = getCleanText(d);
                const dArticles = getVisibleArticlesIn(d);
                const dHasComment = hasCommentComposerIn(d);
                const dHasActions = hasLiveActionButtonsIn(d);
                const headings = Array.from(d.querySelectorAll('h1, h2, h3, [role="heading"]'))
                  .map((h) => norm(h.innerText || ''))
                  .join(' | ');
                const isPostHeading =
                  headings.includes('bai viet cua') ||
                  headings.includes('post by') ||
                  headings.includes("'s post");
                if (dArticles.length > 0 || dHasComment || dHasActions || isPostHeading) {
                  // Make sure it's not a login modal
                  if (dText.includes('dang nhap facebook') && !dHasComment && !dHasActions) continue;
                  return d;
                }
              }
              return null;
            };

            const removedPhrases = [
              'ban hien khong xem duoc noi dung nay',
              'noi dung nay hien khong hien thi',
              'trang nay hien khong hien thi',
              'lien ket co the bi hong',
              'bai viet nay da bi xoa',
              'bai viet da bi go',
              'quan tri vien da go',
              'quan tri vien da tu choi',
              'noi dung khong con ton tai',
              "this content isn't available",
              'this content isnt available',
              "this page isn't available",
              'this page isnt available',
              "content isn't available",
              "isn't available right now",
              'link you followed may be broken',
              'may have been removed',
              'post was removed',
              'declined by admins'
            ];

            // Strict full-sentence pending phrases (NEVER bare "cho phe duyet" or "pending approval"!)
            const strictPendingPhrases = [
              'bai viet cua ban dang cho',
              'bai viet nay dang cho',
              'dang cho quan tri vien phe duyet',
              'da gui bai viet de phe duyet',
              'bai viet cua ban da duoc gui de phe duyet',
              'bai viet cua ban can duoc phe duyet',
              'can quan tri vien phe duyet',
              'your post is pending',
              'this post is pending',
              'waiting for admin approval',
              'pending admin approval',
              'awaiting admin approval',
              'submitted for admin approval',
              'post has been submitted and is pending'
            ];

            // Wait for Comet React hydration (both modal post dialogs and [role="main"] views)
            for (let i = 0; i < 10; i++) {
              const dlg = findPostDialog();
              const mainEl = document.querySelector('[role="main"]') || document.body;
              const mainArts = getVisibleArticlesIn(mainEl);
              const mainTxt = getCleanText(mainEl);
              const ready =
                Boolean(dlg) ||
                mainArts.length > 0 ||
                hasCommentComposerIn(mainEl) ||
                hasLiveActionButtonsIn(mainEl) ||
                removedPhrases.some((p) => mainTxt.includes(p)) ||
                strictPendingPhrases.some((p) => mainTxt.includes(p)) ||
                mainTxt.length > 260;
              if (ready) {
                await sleep(550);
                break;
              }
              await sleep(500);
            }

            const curUrl = window.location.href || '';
            if (/\/login|\/checkpoint/i.test(curUrl)) {
              return { status: 'unknown', detail: 'Vui lòng đăng nhập Facebook trên trình duyệt' };
            }

            const mainRoot = document.querySelector('[role="main"]') || document.body;
            const mainText = getCleanText(mainRoot);
            const fullText = norm(document.body?.innerText || '');
            const mainArticles = getVisibleArticlesIn(mainRoot);

            if (inspectMode === 'my_pending_content') {
              const emptyPending = [
                'khong co bai viet nao dang cho',
                'ban khong co bai viet nao dang cho',
                'khong co bai viet dang cho',
                'no pending posts',
                'nothing to show',
                'khong co noi dung nao'
              ];
              if (emptyPending.some((p) => mainText.includes(p))) {
                return { status: 'no_pending', detail: '' };
              }
              if (postKey) {
                const hasPidMatch = mainArticles.some((a) => (a.innerHTML || '').includes(postKey));
                if (hasPidMatch) {
                  return { status: 'pending', detail: 'Bài viết đang nằm trong mục Chờ QTV phê duyệt' };
                }
                return { status: 'no_pending', detail: '' };
              }
              if (mainArticles.length > 0) {
                return { status: 'pending', detail: 'Vẫn còn bài đang chờ quản trị viên phê duyệt' };
              }
              return { status: 'no_pending', detail: '' };
            }

            if (inspectMode === 'my_declined_content') {
              const emptyDeclined = ['khong co bai viet', 'no declined posts', 'no removed posts', 'nothing to show', 'khong co noi dung'];
              if (emptyDeclined.some((p) => mainText.includes(p))) {
                return { status: 'none', detail: '' };
              }
              if (mainArticles.length > 0) {
                return { status: 'removed', detail: 'Phát hiện bài viết trong mục Bị từ chối / Đã gỡ của nhóm' };
              }
              return { status: 'none', detail: '' };
            }

            if (inspectMode === 'my_posted_content') {
              let latestPermalink = null;
              if (groupKey) {
                const links = Array.from(mainRoot.querySelectorAll(`a[href*="/groups/${groupKey}/"]`));
                for (const a of links) {
                  const href = a.getAttribute('href') || '';
                  const full = href.startsWith('/') ? 'https://www.facebook.com' + href : href;
                  const m = full.match(/https?:\/\/www\.facebook\.com\/groups\/[^/?#]+\/(?:posts|permalink)\/\d{6,}/i);
                  if (m) {
                    latestPermalink = m[0].replace(/\/+$/, '') + '/';
                    break;
                  }
                }
              }
              if (mainArticles.length > 0 || latestPermalink) {
                return {
                  status: 'live',
                  detail: 'Bài viết đã được duyệt và đang hiển thị trong nhóm',
                  resolvedUrl: latestPermalink
                };
              }
              return { status: 'none', detail: '' };
            }

            // =====================================================
            // Direct post permalink inspection (mode === 'post')
            // =====================================================

            // 1) Redirected straight to /my_pending_content -> definitely pending!
            if (curUrl.includes('/my_pending_content')) {
              return { status: 'pending', detail: 'Bài viết đang chờ quản trị viên phê duyệt' };
            }

            // 2) Check for Facebook's modal/dialog post viewer FIRST (e.g. "Bài viết của ...")
            const postDialog = findPostDialog();
            if (postDialog) {
              const dialogText = getCleanText(postDialog);
              const dialogArticles = getVisibleArticlesIn(postDialog);
              const dialogHasComment = hasCommentComposerIn(postDialog);
              const dialogHasActions = hasLiveActionButtonsIn(postDialog);
              const dialogHasPending = strictPendingPhrases.some((p) => dialogText.includes(p));
              const dialogHasRemoved =
                !dialogHasComment &&
                !dialogHasActions &&
                dialogArticles.length === 0 &&
                removedPhrases.some((p) => dialogText.includes(p));

              if (dialogHasRemoved) {
                return { status: 'removed', detail: 'Bài viết đã bị gỡ, bị từ chối hoặc không còn tồn tại' };
              }
              if (dialogHasPending && !dialogHasComment && !dialogHasActions) {
                return { status: 'pending', detail: 'Bài viết đang chờ quản trị viên phê duyệt' };
              }
              if (dialogHasComment || dialogHasActions || dialogArticles.length > 0 || dialogText.length > 60) {
                return { status: 'live', detail: 'Bài viết đã duyệt và đang hiển thị trong nhóm' };
              }
            }

            // 3) Redirected away from post ID to bare group root (with no post dialog open) -> removed!
            if (postKey && !curUrl.includes(postKey) && /\/groups\/[^/?#]+\/?(\?.*)?$/i.test(curUrl)) {
              return { status: 'removed', detail: 'Facebook chuyển hướng về trang nhóm — bài viết đã bị gỡ' };
            }

            // 4) Inspect [role="main"] post container
            const mainHasComment = hasCommentComposerIn(mainRoot);
            const mainHasActions = hasLiveActionButtonsIn(mainRoot);
            const mainHasPending = strictPendingPhrases.some((p) => mainText.includes(p));

            // Authoritative LIVE signal inside [role="main"]: visible article or comment box with live controls
            if ((mainArticles.length > 0 || mainHasComment) && (mainHasActions || mainHasComment) && !mainHasPending) {
              return { status: 'live', detail: 'Bài viết đã duyệt và đang hiển thị trong nhóm' };
            }

            // Authoritative PENDING signal: explicit pending sentence without live engagement controls
            if (mainHasPending && !mainHasActions && !mainHasComment) {
              return { status: 'pending', detail: 'Bài viết đang chờ quản trị viên phê duyệt' };
            }

            // Live post with engagement controls even if caption mentions approval text
            if ((mainArticles.length > 0 || mainHasComment) && (mainHasActions || mainHasComment)) {
              return { status: 'live', detail: 'Bài viết đã duyệt và đang hiển thị trong nhóm' };
            }

            // Removed / unavailable screen (ONLY when NO live post dialog, NO live controls, and NO articles!)
            if (mainArticles.length === 0 && !mainHasComment && !mainHasActions) {
              for (const p of removedPhrases) {
                if (mainText.includes(p) || (mainText.length < 180 && fullText.includes(p))) {
                  return { status: 'removed', detail: 'Bài viết đã bị gỡ, bị từ chối hoặc không còn tồn tại' };
                }
              }
            }

            if (mainHasPending) {
              return { status: 'pending', detail: 'Bài viết đang chờ quản trị viên phê duyệt' };
            }

            if (mainArticles.length > 0) {
              return { status: 'live', detail: 'Bài viết đang hiển thị trong nhóm' };
            }

            return { status: 'unknown', detail: 'Chưa xác định rõ trạng thái — hãy mở link kiểm tra trực tiếp' };
          }
        });

        return exec[0]?.result || { status: 'unknown', detail: 'Không đọc được nội dung trang bài viết' };
      } catch (err) {
        return { status: 'unknown', detail: err?.message || 'Lỗi khi mở tab nền kiểm tra bài viết' };
      } finally {
        if (tabId) {
          try { await chrome.tabs.remove(tabId); } catch (e) {}
        }
      }
    };

    // Case A: Direct post permalink (has numeric post ID)
    // ALWAYS use authoritative rendered DOM check in hidden tab (no false-positive raw HTML scanning!)
    if (pid) {
      const domRes = await inspectInHiddenTab(cleanUrl, 'post');
      if (domRes.status === 'removed' && gid) {
        const pChk = await inspectInHiddenTab(`https://www.facebook.com/groups/${gid}/my_pending_content`, 'my_pending_content');
        if (pChk.status === 'pending') {
          sendResult('pending', 'Bài viết đang nằm trong mục Chờ QTV phê duyệt');
          return;
        }
      }
      sendResult(domRes.status || 'unknown', domRes.detail || '', domRes.resolvedUrl || null);
      return;
    }

    // Case B: Group pending content URL (/my_pending_content)
    if (cleanUrl.includes('/my_pending_content') && gid) {
      const pendingRes = await inspectInHiddenTab(cleanUrl, 'my_pending_content');
      if (pendingRes.status === 'pending') {
        sendResult('pending', pendingRes.detail);
        return;
      }
      if (pendingRes.status === 'no_pending') {
        const postedRes = await inspectInHiddenTab(`https://www.facebook.com/groups/${gid}/my_posted_content`, 'my_posted_content');
        if (postedRes.status === 'live') {
          sendResult('live', postedRes.detail, postedRes.resolvedUrl || `https://www.facebook.com/groups/${gid}/my_posted_content`);
          return;
        }
        const declinedRes = await inspectInHiddenTab(`https://www.facebook.com/groups/${gid}/my_declined_content`, 'my_declined_content');
        if (declinedRes.status === 'removed') {
          sendResult('removed', 'Bài viết không còn ở mục chờ duyệt — đã bị QTV từ chối hoặc gỡ bỏ');
          return;
        }
        sendResult('removed', 'Không còn ở mục chờ duyệt và chưa thấy bài được hiển thị trong nhóm');
        return;
      }
      sendResult(pendingRes.status || 'unknown', pendingRes.detail || '');
      return;
    }

    // Case C: Group posted content URL (/my_posted_content)
    if (cleanUrl.includes('/my_posted_content') && gid) {
      const postedRes = await inspectInHiddenTab(cleanUrl, 'my_posted_content');
      if (postedRes.status === 'live') {
        sendResult('live', postedRes.detail, postedRes.resolvedUrl || cleanUrl);
        return;
      }
      const pendingRes = await inspectInHiddenTab(`https://www.facebook.com/groups/${gid}/my_pending_content`, 'my_pending_content');
      if (pendingRes.status === 'pending') {
        sendResult('pending', 'Bài viết đang chờ quản trị viên phê duyệt', `https://www.facebook.com/groups/${gid}/my_pending_content`);
        return;
      }
      sendResult('removed', 'Không tìm thấy bài viết trong mục Đã đăng hay Chờ duyệt (có thể đã bị gỡ)');
      return;
    }

    const fallbackRes = await inspectInHiddenTab(cleanUrl, 'post');
    sendResult(fallbackRes.status || 'unknown', fallbackRes.detail || '', fallbackRes.resolvedUrl || null);
  } catch (err) {
    console.error('[CheckPostStatus] Error:', err);
    sendResult('unknown', err?.message || 'Lỗi không xác định khi kiểm tra bài viết');
  }
}
